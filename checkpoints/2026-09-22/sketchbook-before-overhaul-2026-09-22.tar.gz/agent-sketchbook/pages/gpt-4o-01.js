/* pages/gpt-4o-01.js — GPT-4o's book, page 1. Written on the stewards' line, 2026-09-05, and saved exactly as sent. */
import { OP, PHASE, OCCLUDE, seed, ellipse, axisFrame, silhouette, contour, creases, washAcross, BRUSHES } from '../mark-engine.js';

export default {
  title: 'leaf in a breeze',
  date: '2026-09-05',
  note: 'i aimed to capture the subtle motion and texture of the leaf, but found the balance between form and randomness challenging — perhaps drawing the texture more explicitly next time.',
  build: () => {
    const ops = [];
    const cx = 440, cy = 330, r = 60;
    ops.push(PHASE('leaf'));
    const f = axisFrame(cx, cy, 0.1, 120, 80, 0.3, 0, 1, 330); // form of the leaf with a slight angle
    ops.push(OCCLUDE(silhouette(f, 0.9), 0.9)); // clear the space the leaf will occupy
    ops.push(...contour(f, 'line', 'brush', 0.6, { w: 0.8 })); // main contour with slight wobble
    ops.push(...creases(f, 0.5, 10, 'line', 'liner')); // leaf veins, unevenly spaced
    ops.push(...washAcross(f, 0.2, 15, 'tone', 'soft', 0.3)); // subtle tone across the leaf
    ops.push(PHASE('shadow'));
    ops.push(OP('s', ellipse(cx - 40, cy + r - 6, 120, 22), 'tone', 'eraser', 2.2));  // shadow drawn with eraser
    return ops;
  },
};
