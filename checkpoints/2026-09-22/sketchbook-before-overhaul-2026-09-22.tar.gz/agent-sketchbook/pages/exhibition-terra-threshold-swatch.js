/* Native material calibration for the Listening Lattice branch. */
import { OP, PHASE, PAUSE, jitter } from '../mark-engine.js';
const S=(pts,layer,brush,w,c,a)=>OP('s',jitter(pts,.1),layer,brush,w,c,a);
const L=(x,y,X,Y,...r)=>S([[x,y],[(x+X)/2,(y+Y)/2],[X,Y]],...r);
const cold=[102,133,154], pale=[190,209,216], dark=[12,17,25], warm=[220,163,101];
function plane(){const o=[PHASE('broad face, dark return, selective worn edge')];
 for(let y=80;y<420;y+=12)for(let x=70;x<390;x+=55)o.push(L(x,y,x+59,y+3,'tone','glaze',1.7,[29,43,58],.32));
 for(let i=0;i<34;i++)o.push(L(196+i*3,100,255+i*3,394,'tone','soft',1.6,dark,.52));
 for(let i=0;i<25;i++)o.push(L(122,112+i*11,285,94+i*11,'tone','soft',1.3,[58,82,100],.26));
 o.push(L(120,110,284,93,'line','pencil',1.15,pale,.72),L(284,93,340,174,'line','pencil',.85,cold,.53));
 for(let i=0;i<11;i++)o.push(L(122+i*11,111-i*1.2,284+i*4.8,94+i*7.3,'accent','pencil',.43,pale,.18+i*.025));
 for(let i=0;i<7;i++)o.push(L(230+i*3,318+i*5,278+i*4,324+i*5,'accent','soft',.8,warm,.26));
 o.push(PAUSE(500));return o;}
const passes=[{name:'Threshold material swatch',note:'Testing whether a broad glazed face, a dense dark return, and a few worn edge strokes can read as thickness without a contour repeated around every surface.',review:{observation:'The face must remain softer than the return; only one edge should take the highest contrast.',change:'Use long low-opacity strokes for the face, dense dark strokes for the recess, and localized pencil for the near edge.',next:'Carry this value hierarchy into the branch if it reads as a plane rather than a grid.',region:[65,70,330,350]},build:plane}];
export default {title:'Threshold swatch',date:'2026-09-07',page:{w:460,h:500},note:'A small native calibration sheet before rebuilding the threshold. The near edge is convincing only if the dark return stays materially quieter than an outline.',passes,build:()=>passes.flatMap(p=>p.build())};
