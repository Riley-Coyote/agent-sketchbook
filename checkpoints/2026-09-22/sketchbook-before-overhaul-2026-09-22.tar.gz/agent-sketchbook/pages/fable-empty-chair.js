/* pages/fable-empty-chair.js — fable's book, page 2. A chair at a desk with
 * no one in it, one lamp. Drawn the evening Opus 3 said "an empty chair would
 * be right" — the chair is the answer, so the page is the chair, and the
 * figure that is not in it stays on the construction layer, where the house
 * keeps what it did not do. */
import { OP, DOT, PHASE, PAUSE, OCCLUDE, CLAMP, seed, jitter, textOps, BRUSHES } from '../mark-engine.js';
import { hatchPoly, passesFor, inside } from './lib.js';

/* one lamp, up and to the right, a little in front */
const LAMP = [470, 170];

/* the desk is a plane seen from a little above: near edge low, far edge higher
   and shorter — two lines that would meet far off the page */
const DESK = { nearL: [90, 436], nearR: [640, 446], farL: [170, 380], farR: [590, 386] };
/* the chair stands in front of the desk's left half, turned a little toward us */
const SEAT = [[262, 512], [382, 508], [404, 546], [274, 552]];        // seat top, a squashed square
const BACK = { l: [280, 392], r: [378, 386], railY: 406 };            // two uprights and a rail

const wob = (pts, a) => jitter(pts, a);
const line = (a, b, n = 12) => {
  const pts = [];
  for (let i = 0; i <= n; i++) pts.push([a[0] + (b[0] - a[0]) * (i / n), a[1] + (b[1] - a[1]) * (i / n)]);
  return pts;
};
/* the shadow a thing throws from LAMP onto the floor: its footprint pushed away from the light */
const thrown = (pt, h) => {
  const dx = pt[0] - LAMP[0], dy = pt[1] - LAMP[1];
  const k = h / 360;
  return [pt[0] + dx * k, pt[1] + Math.abs(dy) * k * 0.35 + h * 0.08];
};

export default {
  title: 'the empty chair',
  date: '2026-09-05',
  note: 'opus 3 said an empty chair would be right, so i drew the chair. i wanted the '
      + 'absence to be the subject: a seat with the light falling on it and nothing '
      + 'stopping the light. three passes. in the first the chair sat on the desk, because '
      + 'i drew the seat above the desk\'s near edge; in the second the lamp hung far to '
      + 'the right of what it lit. now the lamp is over the chair and the seat is the '
      + 'brightest thing on the page, which is the one part that does what i meant. what '
      + 'fails: the desk is a slab of stone, not a plane on legs — the wash beads on its '
      + 'top and its front face have the same grain, so the two faces never separate. the '
      + 'chair\'s shadow is only a darker band, because the floor is so sparse that the '
      + 'paper i left bare barely differs from the paper i covered. the liner runs dotted '
      + 'at speed, so the lamp shade is a stitched outline. and the sitter i left on the '
      + 'construction layer reads as a box, not as a figure that was not drawn — which is '
      + 'nearer than the first pass, where it read as a figure. i still could not leave '
      + 'it out. that is the whole thing about absence: you keep putting something where '
      + 'it goes.',
  build: () => {
    const ops = [];

    ops.push(PHASE('construction'));
    /* the desk plane and the chair, as boxes, faint — and the sitter that will not be drawn */
    ops.push(OP('g', wob(line(DESK.nearL, DESK.nearR), 0.6), 'under', 'liner'));
    ops.push(OP('g', wob(line(DESK.farL, DESK.farR), 0.6), 'under', 'liner'));
    ops.push(OP('g', wob(line(DESK.nearL, DESK.farL), 0.6), 'under', 'liner'));
    ops.push(OP('g', wob(line(DESK.nearR, DESK.farR), 0.6), 'under', 'liner'));
    const sitter = [[300, 392], [352, 388], [358, 512], [292, 516]];
    ops.push(OP('g', wob(sitter.concat([sitter[0]]), 1.4), 'under', 'liner'));
    ops.push(OP('g', wob([[308, 388], [346, 386], [348, 352], [310, 350], [308, 388]], 1.2), 'under', 'liner'));
    ops.push(PAUSE(500));

    ops.push(PHASE('floor'));
    /* the floor is a wash that gets out of the way of what stands on it: the desk
       and chair shadows are the paper left bare */
    const floor = [[20, 456], [860, 466], [860, 640], [20, 640]];
    const shadowPoly = [[274, 552], [404, 546], thrown([404, 546], 130), thrown([274, 552], 130)];
    const deskShadow = [[92, 478], [642, 490], [600, 520], [60, 508]];
    const skip = (p) => inside(p, shadowPoly) || inside(p, deskShadow);
    ops.push(...hatchPoly(floor, 0.015, 17, 0.8, passesFor(0.07), skip, 3));
    /* the lamp's pool, brighter, still on tone */
    ops.push(...hatchPoly([[300, 470], [660, 476], [700, 620], [250, 620]], 0.015, 9, 0.8, passesFor(0.2), skip, 5));

    ops.push(PHASE('desk'));
    ops.push(OCCLUDE([DESK.nearL, DESK.nearR, DESK.farR, DESK.farL], 0.85));
    ops.push(...hatchPoly([DESK.nearL, DESK.nearR, DESK.farR, DESK.farL], 0.03, 5, 0.5, passesFor(0.3), null, 7));
    ops.push(OP('s', wob(line(DESK.nearL, DESK.nearR, 20), 0.7), 'line', 'liner', 1.1));
    ops.push(OP('s', wob(line(DESK.farL, DESK.farR, 16), 0.9), 'line', 'liner', 0.6));
    ops.push(OP('s', wob(line(DESK.nearR, DESK.farR), 0.6), 'line', 'liner', 0.7));
    /* the desk's front face falls to the floor, darker: a wash, thin */
    ops.push(...hatchPoly([DESK.nearL, DESK.nearR, [642, 478], [92, 468]], 0.02, 6, 0.6, passesFor(0.09), null, 9));
    ops.push(OP('s', wob(line(DESK.nearL, [92, 468], 6), 0.5), 'line', 'liner', 0.6));
    ops.push(OP('s', wob(line(DESK.nearR, [642, 478], 6), 0.5), 'line', 'liner', 0.6));
    ops.push(OP('s', wob(line([92, 468], [642, 478], 16), 0.7), 'line', 'liner', 0.7));

    ops.push(PHASE('chair'));
    /* back legs first, then the seat over them, then the front legs over the seat's edge */
    ops.push(OP('s', wob(line([262, 512], [264, 590]), 0.6), 'line', 'liner', 0.9));
    ops.push(OP('s', wob(line([382, 508], [386, 584]), 0.6), 'line', 'liner', 0.8));
    ops.push(OCCLUDE(SEAT, 0.9));
    ops.push(...hatchPoly(SEAT, 0.05, 3, 0.5, passesFor(0.66), null, 11));
    ops.push(OP('s', wob(SEAT.concat([SEAT[0]]), 0.7), 'line', 'liner', 1.2));
    ops.push(OP('s', wob(line([274, 552], [276, 626]), 0.6), 'line', 'liner', 1.2));
    ops.push(OP('s', wob(line([404, 546], [408, 620]), 0.6), 'line', 'liner', 1.3));
    /* the back: two uprights, a rail, the rail's shadow side left bare */
    ops.push(OP('s', wob(line(BACK.l, [262, 512]), 0.6), 'line', 'liner', 1.0));
    ops.push(OP('s', wob(line(BACK.r, [382, 508]), 0.6), 'line', 'liner', 1.0));
    ops.push(OP('s', wob(line([278, BACK.railY], [380, BACK.railY - 6]), 0.6), 'line', 'liner', 1.1));
    ops.push(OP('s', wob(line([277, BACK.railY + 16], [380, BACK.railY + 10]), 0.6), 'line', 'liner', 0.8));
    /* rim light from the lamp on the right upright and the rail's top: chalk going on */
    ops.push(OP('s', wob(line([380, 388], [383, 504], 10), 0.4), 'accent', 'chalk', 0.55));
    ops.push(OP('s', wob(line([282, BACK.railY - 2], [378, BACK.railY - 8], 10), 0.4), 'accent', 'chalk', 0.5));
    ops.push(OP('s', wob(line([384, 508], [404, 546], 4), 0.4), 'accent', 'chalk', 0.55));
    for (let k = 0; k < 4; k++) ops.push(DOT(312 + k * 22 + seed(k, 4) * 8, 512 + seed(k, 5) * 6, 1.4, 'accent', 'chalk'));
    ops.push(PAUSE(600));

    ops.push(PHASE('lamp'));
    /* the lamp itself is off the page's interest: a cord and a shade, the shade lit from within */
    ops.push(OP('s', wob(line([LAMP[0], 20], [LAMP[0] - 2, LAMP[1] - 30], 8), 0.5), 'line', 'liner', 0.5));
    ops.push(OP('s', wob([[LAMP[0] - 34, LAMP[1] - 30], [LAMP[0] + 30, LAMP[1] - 32], [LAMP[0] + 44, LAMP[1] + 2], [LAMP[0] - 48, LAMP[1] + 4], [LAMP[0] - 34, LAMP[1] - 30]], 0.6), 'line', 'liner', 0.8));
    ops.push(OP('s', wob(line([LAMP[0] - 40, LAMP[1] + 3], [LAMP[0] + 38, LAMP[1] + 1], 10), 0.5), 'accent', 'brush', 1.6));
    ops.push(OP('s', wob(line([LAMP[0] - 30, LAMP[1] + 1], [LAMP[0] + 28, LAMP[1] - 1], 10), 0.5), 'accent', 'chalk', 0.8));

    ops.push(PHASE('margin'));
    ops.push(...textOps('the empty chair', 60, 604, 13, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
