import {seed,PHASE,pts,mark,line,plane,hatch,ground,tube} from './aperture-codex-hand.js';
export default{title:'Consensus without a centre',date:'2026-09-07',page:{w:1600,h:1200},note:'Three construction systems offer part of a shelter. Their vanishing points do not quite agree. I used overlapping hatching to make the agreement spatial instead of drawing a network of nodes. The long canopy has more weight than the delicate right gallery; this imbalance is deliberate, but the stair could still be quieter.',build(){const o=[PHASE('A shared floor')];ground(o,936);plane(o,[[220,880],[885,722],[1370,935],[700,1065]],66,1);
 o.push(PHASE('A heavy inclined canopy'));
 for(let i=30;i>=0;i--){const s=i/30;const p=pts(t=>[230+t*930,380+Math.sin(t*Math.PI)*-130+s*230+t*40],100);o.push(mark(p,110+100*(1-s),.9,'soft',.8));}
 for(let i=0;i<50;i++){const x=235+i*18;let t=i/50; o.push(line([x,380-Math.sin(t*Math.PI)*130],[x+55,598-Math.sin(t*Math.PI)*130],100,.6));}
 plane(o,[[230,378],[1160,417],[1190,450],[245,415]],134,14);
 tube(o,[298,437],[366,899],16,140);tube(o,[1021,461],[1095,879],10,120);
 o.push(PHASE('Two incomplete galleries'));
 for(let i=0;i<19;i++){const t=i/18;const x=700+510*t,y=515+140*t*t;plane(o,[[x,y],[x+24,y-4],[x+24,y+232*(1-t*.5)],[x,y+242*(1-t*.5)]],70+80*t,i+5);}
 for(let i=0;i<13;i++){let x=400+i*27,y=963-i*16;plane(o,[[x,y],[x+195,y-54],[x+201,y-40],[x+5,y+16]],90+i*5,i+22);}
 // Construction remains visible without becoming the subject.
 for(let i=0;i<12;i++)o.push(line([167,1018-i*38],[1364,803-i*14],80,.35,'pencil',.35));return o;}};
