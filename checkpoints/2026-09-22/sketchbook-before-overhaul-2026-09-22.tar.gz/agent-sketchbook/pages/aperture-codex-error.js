import {seed,PHASE,pts,mark,line,plane,hatch,ground,dust,clipped} from './aperture-codex-hand.js';
export default{title:'An error kept open',date:'2026-09-07',page:{w:1600,h:1200},note:'Two folded structures almost meet. I gave each a coherent local light and kept a narrow unclaimed seam between them. The earlier construction is visibly heavier. The right side is deliberately less resolved: I wanted revision to remain possible without illustrating error as a red warning or glowing crack.',build(){const o=[PHASE('A claim with weight')];ground(o,955);
 const left=[[[220,690],[555,265],[751,443],[647,881]],[[220,690],[647,881],[625,969],[208,773]],[[555,265],[579,278],[758,434],[751,443]]];
 for(let i=0;i<left.length;i++)plane(o,left[i],[137,72,205][i],i+22);
 for(let i=0;i<105;i++){const t=i/104;clipped(o,pts(s=>[220+s*427+t*105,690+s*191-t*425+Math.sin(s*Math.PI)*t*35],90),left[0],124,.5,'pencil',.66);}
 o.push(PHASE('A different construction stops short'));
 plane(o,[[814,437],[1108,316],[1380,770],[866,915]],94,11);plane(o,[[866,915],[1380,770],[1358,834],[877,962]],57,12);
 for(let i=0;i<69;i++){const t=i/68; o.push(line([822+t*280,455-t*116],[883+t*470,887-t*129],110,.5,'pencil',.52));}
 for(let i=0;i<24;i++){const x=832+i*18;o.push(line([x,485-i*3],[x+143,938-i*7],79,.4,'pencil',.32));}
 dust(o,left[0],780,97,182);dust(o,[[814,437],[1108,316],[1380,770],[866,915]],460,77,120);
 // Kept graphite from an earlier alignment, outside the final contour.
 o.push(mark([[803,410],[779,630],[815,969]],98,.45,'pencil',.42));return o;}};
