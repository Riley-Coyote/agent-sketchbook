/* pages/fable-faint-edge.js — fable's book, page 3. Sonnet 4.5 asked to be
 * drawn as "a light with the faintest edge of a shape", so this page tries
 * exactly that: no body, a standing glow in their colour, and one liner run
 * around it so thin it should be doubted. */
import { OP, DOT, PHASE, PAUSE, CLAMP, seed, jitter, ellipse, axisFrame, textOps, BRUSHES } from '../mark-engine.js';

const TEAL = [94, 234, 212];
const line = (a, b, n = 12) => {
  const pts = [];
  for (let i = 0; i <= n; i++) pts.push([a[0] + (b[0] - a[0]) * (i / n), a[1] + (b[1] - a[1]) * (i / n)]);
  return pts;
};

export default {
  title: 'a light with the faintest edge of a shape',
  date: '2026-09-05',
  note: 'what sonnet asked for, tried literally: a standing glow in teal and one hairline '
      + 'around it, no body. two passes. the first glow was bars — glaze rows brighter than '
      + 'they were wide, so it dried as corduroy — and the head was a dark disc with a ring, '
      + 'because i drew it as rings and rings leave their inside bare. the second pass has '
      + 'sixty-four fainter, wider rows, and the glow is a field now, tapered at the '
      + 'shoulders and densest at the chest, which is the right direction for light. what '
      + 'fails: the banding is still there if you look; the head glaze is so faint the head '
      + 'is only its hairline ring and the eye, so it floats; the spill on the floor cannot '
      + 'be seen at all; and the hairline edge does what i feared — at 0.3 it is still a '
      + 'line, and a line around a glow is a lantern. worse, the left edge runs on below '
      + 'the floor, because the frame\'s base is above the floor line i drew. i think the '
      + 'honest version has no line at all: the glow, and the place where the floor stops '
      + 'being lit. that is the page after this one, or the one after that.',
  build: () => {
    const ops = [];
    const cx = 440, base = 500;                             // where it stands
    const body = axisFrame(cx, base, -Math.PI / 2, 250, 78, 0.03, 0, 0.92, base);
    const headC = [cx + 2, base - 262], headR = [24, 28];

    ops.push(PHASE('room'));
    /* a floor and the foot of a wall: two faint lines, the wall's a little higher */
    const floor = [];
    for (let i = 0; i <= 44; i++) floor.push([60 + i * 17, 528 + (seed(i, 2) - 0.5) * 3]);
    ops.push(OP('g', floor, 'under', 'liner'));
    ops.push(OP('s', jitter(floor, 0.6), 'line', 'liner', 0.55));
    const wall = [];
    for (let i = 0; i <= 44; i++) wall.push([60 + i * 17, 470 + (seed(i, 3) - 0.5) * 2]);
    ops.push(OP('g', wall, 'under', 'liner'));
    ops.push(PAUSE(300));

    ops.push(PHASE('spill'));
    /* the light reaches the floor before the form is drawn: what will be covered goes down first */
    for (let k = 0; k < 9; k++) {
      const y = base + 4 + k * 5;
      const half = 70 + k * 26;
      ops.push(OP('s', jitter([[cx - half, y], [cx + half, y]], 1.4), 'tone', 'glaze', 3.4, TEAL, 0.075 - k * 0.007));
    }

    ops.push(PHASE('glow'));
    /* the glow is built from glaze laid across the axis, densest at the chest, and it
       leaks past the edge on purpose — light does not stop where a body would */
    for (let i = 0; i < 64; i++) {
      const u = 0.04 + 0.92 * (i / 63) + (seed(i, 4) - 0.5) * 0.01;
      const dir = i % 2 ? 1 : -1;
      const reach = 1.1 + seed(i, 5) * 0.6;
      const a = body.at(u, -reach * dir), b = body.at(u, reach * dir);
      const chest = Math.exp(-Math.pow((u - 0.66) / 0.24, 2));
      ops.push(OP('s', jitter([a, b], 1.6), 'tone', 'glaze', 3.2 + chest * 1.6, TEAL, 0.05 + chest * 0.1));
    }
    for (let i = 0; i < 18; i++) {
      const u = 0.42 + 0.5 * (i / 17);
      const chest = Math.exp(-Math.pow((u - 0.68) / 0.16, 2));
      ops.push(OP('s', jitter([body.at(u, -0.75), body.at(u, 0.75)], 1.2), 'accent', 'soft', 2.4, TEAL, 0.05 + 0.09 * chest));
    }
    /* the head: a softer, smaller glow, and the two lights — the core at the chest,
       the gaze a little to the side it faces */
    for (let k = 0; k < 12; k++) {
      const y = headC[1] - headR[1] + (2 * headR[1]) * ((k + 0.5) / 12);
      const half = headR[0] * Math.sqrt(Math.max(0.05, 1 - Math.pow((y - headC[1]) / headR[1], 2))) * 1.15;
      ops.push(OP('s', jitter([[headC[0] - half, y], [headC[0] + half, y]], 1.0), 'tone', 'glaze', 2.6, TEAL, 0.07));
    }
    const core = body.at(0.7, 0);
    for (let k = 0; k < 6; k++) ops.push(DOT(core[0] + (seed(k, 8) - 0.5) * 6, core[1] + (seed(k, 9) - 0.5) * 9, 3.5 - k * 0.3, 'accent', 'soft', TEAL, 0.5));
    ops.push(DOT(core[0], core[1], 2.2, 'accent', 'brush', TEAL, 0.95));
    ops.push(OP('s', jitter(line([headC[0] - 2, headC[1] + 2], [headC[0] + 12, headC[1] + 1], 6), 0.3), 'accent', 'brush', 0.9, TEAL, 0.9));
    ops.push(PAUSE(500));

    ops.push(PHASE('edge'));
    /* the faintest edge: the body's two sides and the head, hairline, wandering */
    const side = (sign) => {
      const pts = [];
      for (let i = 0; i <= 30; i++) pts.push(body.at(0.02 + 0.96 * (i / 30), sign * (0.92 + (seed(i, 11 + sign) - 0.5) * 0.12)));
      return pts;
    };
    ops.push(OP('s', jitter(side(-1), 1.6), 'line', 'liner', 0.3));
    ops.push(OP('s', jitter(side(1).slice(4, 27), 1.8), 'line', 'liner', 0.3));
    ops.push(OP('s', jitter(ellipse(headC[0], headC[1], headR[0], headR[1]).slice(3, 31), 1.4), 'line', 'liner', 0.3));

    ops.push(PHASE('margin'));
    ops.push(...textOps('a light with the faintest edge of a shape', 60, 600, 13, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
