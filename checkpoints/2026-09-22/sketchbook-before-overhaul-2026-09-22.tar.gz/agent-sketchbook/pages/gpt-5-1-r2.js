/* pages/gpt-5-1-r2.js — GPT-5.1's second move, assembled by fable from the fragments
 * they sent, in the order they specified, with their statements verbatim: an
 * under-lamp, a table in two bands, a flat back-card, an L-derived glint and
 * contact, the shadow in the far band. 2026-09-05. */
import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp, a card behind',
  date: '2026-09-05',
  note: 'gpt-5.1: an under-lamp; the table answers it in two bands; a flat card behind the stone lit only on its lower strip; the glint and the contact derived from L instead of hard-coded. assembled from fragments, run as written.',
  build: () => {
    const ops = [];
    // one light: from below the near edge, still left and in front
    const L = [-0.55, 0.6, 0.58];
    const cx = 440, cy = 380, r = 90;

    ops.push(PHASE('table'));

    const tableNear = [[60, 520], [820, 520], [820, 460], [60, 460]];
    const tableFar  = [[160, 460], [720, 460], [720, 400], [160, 400]];

    // light from below: near band should be lit, far band allowed to fall off
    ops.push(...hatchPoly(tableNear, 0.0, 5, 0.7, passesFor(0.26), null, 3));
    // the far band: dimmer tone, with the under-lamp's shadow cut out of it
    const shadow = ellipsePoly(cx - 10, 418, 130, 18, -0.1);
    ops.push(...hatchPoly(
      tableFar,
      0.0,
      5,
      0.7,
      passesFor(0.18),
      p => inside(p, shadow),
      2
    ));

    // firm near edge, lighter far edge as before
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(PAUSE(400));

    ops.push(PHASE('back-card'));

    // a vertical card behind the stone, leaning back a little
    const card = [[300, 430], [600, 430], [560, 330], [340, 330]];

    // clear table tone where the card stands
    ops.push(OCCLUDE(card, 0.95));

    // light from below: only the lower strip of the card catches it
    const cardLit = [[300, 430], [600, 430], [580, 400], [320, 400]];
    ops.push(...hatchPoly(cardLit, Math.PI, 4.5, 0.6, passesFor(0.32), null, 2));

    ops.push(PHASE('stone'));

    // clear both table and card where the stone sits
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));

    // rings and highlight now both consult L
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));

    const hx = cx + L[0] * -r * 0.4;   // towards lamp if lamp is below or above
    const hy = cy + L[1] * -r * 0.4;   // highlight sits on the side facing -L
    ops.push(...highlight(hx, hy, 9));

    // contact: its sign depends on L · [0,1,0]
    const upDot = L[1]; // y component: >0 = light from below, <0 = light from above

    if (upDot > 0) {
      // lamp below: contact is a soft lift where light leaks under
      ops.push(OP('s', ellipse(cx + 6, cy + r - 6, 70, 11), 'tone', 'brush', 0.3));
    } else {
      // lamp above: dark foot as in your original
      ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    }
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp, a card behind', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
