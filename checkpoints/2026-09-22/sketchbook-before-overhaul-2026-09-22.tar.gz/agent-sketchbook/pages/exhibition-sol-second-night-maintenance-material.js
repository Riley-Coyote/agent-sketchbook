/* A material branch from Night maintenance page 2.
 * Rails and distant rims are repainted rather than cut away; the awake glass is rebuilt by reflected fields.
 */
import {DOT,PHASE,PAUSE,seed} from '../mark-engine.js';
import {roomAndGarden,glassAndCaretaker,podPoly,stroke,bezier,ellipse} from './exhibition-sol-second-night-maintenance.js';

const mix=(a,b,t)=>a+(b-a)*t;
const bone=[213,218,226],steel=[108,128,156],violet=[82,73,108];
const night=[13,16,24],deep=[25,30,45],amber=[229,163,83],ember=[151,82,45];

function materialReconstruction(){
  const ops=[PHASE('05 · architecture falls behind the glass')];
  const vanish=[1110,350];
  // Repaint the entire original rails on their own layer, then return only interrupted low-value spans.
  ops.push(bezier([70,82],[690,112],vanish,night,4.4,'soft',.96,'line',.025));
  ops.push(bezier([1430,78],[1254,180],vanish,night,4.0,'soft',.96,'line',.025));
  const railFragments=[
    [[72,83],[215,91],[337,109]],[[425,127],[542,151],[640,178]],
    [[825,227],[931,271],[1031,316]],[[1428,80],[1364,115],[1313,149]],
    [[1254,190],[1209,229],[1172,270]],
  ];
  railFragments.forEach((p,i)=>ops.push(bezier(p[0],p[1],p[2],i===0?steel:deep,
    i===0?.52:.34,'pencil',i===0?.34:.28,'line',.025)));

  ops.push(PHASE('06 · sleeping glass is mostly absence'));
  // Repaint complete distant boundaries into the room. This avoids punched-out notches.
  const sleepers=[[765,366,83,137],[918,318,58,94],[1070,357,47,78],[1200,430,70,116],[1018,552,96,155]];
  sleepers.forEach(([cx,cy,rx,ry],i)=>{
    ops.push(stroke(podPoly(cx,cy,rx,ry),night,3.2-(i%3)*.25,'soft',.92,'line',.025));
  });
  // Each sleeper retains a different amount and location of edge evidence.
  ops.push(ellipse(765,366,80,134,steel,.42,'pencil',.28,'line',-2.68,-1.48));
  ops.push(ellipse(765,366,80,134,deep,.34,'pencil',.24,'line',.18,.8));
  ops.push(ellipse(918,318,56,91,steel,.32,'pencil',.22,'line',-1.12,-.18));
  ops.push(ellipse(1070,357,45,75,steel,.28,'pencil',.19,'line',2.82,4.08));
  ops.push(ellipse(1200,430,67,112,steel,.38,'pencil',.25,'line',-.46,.56));
  ops.push(ellipse(1018,552,92,151,steel,.46,'pencil',.27,'line',1.55,2.72));
  ops.push(ellipse(1018,552,92,151,deep,.3,'pencil',.2,'line',-1.5,-.74));
  // Suspension becomes a handful of hairline fragments, not bars.
  const cables=[[[752,70],[757,151],[760,229]],[[906,70],[913,142],[917,216]],[[1062,70],[1066,170],[1069,266]],[[1187,70],[1194,196],[1198,301]]];
  cables.forEach((p,i)=>ops.push(bezier(p[0],p[1],p[2],i===0?steel:deep,.22+(i===0?.08:0),'pencil',.16+(i===0?.08:0),'line',.02)));

  ops.push(PHASE('07 · a reflected field holds the awake vessel'));
  // A broad cool field crosses the body. Overlapping soft strokes avoid a hard filled patch.
  for(let i=0;i<34;i++){
    const t=i/33;
    const x=455+t*206;
    const top=332+Math.sin(t*Math.PI)*24;
    const bottom=548-Math.sin(t*Math.PI)*31;
    const c=i%7===0?steel:violet;
    ops.push(bezier([x,top],[x+20,423],[x-7,bottom],c,
      2.8+Math.sin(t*Math.PI)*2.2,'soft',.055+Math.sin(t*Math.PI)*.055,'line',.09));
  }
  // A warmer reflected band bends across the lower third and returns cool at its far edge.
  for(let i=0;i<17;i++){
    const y=493+i*4.2;
    ops.push(bezier([463,y],[548,y+18],[657,y-8],i<7?ember:steel,
      1.5+(i%3)*.35,'glaze',.08+(i<7?.035:0),'line',.07));
  }
  // Broken vertical window reflections give the broad field a glass surface.
  const strips=[
    [[467,332],[451,389],[449,441]],[[451,464],[458,520],[477,566]],
    [[631,305],[660,371],[669,421]],[[672,449],[667,505],[649,557]],
  ];
  strips.forEach((p,i)=>ops.push(stroke(p,i===1?bone:(i%2?amber:steel),i===1?.78:.52,
    i===1?'chalk':'pencil',i===1?.52:.42,'accent',.035)));

  ops.push(PHASE('08 · the living record thickens unevenly'));
  // Fine reaches start from unequal heights and sometimes cross back through the central record.
  for(let i=0;i<58;i++){
    const u=.08+seed(i,501)*.84;
    const sy=mix(550,349,u),sx=558+(seed(i,502)-.5)*7;
    const side=seed(i,503)>.47?1:-1;
    const reach=24+Math.pow(seed(i,504),.7)*89;
    const rise=(seed(i,505)-.28)*74;
    const ex=sx+side*reach,ey=sy-rise;
    const cx=mix(sx,ex,.54)+side*(seed(i,506)-.5)*18;
    const cy=mix(sy,ey,.46)+(seed(i,507)-.5)*17;
    const bright=i%13===0;
    ops.push(bezier([sx,sy],[cx,cy],[ex,ey],bright?bone:(i%4===0?steel:amber),
      .22+seed(i,508)*.34,'pencil',.2+seed(i,509)*.35,'line',.035));
    if(i%9===0)ops.push(DOT(ex,ey,.65+seed(i,510)*1.7,'accent',bright?'chalk':'soft',bright?bone:amber,.32+seed(i,511)*.34));
  }
  // Compressed knots are small local events, not evenly spaced beads.
  const knots=[[548,466,13],[570,439,9],[555,505,11],[584,481,7]];
  knots.forEach(([cx,cy,n],j)=>{
    for(let i=0;i<n;i++){
      const a=seed(i,540+j*7)*Math.PI*2,r=2+Math.pow(seed(i,541+j*7),1.5)*(10+j*2);
      ops.push(DOT(cx+Math.cos(a)*r,cy+Math.sin(a)*r*.62,.45+seed(i,542+j*7)*1.35,
        'accent',i%6===0?'chalk':'soft',i%5===0?bone:amber,.25+seed(i,543+j*7)*.42));
    }
  });
  // A few extremely fine reaches touch the reflected field and disappear.
  const whispers=[[[505,404],[476,382],[451,359]],[[601,390],[633,359],[652,325]],[[612,516],[643,534],[666,528]],[[496,515],[461,536],[438,529]]];
  whispers.forEach((p,i)=>ops.push(stroke(p,i===1?bone:steel,.2+(i===1?.08:0),'pencil',.28+(i===1?.16:0),'line',.025)));

  // Re-anchor the existing quiet caretaker without enlarging it.
  for(let i=0;i<9;i++){
    const y=751+i*2.4,fade=1-i/9;
    ops.push(stroke([[654-i,y],[714,y+1],[781+i,y-3]],night,1.8,'soft',.25*fade,'line',.055));
  }
  ops.push(bezier([679,769],[711,776],[751,764],ember,.5,'glaze',.17,'line',.055));
  ops.push(PAUSE(900));
  return ops;
}

function settleTheReflection(){
  const ops=[PHASE('09 · reflection follows the vessel')];
  // Oblique feathering joins the vertical field to the curved glass instead of a rectangular panel.
  for(let i=0;i<16;i++){
    const y=355+i*12;
    const inset=Math.abs(i-7.5)*5;
    ops.push(bezier([458+inset,y],[546,y+15-Math.sin(i*.7)*8],[661-inset*.6,y-5],
      i%5===0?steel:violet,1.35+(i%3)*.32,'glaze',.065+(i%4)*.012,'line',.06));
  }
  // Uneven night paint breaks the straight upper termination while leaving a subdued field below.
  const upper=[[[456,338],[492,345],[520,341]],[[533,342],[558,350],[579,344]],[[612,345],[638,338],[661,346]]];
  upper.forEach((p,i)=>ops.push(stroke(p,night,2.5+i*.35,'soft',.52,'line',.055)));
  // A faint curved return at the field's lower edge follows the vessel's belly.
  ops.push(bezier([471,536],[552,568],[648,531],steel,.58,'soft',.24,'line',.055));

  // The far-right record should be found by two reflections, not a complete boundary.
  ops.push(stroke(podPoly(1200,430,70,116),night,3.4,'soft',.94,'line',.02));
  ops.push(ellipse(1200,430,67,112,steel,.32,'pencil',.23,'line',-1.22,-.55));
  ops.push(ellipse(1200,430,67,112,steel,.26,'pencil',.18,'line',1.12,1.62));
  ops.push(DOT(1172,385,.9,'line','soft',bone,.22));
  ops.push(PAUSE(800));
  return ops;
}

function loseTheInnerRims(){
  const ops=[PHASE('10 · sleepers lose their inner rims')];
  const sleepers=[[765,366,83,137],[918,318,58,94],[1070,357,47,78],[1200,430,70,116],[1018,552,96,155]];
  for(const [cx,cy,rx,ry] of sleepers){
    // These match the two original pod edge constructions exactly and repaint them into night.
    ops.push(ellipse(cx-5,cy+2,rx*.92,ry*.985,night,2.75,'soft',.94,'line',.15,Math.PI*1.08));
    ops.push(ellipse(cx+3,cy,rx*.88,ry*.96,night,2.65,'soft',.94,'line',Math.PI*1.12,Math.PI*2+.08));
  }
  const glints=[
    [[698,343],[707,314],[724,292]],[[875,279],[889,263],[905,258]],
    [[1034,323],[1042,301],[1054,288]],[[1171,489],[1186,500],[1198,494]],
    [[946,610],[957,639],[978,664]],
  ];
  glints.forEach((p,i)=>ops.push(stroke(p,i===0?steel:deep,.28+(i===0?.12:0),'pencil',.2+(i===0?.1:0),'line',.025)));
  ops.push(PAUSE(700));
  return ops;
}

const passes=[
  {name:'The room and suspended records',note:'A closed service hall recedes toward a quiet door. Six archive vessels hang at different depths; only the nearest is awake, its branching record lit from within.',review:{observation:'The depth sequence and amber foreground vessel read, but continuous oval rims make the vessels diagrammatic and the two bright ceiling rails compete with the focal record.',change:'Initial spatial construction and suspended records.',next:'Develop the foreground material and give the caretaker a task.',region:[390,190,820,500]},build:roomAndGarden},
  {name:'Glass and the caretaker',note:'The awake vessel bends room seams through its body. A small wheeled caretaker reaches into it with an articulated inspection arm.',review:{observation:'The awake record and caretaker relationship reads, but distant vessels remain similarly bounded, original rails still dominate, and glass depends too much on its outline.',change:'Added broken glints, internal crossings and fragments, the caretaker, and local floor reflection.',next:'Repaint the complete rails and distant rims into the room, then rebuild only selective evidence; establish the awake vessel with a broad reflected field and much finer unequal growth.',region:[390,250,870,570]},build:glassAndCaretaker},
  {name:'Reflected field and unequal sleep',note:'The original rails and distant bounds are repainted into the room before selective fragments return. A broad cool-violet field and bent warm band hold the awake glass, while dense irregular reaches and compressed knots replace the sparse branch symbol.',review:{observation:'The rails now recede and the awake vessel has a visible reflected body with dense irregular growth. At close scale the vertical strokes end along a nearly rectangular upper edge, making the field resemble a lit panel; the far-right sleeper also retains too much oval boundary.',change:'Repainted full rail and rim paths, restored unequal fragments and hairline suspension, layered a broad reflected field, added 58 irregular reaches, four compressed knots, and four disappearing whispers.',next:'Feather the field obliquely, break its straight top termination with same-layer night paint, and reduce the far-right rim to two small glass cues.',region:[390,245,890,570]},build:materialReconstruction},
  {name:'Reflection follows the vessel',note:'Oblique feathering and an uneven upper loss turn the cool field with the glass rather than leaving it as a panel. The far-right sleeper is almost entirely lost, held by two reflections and one dim point.',review:{observation:'The broad field is now subordinate to the warm living core and the rails recede. Several sleeping vessels still read as complete eggs because the original inner near/far ellipse strokes remain after the outer silhouettes were repainted.',change:'Added sixteen low oblique glazes, three uneven upper repaint strokes, one curved lower return, and repainted the far-right rim before restoring two short cues.',next:'Repaint the exact original inner rim arcs for every sleeper and restore only one isolated glint per vessel.',region:[410,245,850,570]},build:settleTheReflection},
  {name:'Sleepers lose their inner rims',note:'The original near and far inner ellipses are repainted into the room. One small cold trace per vessel remains, so the garden is inferred from suspension, interior records, and occasional glass rather than outlined eggs.',review:{observation:'Inspect whether the foreground awake vessel is now the only substantially bounded form and whether the sleeping garden remains discoverable without repeating its silhouette.',change:'Repainted both original inner rim arcs on five sleeping vessels and restored five unequal isolated traces.',next:'If the final whole and detail preserve spatial legibility and the caretaker’s relationship, select this checkpoint for review.',region:[390,180,900,650]},build:loseTheInnerRims},
];

export default{title:'Night maintenance · reflected field',date:'2026-09-07',refs:[2],page:{w:1500,h:950},note:'A substantive branch from page 2. The room and sleeping vessels are repainted into darkness so the awake glass can be carried by reflection, interior pressure, and the caretaker’s quiet attention rather than outlines.',passes,build:()=>passes.flatMap(p=>p.build())};
