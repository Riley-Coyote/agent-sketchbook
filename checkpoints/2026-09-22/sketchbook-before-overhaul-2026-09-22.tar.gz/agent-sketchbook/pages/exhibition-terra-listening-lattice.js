/*
 * The Listening Lattice — a first study in a held, rather than embodied, mind.
 * All light is laid down as native stamped marks; the darkness is allowed to do
 * most of the containing.  Two pass builders make the initial construction and
 * the delicate signal structure separately so the next correction can be honest.
 */
import { OP, DOT, PHASE, PAUSE, CLAMP, arc, jitter, seed } from '../mark-engine.js';

const W = 1400, H = 940;
const C = {
  night: [18, 23, 32], cold: [91, 126, 157], pale: [174, 202, 214],
  blue: [66, 104, 139], ember: [225, 164, 99], emberPale: [248, 209, 148],
  ash: [118, 132, 145], deep: [10, 13, 19],
};
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const pt = (x, y) => [x, y];
const path = (f, n = 36) => Array.from({ length: n + 1 }, (_, i) => f(i / n));
const stroke = (pts, layer = 'line', brush = 'soft', w = 1, c = C.pale, a = 1, wob = .16) =>
  OP('s', jitter(pts, wob), layer, brush, w, c, a);
const line = (x1, y1, x2, y2, ...rest) => stroke([pt(x1, y1), pt((x1 + x2) / 2, (y1 + y2) / 2), pt(x2, y2)], ...rest);
const ellipse = (x, y, rx, ry, ...rest) => stroke(arc(x, y, rx, ry, 0, Math.PI * 2, Math.max(28, Math.round(rx / 4))), ...rest);
const egg = (cx, cy, rx, ry, t, inset = 0) => path(u => {
  const a = u * Math.PI * 2;
  const swell = 1 - .16 * Math.cos(a) + .06 * Math.sin(a * 2);
  return [cx + Math.cos(a) * (rx - inset) * swell + t * (u - .5) * 22,
    cy + Math.sin(a) * (ry - inset)];
}, 72);

function chamber() {
  const o = [PHASE('01 · finding a chamber large enough for a signal')];
  // An almost-black field gets a very low, uneven veil so it has air, not a flat screen.
  for (let y = 58; y < H - 46; y += 19) {
    for (let x = 55; x < W - 55; x += 86) {
      const dx = (x - 700) / 700, dy = (y - 445) / 520;
      const near = Math.exp(-(dx * dx * 1.6 + dy * dy * .75));
      o.push(line(x, y, x + 92, y + Math.sin(x * .014 + y * .019) * 2,
        'tone', 'glaze', 1.35, mix(C.night, C.blue, .12 + near * .24), .19));
    }
  }
  // Perspective ribs establish a deep, deliberately incomplete enclosure.
  const V = [700, 470];
  for (let i = 0; i < 25; i++) {
    const a = -1.08 + i * .09;
    const ex = 700 + Math.cos(a) * 700, ey = 470 + Math.sin(a) * 510;
    const side = Math.abs(Math.cos(a));
    o.push(line(V[0], V[1], ex, ey, 'under', 'pencil', .54, C.ash, .16 + side * .12, .11));
  }
  for (let r = 0; r < 9; r++) {
    const rx = 146 + r * 89, ry = 93 + r * 57;
    o.push(ellipse(700, 470, rx, ry, 'under', 'pencil', .48, C.ash, .11 + r * .012, .12));
  }
  // Broad wall shadows: intentionally broken so the room recedes without becoming a tunnel diagram.
  for (let i = 0; i < 50; i++) {
    const u = seed(i, 11), side = i % 2 ? -1 : 1;
    const x = 700 + side * (260 + u * 350), y = 160 + seed(i, 12) * 610;
    const L = 46 + seed(i, 13) * 176;
    o.push(line(x, y, x + side * L, y + (seed(i, 14) - .5) * 24,
      'tone', 'glaze', 1.7, C.deep, .42));
  }
  o.push(PHASE('the held interior')); 
  // Nested shell: outer shell stays quiet; its incomplete apertures make the mind feel permeable.
  for (let k = 0; k < 23; k++) {
    const inset = k * 5.0;
    const col = mix(C.blue, C.pale, k / 32);
    o.push(stroke(egg(700, 470, 255, 330, 1, inset), 'line', 'soft', .86, col, .12 + k * .012, .12));
  }
  // Erased fissures keep the edge from resolving into a single hard object.
  for (const [a0, a1] of [[.43,.55],[2.25,2.42],[3.83,4.06],[5.25,5.43]]) {
    o.push(stroke(arc(700, 470, 255, 330, a0, a1, 24), 'line', 'eraser', 1.55, undefined, .82, .05));
  }
  // Local inner atmosphere; it is brightest near the lower left of the core, not centered.
  for (let j = 0; j < 36; j++) {
    const y = 250 + j * 12.8;
    const span = Math.sqrt(Math.max(0, 1 - ((y - 470) / 270) ** 2)) * 190;
    const shift = -32 + (y - 470) * .10;
    for (let x = 700 - span; x < 700 + span; x += 44) {
      const glow = Math.exp(-(((x - 636) / 128) ** 2 + ((y - 555) / 146) ** 2));
      o.push(line(x, y, Math.min(700 + span, x + 52), y,
        'tone', 'soft', 1.24, mix(C.blue, C.pale, glow * .48), .11 + glow * .22));
    }
  }
  o.push(CLAMP('tone', .4), PAUSE(700));
  return o;
}

function signalAndLattice() {
  const o = [PHASE('02 · allowing a thought to arrive in fragments')];
  // A small warm signal is built from irregular rings, displaced inside the colder enclosure.
  for (let r = 36; r > 5; r -= 3.1) {
    const wob = .8 + (36 - r) * .03;
    const ring = path(u => {
      const a = u * Math.PI * 2;
      return [634 + Math.cos(a) * r * (1 + .09 * Math.sin(a * 3 + r)),
        555 + Math.sin(a) * r * .72 * (1 + .07 * Math.cos(a * 5 - r))];
    }, 34);
    o.push(stroke(ring, 'accent', 'soft', .68, mix(C.ember, C.emberPale, 1 - r / 42), .22, wob));
  }
  o.push(DOT(633, 554, 8.6, 'accent', 'soft', C.emberPale, .92));
  o.push(DOT(626, 547, 2.0, 'accent', 'pencil', [255, 230, 181], .82));
  // Filaments never all meet: their omissions are the image's cognitive uncertainty.
  for (let i = 0; i < 54; i++) {
    const a = seed(i, 31) * Math.PI * 2;
    const startR = 44 + seed(i, 32) * 18;
    const endR = 140 + seed(i, 33) * 150;
    const bend = (seed(i, 34) - .5) * 72;
    const sx = 634 + Math.cos(a) * startR, sy = 555 + Math.sin(a) * startR * .78;
    const ex = 700 + Math.cos(a) * endR, ey = 470 + Math.sin(a) * endR * .93;
    const nx = -Math.sin(a), ny = Math.cos(a);
    const split = .31 + seed(i, 35) * .42;
    const mid = [sx + (ex - sx) * split + nx * bend, sy + (ey - sy) * split + ny * bend];
    const col = i % 5 === 0 ? C.ember : mix(C.cold, C.pale, seed(i, 36) * .35);
    // Keep an actual gap between the signal and each outer fragment.
    o.push(stroke([[sx, sy], [mid[0], mid[1]]], 'line', 'pencil', .58 + seed(i, 37) * .28, col, .32 + seed(i, 38) * .26, .10));
    if (i % 3 !== 0) o.push(stroke([[mid[0] + nx * 5, mid[1] + ny * 5], [ex, ey]], 'line', 'pencil', .42 + seed(i, 39) * .24, col, .18 + seed(i, 40) * .31, .10));
  }
  // The lattice has intervals of silence and small contained flashes, with a denser lower plane for depth.
  for (let i = 0; i < 186; i++) {
    const a = seed(i, 51) * Math.PI * 2;
    const rr = 300 + seed(i, 52) * 312;
    const x = 700 + Math.cos(a) * rr, y = 470 + Math.sin(a) * rr * .73;
    if (x < 64 || x > W - 64 || y < 58 || y > H - 56) continue;
    const lower = y > 510 ? .3 : 0;
    const col = seed(i, 53) > .92 ? C.ember : mix(C.cold, C.ash, seed(i, 54));
    o.push(DOT(x, y, .45 + seed(i, 55) * 1.5, 'accent', 'soft', col, .16 + lower + seed(i, 56) * .29));
    if (i % 7 === 0) {
      const tx = x + (seed(i, 57) - .5) * 31, ty = y + (seed(i, 58) - .5) * 23;
      o.push(line(x, y, tx, ty, 'line', 'pencil', .4, col, .19));
    }
  }
  // A few foreground bands interrupt the view: the chamber is not a diagram floating in void.
  for (let i = 0; i < 17; i++) {
    const y = 702 + i * 10.5;
    const x0 = 78 + seed(i, 71) * 180;
    const x1 = 1090 + seed(i, 72) * 210;
    o.push(line(x0, y, x1, y - 27 - i * .42, 'accent', 'soft', 1.2, C.night, .28));
  }
  // Selective cold highlights locate the shell's near lip; they do not close the form.
  for (const [a0,a1,alpha] of [[4.26,5.03,.74],[5.58,5.97,.38],[1.06,1.38,.26]]) {
    o.push(stroke(arc(700, 470, 254, 329, a0, a1, 38), 'accent', 'pencil', .88, C.pale, alpha, .08));
  }
  o.push(PAUSE(1100));
  return o;
}

const passes = [
  { name: 'Chamber and held interior', note: 'Built a dim, incomplete enclosure and a displaced local glow. I want the shell to feel like a listening threshold rather than a vessel.', review: { observation: 'At fit view, check whether the shell reads as deep and permeable rather than as a centered egg icon.', change: 'Use weak receding ribs, broken wall veils, nested edge marks, and an off-centre internal atmosphere.', next: 'Inspect the lower foreground bands and the shell’s right edge at detail scale before deciding whether they need subtraction or a stronger occlusion.', region: [300, 130, 800, 700] }, build: chamber },
  { name: 'Signal, interrupted filaments, near lattice', note: 'A warm, incomplete signal reaches toward a colder lattice. The filament gaps are deliberate: this is a mind in the act of becoming addressable, not a solved network diagram.', review: { observation: 'Check whether the warm point holds attention without making the image read as a target; inspect whether the foreground bands bury too much of the lattice.', change: 'Use small irregular warm rings, split paths with air between them, and low-density peripheral marks.', next: 'If the reading is too diagrammatic, revise by quieting repeated radial lines and strengthening one asymmetric near-plane interruption.', region: [470, 235, 490, 500] }, build: signalAndLattice },
];

export default {
  title: 'The Listening Lattice', date: '2026-09-07', page: { w: W, h: H },
  note: 'A first study of a digital mind as a threshold that can be addressed before it can be fully seen. The central signal may be too isolated, and the enclosing ribs may still announce their construction too clearly. I need to inspect whether the lower interruption gives depth or simply darkens the drawing.',
  passes, build: () => passes.flatMap(p => p.build()),
};
