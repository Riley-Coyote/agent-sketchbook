import { PHASE, mark, line, curve, oval, hatch, plane, dust, clipped, pts } from './aperture-codex-hand.js';
const W=1200,H=1600;
export default {title:'The Witness That Cannot Wake · final rework',date:'2026-09-07',page:{w:W,h:H},note:'The material versions kept turning the sitter into a diagram. I changed hands: this one is built from fine, curved MarkEngine strokes. I kept the head blank and made the body legible through the way the cloth turns around the collarbones, elbows, and tray. The back shoulder still vanishes a little too politely into the attendant shadow.',build:()=>{const o=[PHASE('placing the quiet room')];
 const table=[[78,1210],[1108,1130],[1160,1510],[42,1550]];plane(o,table,58,3);dust(o,table,330,9,110);
 o.push(PHASE('the shadow that remains after watching'));
 const ghost=[[723,410],[827,373],[923,458],[955,702],[901,1055],[755,1088],[676,891],[680,599]];hatch(o,ghost,74,5,.2,11,'pencil');o.push(mark([...ghost,ghost[0]],92,.5,'pencil',.45));
 o.push(PHASE('drapery before the face'));
 const body=[[198,770],[322,680],[477,708],[604,813],[714,1038],[646,1190],[489,1280],[281,1204],[143,1038]];hatch(o,body,132,3.5,.42,22,'soft');hatch(o,body,80,7,-.7,23,'pencil');
 // shoulder-to-lap contour currents, intentionally unequal and curved
 for(let i=0;i<94;i++){const t=i/93; o.push(mark(curve([190,805+i*3],[330,740+i*7],[505,786+i*3],[666,1024+i*1]),115+i*.45,.56,'pencil',.72));}
 for(let i=0;i<47;i++)o.push(mark(curve([260+i*2,788],[345+i*1,875],[394+i*2,997],[477+i*1,1198]),70+i*.7,.62,'charcoal',.68));
 for(let i=0;i<31;i++)o.push(mark(curve([533,792+i*2],[596,858+i*4],[630,968+i*2],[660,1070+i]),150,.52,'pencil',.74));
 // neck and head: a blank plane is surrounded by modeled, angled hatch paths
 for(let i=0;i<39;i++)o.push(mark(curve([355+i*2,690],[377+i*2,650],[437+i*2,651],[476+i*1,734]),120,.62,'soft',.72));
 const head=[...oval(435,495,177,244,.17)];
 for(let i=0;i<106;i++){const y=294+i*4.05, dy=(y-495)/244, half=177*Math.sqrt(Math.max(.02,1-dy*dy)); const a=[435-half*.94,y],d=[435+half*.86,y+8];o.push(mark(curve(a,[350,y-28],[479,y+35],d), i<52?80:139,.48,'pencil',.72));}
 // face is literally left unmarked, with only a lifted perimeter suggested by chalk
 o.push(mark(curve([372,406],[437,351],[532,410],[548,548]),172,.6,'chalk',.35));o.push(mark(curve([548,548],[521,640],[432,672],[367,604]),150,.55,'chalk',.28));
 // distinct locks follow skull rather than a scribble cap
 for(let i=0;i<29;i++){const x=290+i*10,y=405-(i%5)*13;o.push(mark(curve([x,y],[x+18,y-70],[x+55,y-41],[x+34,y+38]),75,.7,'charcoal',.8));}
 o.push(PHASE('tray, sleeves, and small weather'));
 const tray=[[216,1119],[850,1061],[984,1193],[328,1272]];plane(o,tray,105,35);for(let i=0;i<44;i++)o.push(mark(curve([255,1141+i],[459,1112+i*-.3],[705,1102+i*-.1],[914,1165+i*.3]),138,.42,'pencil',.56));
 // sleeve ends and quiet hands support its near and far edges
 for(let i=0;i<27;i++){o.push(mark(curve([196,982+i*4],[264,1026+i*2],[327,1080],[416,1122]),156,.55,'soft',.72));o.push(mark(curve([632,941+i*3],[716,991+i],[792,1051],[862,1081]),142,.52,'soft',.68));}
 for(let i=0;i<10;i++){o.push(line([365+i*8,1118+i],[415+i*5,1122+i],185,.42,'pencil',.75));o.push(line([807+i*6,1088-i],[854+i*4,1082-i],174,.42,'pencil',.75));}
 for(let i=0;i<24;i++)o.push(line([306+i*5,1150],[307+i*5,1165+(i%5)*4],180,.42,'chalk',.7));
 for(let i=0;i<18;i++)o.push(mark(pts(t=>[489+t*92,1180+Math.sin(t*3.14)*18+i*.25],22),164,.4,'chalk',.62));
 for(let i=0;i<29;i++)o.push(mark(pts(t=>[656+t*120,1168+Math.sin(t*3.14)*12+i*.2],21),158,.38,'pencil',.65));
 for(let i=0;i<45;i++)o.push(line([799+(i%9)*10,1128+Math.floor(i/9)*14],[806+(i%9)*10,1126+Math.floor(i/9)*14],150,.32,'chalk',.5));
 return o;}};
