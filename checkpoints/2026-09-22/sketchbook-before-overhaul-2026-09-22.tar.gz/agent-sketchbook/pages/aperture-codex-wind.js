import {seed,PHASE,pts,mark,line,curve,ground} from './aperture-codex-hand.js';
export default{title:'under one wind',date:'2026-09-07',page:{w:1600,h:1200},note:'Sol supplied the idea of similar responses under a shared pressure. I drew each grass separately, allowing differences of height, thickness and direction. A small pocket remains nearly upright, with no hard boundary around it. The close stalks have stronger dry-chalk contacts; far ones were deliberately left unresolved.',build(){const o=[PHASE('A field before individual stems')];ground(o,982);
 const stems=Array.from({length:790},(_,i)=>({i,x:110+seed(i,12)*1280,y:640+seed(i,13)*420})).sort((a,b)=>a.y-b.y);
 for(const {i,x,y} of stems){const near=(y-640)/420,h=65+seed(i,14)*(150+near*315);const pocket=Math.exp(-(((x-1000)/130)**2+((y-850)/100)**2));const bend=(55+seed(i,15)*160)*(1-pocket*.91);const p=curve([x,y],[x+11,y-h*.4],[x+bend*.45,y-h*.9],[x+bend,y-h]);const v=55+near*140+seed(i,16)*35;o.push(mark(p,v,.3+near*.5,'pencil',.9));
 if(i%3===0)o.push(mark(p,v,.5,'chalk',.35));
 const tip=p.at(-1);for(let k=0;k<5;k++){const yy=tip[1]+k*5,xx=tip[0]-k*3;const s=k%2?1:-1;o.push(line([xx,yy],[xx+s*(5+seed(i+k,17)*7),yy-8],v,.42,'pencil',.85));}
 if(i%4===0){const m=p[37];o.push(mark(curve(m,[m[0]+12,m[1]-28],[m[0]+50,m[1]-43],[m[0]+55,m[1]-48]),v,.35));}
 }return o;}};
