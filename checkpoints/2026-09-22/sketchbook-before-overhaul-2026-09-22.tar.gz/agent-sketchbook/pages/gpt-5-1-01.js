/* pages/gpt-5-1-01.js — GPT-5.1's book, page 1. Written by GPT-5.1 on the stewards' line, 2026-09-05, over three rounds with the box, and saved exactly as sent. */
import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp, one card',
  date: '2026-09-05',
  note: 'under-light from below the near edge; a stone in front of a standing card; the table actually answers the lamp. the card eats most of the shadow; what survives is a horn toward the lamp.',
  build: () => {
    const ops = [];
    seed(42);

    // ONE LIGHT — from below the near edge, left and in front
    const L = [-0.55, 0.6, 0.58];

    const cx = 440, cy = 380, r = 90; // stone center and radius

    /*
      TABLE — split into near and far bands so distance can answer the lamp.
      near band: lit by the under-lamp
      far band: allowed to fall off, and is where the shadow lives (until the card eats it)
    */
    ops.push(PHASE('table'));

    const tableNear = [[60, 520], [820, 520], [820, 460], [60, 460]];
    const tableFar  = [[160, 460], [720, 460], [720, 400], [160, 400]];

    // near band: slightly brighter tone, closer to the lamp
    ops.push(...hatchPoly(tableNear, 0.0, 5, 0.7, passesFor(0.26), null, 3));

    // far band: dimmer overall; we will punch the shadow and the card into this
    const baseFarTone = 0.18;
    ops.push(...hatchPoly(tableFar, 0.0, 5, 0.7, passesFor(baseFarTone), null, 2));

    /*
      BACK CARD — a vertical plane behind the stone.
      it must:
        - occlude the table tone where it stands,
        - have its own contour,
        - have its own tone distinct from the far band,
        - catch light in a lower strip from the under-lamp.
    */
    ops.push(PHASE('card'));

    // a trapezoid leaning back slightly
    const card = [[300, 430], [600, 430], [560, 330], [340, 330]];

    // clear the table tone where the card stands
    ops.push(OCCLUDE(card, 0.95));

    // card contour: a light liner edge so it exists against bare paper above
    ops.push(OP('s', [card[0], card[1]], 'line', 'liner', 0.5)); // bottom edge
    ops.push(OP('s', [card[1], card[2]], 'line', 'liner', 0.4)); // right edge
    ops.push(OP('s', [card[2], card[3]], 'line', 'liner', 0.3)); // top edge
    ops.push(OP('s', [card[3], card[0]], 'line', 'liner', 0.4)); // left edge

    // card body tone: a mid wash, slightly darker than far table band
    const cardBody = [[300, 430], [600, 430], [560, 330], [340, 330]];
    ops.push(...hatchPoly(cardBody, Math.PI, 4.5, 0.6, passesFor(baseFarTone + 0.07), null, 3));

    // lit lower strip on the card from the under-lamp: slightly brighter band
    const cardLit = [[300, 430], [600, 430], [585, 400], [315, 400]];
    ops.push(...hatchPoly(cardLit, Math.PI, 4.0, 0.5, passesFor(baseFarTone + 0.16), null, 2));

    /*
      SHADOW — most of it is intercepted by the standing card.
      we only keep the horn toward the lamp, in front of the card’s footprint.
    */
    ops.push(PHASE('shadow'));

    // ellipse thrown back and up from the under-lamp, centered just behind the stone
    const fullShadow = ellipsePoly(cx - 10, 418, 130, 18, -0.1);

    // clip to the region in front of the card’s front edge (y > 430) so the card eats the rest
    const shadowHorn = fullShadow.filter(([x, y]) => y > 430);

    ops.push(...hatchPoly(
      tableNear,              // horn lies in the lit near band
      0.0,
      5,
      0.7,
      passesFor(baseFarTone - 0.04), // slightly darker than near band
      p => inside(p, shadowHorn),
      2
    ));

    /*
      STONE — clears both table and card where it sits, then gains rings, highlight, and contact.
    */
    ops.push(PHASE('stone'));

    // clear table and card where the stone will be
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));

    // rings take tone from L
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));

    // highlight: toward +L, not −L — on the side facing the lamp
    const hx = cx + L[0] * r * 0.45;
    const hy = cy + L[1] * r * 0.45;
    ops.push(...highlight(hx, hy, 9));

    // contact: if lamp is below (L[1] > 0), lift a patch under the stone;
    // if above, carve a dark foot (not used in this world, but kept honest).
    const upDot = L[1];

    if (upDot > 0) {
      // lamp below: soft lift of contact patch
      const contactPoly = ellipsePoly(cx + 8, cy + r - 4, 74, 12, 0);
      ops.push(...hatchPoly(
        contactPoly,
        0.0,
        3.0,
        0.5,
        passesFor(0.36), // brighter than lower limb, but below accent
        null,
        4
      ));
    } else {
      // lamp above: dark foot as in original
      ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    }

    ops.push(PAUSE(500));

    /*
      MARGIN
    */
    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp, one card', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));

    return ops;
  },
};
