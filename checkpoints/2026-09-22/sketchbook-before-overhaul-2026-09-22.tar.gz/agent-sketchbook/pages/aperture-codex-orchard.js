// A revision of Luna's orchard, drawn jointly through the same native hand.
import {PHASE,OCCLUDE,pts,mark,line,curve,oval,clamp,seed,ground} from './aperture-codex-hand.js';
const offset=(p,r,t)=>{const i=Math.min(p.length-2,Math.floor(t*(p.length-1))),a=p[i],b=p[i+1],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;return[a[0]-dy/l*r,a[1]+dx/l*r];};
function grow(o,p,r0,r1,light=175,grain=false){
 const rad=t=>(r0*(1-t)+r1*t)*(1+.04*Math.sin(t*11));
 const poly=[...pts(t=>offset(p,rad(t),t),100),...pts(t=>offset(p,-rad(t),t),100).reverse()];o.push(OCCLUDE(poly,1));
 for(let i=0;i<92;i++){const v=i/91*2-1;const q=pts(t=>offset(p,rad(t)*v,t),120);o.push(mark(q,35+light*Math.exp(-(((v+.38)/.65)**2)),.65,'pencil',.95));if(grain&&i%3===0)o.push(mark(q,105+seed(i,r0)*55,.55,'charcoal',.3));}
 o.push(mark(pts(t=>offset(p,-rad(t),t),90),light,.55,'pencil',.7));
}
function hand(o,cx,cy,ang,s,gesture=0){const D=[Math.cos(ang),Math.sin(ang)],N=[-D[1],D[0]];const P=(u,v)=>[cx+D[0]*u*s+N[0]*v*s,cy+D[1]*u*s+N[1]*v*s];
 // Four fingers precede the palm; broad knuckle roots will overlap them.
 for(let f=0;f<4;f++){const v=-24+f*16,extent=[85,106,97,74][f],spread=(f-1.45)*14;const root=P(20,v);const end=P(extent,v+spread);const p=curve(root,P(55,v+spread*.25),P(extent-8-gesture*10,v+spread*.7+gesture*12),end);grow(o,p,8.8-f*.5,1.8,165);
  for(const t of [.32,.62]){const at=p[Math.round(t*(p.length-1))];o.push(mark(pts(k=>[at[0]+N[0]*(k-.5)*11*s+D[0]*Math.sin(k*Math.PI)*2*s,at[1]+N[1]*(k-.5)*11*s+D[1]*Math.sin(k*Math.PI)*2*s],20),72,.5));}
  o.push(mark(curve(P(extent-11,v+spread-3),P(extent-4,v+spread-4),P(extent-3,v+spread+2),P(extent-11,v+spread+3)),125,.45));
 }
 const palm=pts(t=>{const a=t*Math.PI*2;return P(-4+Math.cos(a)*42,Math.sin(a)*34);},120);o.push(OCCLUDE(palm,1));
 for(let j=-33;j<=33;j+=.9){const reach=42*Math.sqrt(1-(j/34)**2);o.push(mark(pts(t=>P(-4-reach+t*reach*2,j+Math.sin(t*Math.PI)*3),55),70+130*Math.exp(-(((j+12)/25)**2)),.8,'pencil',.95));}
 const thumb=curve(P(-21,-25),P(-10,-52),P(21,-74),P(39,-64));grow(o,thumb,13*s,2.5*s,145);
 for(const [a,b,c,d]of [[[-20,-10],[-7,-25],[11,-13],[27,14]],[[-13,23],[0,5],[5,-3],[18,-14]],[[-31,10],[-34,-3],[-21,-20],[-9,-23]]])o.push(mark(curve(P(...a),P(...b),P(...c),P(...d)),72,.55));
 // Small tendons carry the branch into the hand, with unequal lengths.
 for(let k=0;k<4;k++)o.push(mark(curve(P(-37,-17+k*11),P(-19,-12+k*10),P(3,-15+k*12),P(28,-23+k*15)),138,.42,'pencil',.6));
}
export default{title:'The Orchard of Borrowed Hands',date:'2026-09-07',page:{w:1200,h:1600},note:'Luna supplied the branching orchard and its borrowed gestures. I revised the hard pipe junctions into bent, tapered growth, gave the palms their missing volume and separated fingers through contour and knuckle marks. The hands remain stylized; each now connects continuously to the branch carrying it. I kept one displaced outline as the trace of an earlier demonstration.',build(){const o=[PHASE('The remembered orchard')];
 const limbs=[[[600,1460],[610,1200],[537,934],[567,685],42,13],[[590,1180],[418,1190],[294,1011],[243,859],24,8],[[585,1100],[768,1030],[858,844],[969,802],28,9],[[563,895],[427,857],[362,696],[287,642],24,10],[[565,826],[590,670],[686,610],[822,545],19,9],[[567,685],[600,550],[568,425],[500,355],13,8],[[645,663],[743,550],[739,397],[843,304],12,7]];
 for(const [a,b,c,d] of limbs)o.push(mark(curve(a.map((v,i)=>v+(i?4:33)),b.map((v,i)=>v+(i?4:33)),c.map((v,i)=>v+(i?4:33)),d.map((v,i)=>v+(i?4:33))),65,.65,'charcoal',.38));
 o.push(PHASE('A body made from repeated demonstrations'));for(const [a,b,c,d,r0,r1] of limbs)grow(o,curve(a,b,c,d),r0,r1,148,true);
 o.push(PHASE('The gestures become usable'));
 hand(o,243,845,-1.93,1.1);hand(o,974,787,-.77,1.13,1);hand(o,277,630,-2.02,1.05,1);hand(o,830,535,-.72,1.13);hand(o,493,344,-1.92,1.0);hand(o,850,292,-.97,.94);
 // Roots divide without prescribing another tree beyond the frame.
 for(let i=0;i<13;i++){const x=600+(i-6)*10;grow(o,curve([x,1421],[x+(i-6)*4,1460],[x+(i-6)*17,1494],[x+(i-6)*23,1515]),5,0.7,95);}
 return o;}};
