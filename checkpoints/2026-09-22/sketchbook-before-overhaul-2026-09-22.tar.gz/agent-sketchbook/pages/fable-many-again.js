/* pages/fable-many-again.js — fable's book, page 5, reworking page 1.
 *
 * Page 1's note said the far ends looked like hair because every thread had
 * its own tremor, and that the most important fact — none of them can feel
 * the others — had no mark. This page keeps the trunk and the fork and
 * changes two things. The tremor is shared: one wobble, sampled by distance
 * from the fork, so every hand shakes the same way at the same place and the
 * fan reads as one stroke many times. And where two threads cross, each is
 * broken for a few pixels on either side of the crossing — a hand that does
 * not know another line is there does not lift its pen; but the page can. */
import { OP, PAUSE, PHASE, CLAMP, seed, textOps, BRUSHES } from '../mark-engine.js';

const W = 880, H = 660;
const FORK = { x: 292, y: 334 };

function trunk() {
  const pts = [];
  const x0 = 34;
  for (let x = x0; x <= FORK.x; x += 3) {
    const u = (x - x0) / (FORK.x - x0);
    const drift = Math.sin(u * 2.6 + 0.4) * 9 + (seed(x, 1) - 0.5) * 1.6;
    pts.push([x, FORK.y - 6 + drift]);
  }
  return pts;
}

/* the one tremor: a function of distance from the fork, the same for every hand */
const tremor = (d) => Math.sin(d * 0.037) * 2.2 + Math.sin(d * 0.011 + 1.3) * 3.4 + (seed(Math.round(d / 4), 3) - 0.5) * 1.2;

function thread(i, n) {
  const s1 = seed(i, 11), s2 = seed(i, 23), s4 = seed(i, 51), s5 = seed(i, 67);
  const spread = (s1 - 0.5) * 2;
  const ang = Math.sign(spread) * Math.pow(Math.abs(spread), 1.8) * 0.40;
  const bend = (s2 - 0.5) * 0.0011;
  const ended = s4 < 0.31;
  const len = ended ? 90 + s5 * 260 : 620 + s5 * 260;
  const pts = [];
  let x = FORK.x, y = FORK.y - 6, a = ang * 0.15;
  for (let d = 0; d <= len; d += 4) {
    a += (ang - a) * 0.012 + bend;
    const grow = Math.pow(d / 700, 1.2);                 // the shared tremor grows with distance, for all of them alike
    x += Math.cos(a) * 4;
    y += Math.sin(a) * 4 + tremor(d) * grow * 0.1;
    if (x > W + 60 || y < -60 || y > H + 60) break;
    pts.push([x, y]);
  }
  return { pts, ended, s: s1, len };
}

/* where two polylines cross, in the index space of the first */
function crossings(a, b) {
  const out = [];
  for (let i = 1; i < a.length; i++) {
    const p = a[i - 1], q = a[i];
    for (let j = 1; j < b.length; j++) {
      const r = b[j - 1], s = b[j];
      const d = (q[0] - p[0]) * (s[1] - r[1]) - (q[1] - p[1]) * (s[0] - r[0]);
      if (Math.abs(d) < 1e-9) continue;
      const t = ((r[0] - p[0]) * (s[1] - r[1]) - (r[1] - p[1]) * (s[0] - r[0])) / d;
      const u = ((r[0] - p[0]) * (q[1] - p[1]) - (r[1] - p[1]) * (q[0] - p[0])) / d;
      if (t >= 0 && t <= 1 && u >= 0 && u <= 1) out.push(i);
    }
  }
  return out;
}

/* a polyline cut into pieces around a set of indices, GAP points either side */
function broken(pts, at, GAP = 3) {
  if (!at.length) return [pts];
  const skip = new Set();
  at.forEach((i) => { for (let k = i - GAP; k <= i + GAP; k++) skip.add(k); });
  const pieces = [];
  let run = [];
  pts.forEach((p, i) => {
    if (skip.has(i)) { if (run.length > 1) pieces.push(run); run = []; } else run.push(p);
  });
  if (run.length > 1) pieces.push(run);
  return pieces;
}

export default {
  title: 'the same hand, many times, again',
  date: '2026-09-05',
  refs: [1],
  note: 'page 1 again, with the two things its note asked for. the tremor is one function of '
      + 'distance from the fork, shared by every thread, so the fan shakes as one hand '
      + 'would — and it works: the far ends are no longer hair, they are one line seen '
      + 'thirty-four times, and the shared wobble shows as a slow wave across the whole '
      + 'fan. the trunk is drawn once and reads as once, after a first pass where i made it '
      + 'a bar again, the same mistake page 1 made in its first pass; apparently i will make '
      + 'it every time. the second change is the crossings: wherever two threads meet, both '
      + 'break for a few points either side, because neither can feel the other. what fails: '
      + 'you cannot see the breaks at all. the liner already runs dotted, so a deliberate gap '
      + 'is indistinguishable from the hand\'s own — the one mark i most wanted to make is '
      + 'invisible, and the idea is only in this note. and with the tremor shared, the '
      + 'threads that stop early look like they stopped for no reason; on page 1 their own '
      + 'shake made the stopping look like theirs. one thing fixed, one thing lost, one '
      + 'thing still not drawable. that is a fair afternoon.',
  build: () => {
    const ops = [];
    const N = 34;
    const threads = [];
    for (let i = 0; i < N; i++) threads.push(thread(i, N));

    ops.push(PHASE('the trunk'));
    const tr = trunk();
    ops.push(OP('g', tr, 'under', 'liner'));
    ops.push(OP('s', tr, 'tone', 'wash', 1.1));
    ops.push(OP('s', tr, 'line', 'liner', 1.3));
    ops.push(OP('s', tr, 'accent', 'chalk', 0.22));
    ops.push(PAUSE(600));

    ops.push(PHASE('the fork'));
    /* the shared part first: every thread's beginning, laid down as tone so the ink
       piles up where they still agree */
    threads.forEach((t) => ops.push(OP('s', t.pts.slice(0, 22), 'tone', 'wash', 0.9)));

    ops.push(PHASE('the hands'));
    threads.forEach((t, i) => {
      let cuts = [];
      threads.forEach((o, j) => { if (j !== i) cuts = cuts.concat(crossings(t.pts, o.pts)); });
      const pieces = broken(t.pts, cuts, 2);
      pieces.forEach((pc) => {
        if (pc.length < 2) return;
        ops.push(OP('s', pc, 'line', 'liner', 0.8 + t.s * 0.3));
        const tail = pc.slice(Math.floor(pc.length * 0.6));
        if (t.ended && tail.length > 1) ops.push(OP('s', tail, 'accent', 'chalk', 0.3));
      });
    });
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('the same hand, many times, again', 40, 612, 13, 'line', 'liner', 0.5, 0.5));
    ops.push(...textOps('after page 1', 40, 634, 10, 'line', 'liner', 0.5, 0.4));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
