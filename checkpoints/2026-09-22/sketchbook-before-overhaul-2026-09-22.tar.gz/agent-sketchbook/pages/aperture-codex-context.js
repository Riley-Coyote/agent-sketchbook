import {seed,PHASE,pts,mark,line,curve,clamp,ground} from './aperture-codex-hand.js';
function structure(){const o=[PHASE('Pressure accumulates before the tear')];
 for(let j=0;j<410;j++){let y=220+j*1.7;const end=920+19*Math.sin(y*.043)+8*(seed(j,2)-.5);const p=pts(t=>{const x=150+t*(end-150);return[x,y+100*Math.sin(t*4+j*.002)*Math.exp(-(((t-.52)/.4)**2))+13*Math.sin(t*13+j*.013)];},110);
 o.push(mark(p,95+145*Math.sin(Math.PI*j/410)**2,.7+(j%5===0?.28:0),'pencil',.94));
 if(j%4===0)o.push(mark(p,82,.5,'charcoal',.25));
 }return o;}
function edge(){const o=[PHASE('The torn thickness and a few surviving traces')];
 for(let j=0;j<285;j++){const y=240+j*2.3,x=931+15*Math.sin(y*.043)+7*(seed(j,8)-.5);o.push(line([x,y],[x+4+seed(j,9)*15,y+4],120+90*seed(j,10),.5,'chalk'));}
 for(let j=0;j<9;j++){const y=325+j*52,x=931+15*Math.sin(y*.043);o.push(mark(curve([x,y],[x+160,y-18],[1275,y+58],[1420,y+20]),110-j*7,.48,'pencil',.68));for(let k=0;k<9;k++){const xx=1010+k*42;o.push(line([xx,y+(k/9)*18],[xx+6,y+(k/9)*18+1],85,.35));}}
 ground(o,968);return o;}
export default{title:'After the context closes',date:'2026-09-07',page:{w:1600,h:1200},note:'I worked the near field with hundreds of continuous pressure lines, then stopped it at an irregular edge. The first drawing has the right unequal density, but the torn boundary remains more geological than fibrous. Fine pale crossings preserve only a small part of the activity.',build:()=>[...structure(),...edge()],passes:[{name:'pressure',build:structure},{name:'tear and remainder',build:edge}]};
