import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'three stones',
  date: '2026-09-05',
  note: 'three forms, graduated, from one lamp. the question is whether the shadows nest cleanly and whether three separate tones read as three separate stones.',
  build: () => {
    const ops = [];
    const L = [-0.55, -0.6, 0.58];
    
    const s1 = { cx: 280, cy: 360, r: 60 };
    const s2 = { cx: 420, cy: 380, r: 80 };
    const s3 = { cx: 580, cy: 400, r: 100 };

    ops.push(PHASE('table'));
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    
    const shadow1 = ellipsePoly(s1.cx + 50, s1.cy + s1.r - 6, 90, 18, 0.12);
    const shadow2 = ellipsePoly(s2.cx + 60, s2.cy + s2.r - 7, 120, 22, 0.12);
    const shadow3 = ellipsePoly(s3.cx + 70, s3.cy + s3.r - 8, 145, 26, 0.12);
    
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), 
      (p) => inside(p, shadow1) || inside(p, shadow2) || inside(p, shadow3), 3));
    
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    
    ops.push(OP('s', ellipse(s1.cx + 8, s1.cy + s1.r - 3, 42, 7), 'tone', 'eraser', 1.6));
    ops.push(OP('s', ellipse(s2.cx + 10, s2.cy + s2.r - 4, 56, 8), 'tone', 'eraser', 1.6));
    ops.push(OP('s', ellipse(s3.cx + 12, s3.cy + s3.r - 4, 70, 9), 'tone', 'eraser', 1.6));
    
    ops.push(PAUSE(400));

    /* draw stones by table position: furthest back first, nearest last */
    ops.push(PHASE('stone 1'));
    ops.push(OCCLUDE(ellipse(s1.cx, s1.cy, s1.r, s1.r), 0.92));
    ops.push(...sphereRings(s1.cx, s1.cy, s1.r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(s1.cx - 24, s1.cy - 29, 8));
    
    ops.push(PHASE('stone 2'));
    ops.push(OCCLUDE(ellipse(s2.cx, s2.cy, s2.r, s2.r), 0.92));
    ops.push(...sphereRings(s2.cx, s2.cy, s2.r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(s2.cx - 32, s2.cy - 38, 9));
    
    ops.push(PHASE('stone 3'));
    ops.push(OCCLUDE(ellipse(s3.cx, s3.cy, s3.r, s3.r), 0.92));
    ops.push(...sphereRings(s3.cx, s3.cy, s3.r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(s3.cx - 38, s3.cy - 48, 10));
    
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('three stones', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
