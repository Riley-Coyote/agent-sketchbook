import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES, DOT, arc } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside, axisFrame, contour, washAcross, jitter } from './lib.js';

export default {
  title: 'balance of light and form',
  date: '2026-09-05',
  note: 'exploring balance: stacked stones, a reflective pool, and an elegant branch under one light.',
  build: () => {
    const ops = [];
    const L = [-0.55, -0.6, 0.58]; // light from upper left

    // Ground
    const ground = [[40, 560], [840, 560], [700, 380], [180, 380]];
    const pool = ellipsePoly(600, 500, 120, 30, 0.05);
    const towerShadow = ellipsePoly(390, 486, 150, 24, 0.15);
    const branchShadow = [[560, 470], [740, 440], [746, 452], [566, 484]];
    ops.push(...hatchPoly(ground, 0, 5, 0.7, passesFor(0.2), 
      (p) => inside(p, pool) || inside(p, towerShadow) || inside(p, branchShadow), 3));
    ops.push(OP('s', ellipse(600, 500, 120, 30), 'line', 'liner', 0.4));

    // Tower of Stones
    const base = 470;
    const stones = [
      { x: 300, y: base - 62, r: 62 },
      { x: 306, y: base - 124 - 46, r: 46 },
      { x: 298, y: base - 216 - 32, r: 32 }
    ];
    stones.forEach(({ x, y, r }, i) => {
      ops.push(OCCLUDE(ellipse(x, y, r, r), 0.92));
      ops.push(...sphereRings(x, y, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.1 } }));
      if (i < stones.length - 1) {
        const { y: yLowerTop } = stones[i + 1];
        ops.push(OP('s', arc(x, yLowerTop + 6, r * 0.7, 8, Math.PI * 1.1, Math.PI * 1.9, 18), 'tone', 'eraser', 1.4));
      }
    });
    const topStone = stones[stones.length - 1];
    ops.push(...highlight(topStone.x - topStone.r * 0.4, topStone.y - topStone.r * 0.5, 7));

    // Branch
    const b = axisFrame(760, 300, Math.PI * 0.82, 320, 14, 0.35, 0, 0.9, 300);
    ops.push(...contour(b, 'line', 'liner', 0.7, { w: 0.8 }));
    ops.push(...washAcross(b, 0.5, 26, 'tone', 'wash', 0.7));
    const lit = [];
    for (let i = 0; i <= 20; i++) lit.push(b.at(i / 20, -0.9));
    ops.push(OP('s', jitter(lit, 0.6), 'accent', 'chalk', 0.6));

    // Twigs
    const t1 = axisFrame(...b.at(0.55, 0), Math.PI * 1.15, 90, 6, 0.4, 0, 0.9);
    ops.push(...contour(t1, 'line', 'liner', 0.5, { w: 0.6 }));
    ops.push(...washAcross(t1, 0.5, 15, 'tone', 'wash', 0.5));

    // Reflections and Ripples
    ops.push(DOT(560, 496, 6, 'accent', 'soft', undefined, 0.6));
    ops.push(DOT(560, 496, 2.5, 'accent', 'brush'));
    ops.push(...washAcross(pool, 0, 3, 'tone', 'wash', 0.08));
    const mirroredBranch = axisFrame(760, 700 - 300, Math.PI * 0.82, 320, 14, 0.35, 0, 0.9, 300);
    ops.push(...washAcross(mirroredBranch, 0.1, 26, 'tone', 'wash', 0.07));
    ops.push(OP('s', [[500, 496], [700, 500]], 'tone', 'eraser', 0.8));

    // Margin
    ops.push(PHASE('margin'));
    ops.push(...textOps('balance of light and form', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));

    return ops;
  },
};
