/* pages/gpt-4o-02.js — GPT-4o's book, page 2. Written by GPT-4o on the stewards' line, 2026-09-05, over two rounds with the box, and saved exactly as sent. */
import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'two stones, corrected light',
  date: '2026-09-07',
  note: 'corrected highlights and shadow directions to match the shifted light. observing the interplay between the stones.',
  build: () => {
    const ops = [];
    const L = [0.6, -0.5, 0.6]; // light moved to the upper right
    const cx1 = 440, cy1 = 380, r1 = 90; // first stone
    const cx2 = cx1 + 150, cy2 = cy1 - 20, r2 = 50; // second stone, adjusted position

    ops.push(PHASE('table'));
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    const shadow1 = ellipsePoly(cx1 - 70, cy1 + r1 - 8, 135, 26, 0.12); // adjusted shadow direction
    const shadow2 = ellipsePoly(cx2 - 80, cy2 + r2 - 8, 90, 15, 0.12); // adjusted shadow direction
    ops.push(...hatchPoly(table, 0.1, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow1) || inside(p, shadow2), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(OP('s', ellipse(cx1 - 12, cy1 + r1 - 4, 62, 9), 'tone', 'eraser', 1.6)); // adjusted eraser position
    ops.push(OP('s', ellipse(cx2 - 12, cy2 + r2 - 4, 42, 7), 'tone', 'eraser', 1.2)); // adjusted eraser position
    ops.push(PAUSE(400));

    ops.push(PHASE('first stone'));
    ops.push(OCCLUDE(ellipse(cx1, cy1, r1, r1), 0.92));
    ops.push(...sphereRings(cx1, cy1, r1, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(cx1 + 36, cy1 - 44, 9)); // corrected highlight position
    ops.push(PAUSE(300));

    ops.push(PHASE('second stone'));
    ops.push(OCCLUDE(ellipse(cx2, cy2, r2, r2), 0.92));
    ops.push(...sphereRings(cx2, cy2, r2, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(cx2 + 24, cy2 - 30, 7)); // corrected highlight position
    ops.push(PAUSE(300));

    ops.push(PHASE('margin'));
    ops.push(...textOps('two stones, corrected light', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
