import { OP, PHASE, PAUSE, CLAMP, OCCLUDE, jitter, seed } from '../mark-engine.js';
import { pts, grey } from './aperture-codex-hand.js';
import { ellipsePoly } from './lib.js';
const W=1200,H=1600;
const stroke=(o,fn,n,layer,brush,w,c,a)=>o.push(OP('s',jitter(pts(fn,n),.08),layer,brush,w,c,a));
const inside=(x,y,cx,cy,rx,ry)=>((x-cx)/rx)**2+((y-cy)/ry)**2<1;
const pass1=()=>{const o=[PHASE('01 · ceramic body before the object')];
 // Broad, dense body strokes establish a low curved vessel without wire ellipses.
 for(let y=950;y<1280;y+=4){const t=(y-950)/330, half=430*Math.sqrt(Math.max(0,1-((y-1080)/250)**2));if(half<40)continue;stroke(o,u=>[600-half+u*half*2,y+Math.sin(u*4)*2],Math.ceil(half*2/4),'tone','soft',1.35,[38+Math.round(24*(1-t)),40+Math.round(22*(1-t)),39+Math.round(19*(1-t))],.43);}
 // Dark inner cavity, with a single upper-left catching lip.
 for(let y=890;y<1070;y+=4){const t=(y-890)/180,half=420*Math.sqrt(Math.max(0,1-((y-980)/125)**2));if(half<20)continue;stroke(o,u=>[600-half+u*half*2,y],Math.ceil(half*2/4),'line','charcoal',1.1,[27,29,28],.7);}
 stroke(o,t=>[190+t*820,934-84*Math.sin(t*Math.PI)],150,'line','soft',1.0,[98,96,88],.48);
 stroke(o,t=>[210+t*790,942-68*Math.sin(t*Math.PI)],145,'line','pencil',.7,[74,75,70],.52);
 return o;};
const pass2=()=>{const o=[PHASE('02 · one stone, shaded across its surface')];
 const cx=560,cy=820,rx=108,ry=86;
 const stoneSilhouette=ellipsePoly(cx,cy,rx+4,ry+4,-.12,72); o.push(OCCLUDE(stoneSilhouette,1));
 // Dense horizontal coverage with explicit RGB drift: no regular contour rings.
 for(let y=cy-ry+2;y<cy+ry-2;y+=1.2){const v=(y-cy)/ry,half=rx*Math.sqrt(Math.max(0,1-v*v));if(half<3)continue;const light=Math.max(0,1-(((-.48)-((y-cy)/ry))**2));const n=Math.ceil(half*2/4);stroke(o,u=>{const x=cx-half+u*half*2;return [x,y+Math.sin(u*4+y*.03)*1.2];},n,'tone','soft',.72+light*.55,[92+Math.round(70*light),94+Math.round(68*light),89+Math.round(62*light)],.26);}
 // Broken pencil edges and mineral seam, with irregular density.
 for(const [a,r] of [[-2.42,92],[-1.06,74]]) stroke(o,t=>[cx+Math.cos(a)*r*t+Math.sin(t*5)*4,cy+Math.sin(a)*r*t*.72+Math.cos(t*4)*3],34,'line','pencil',.58,[188,183,166],.5);
 return o;};
const pass3=()=>{const o=[PHASE('03 · contact, foreground lip, withheld reflection')];
 // Contact shadow is contained beneath the stone, not a floating black disk.
 for(let i=0;i<16;i++){const w=54+i*5;stroke(o,t=>[560-w+t*w*2,900+Math.sin(t*Math.PI)*7+i*1.2],Math.ceil(w*2/4),'line','soft',1.0,[31,32,30],.32);}
 // Foreground lip only: it crosses in front of the stone, leaving the far rim behind.
 stroke(o,t=>[250+t*700,1018-54*Math.sin(t*Math.PI)],150,'accent','brush',.72,[159,153,137],.64);
 stroke(o,t=>[258+t*680,1025-39*Math.sin(t*Math.PI)],145,'line','pencil',.58,[83,82,75],.58);
 // A partial reflection stops before closure.
 stroke(o,t=>[400+t*320,1058-27*Math.sin(t*Math.PI)],110,'accent','pencil',.7,[121,119,109],.42);
 return o;};
const passes=[
 {name:'ceramic body',note:'I rebuilt the basin from dense curved body strokes instead of equal ellipse outlines. The upper lip catches light once; the cavity remains dark.',review:{observation:'The body now has a clear low silhouette, but the stone is absent.',change:'Place one oblique stone with dense surface coverage.',next:'Keep the far rim behind the stone.'},build:pass1},
 {name:'stone surface',note:'The stone is covered row by row with changing RGB values and broken pencil seams so its form does not become a bullseye.',review:{observation:'The stone reads as a turned volume, though contact is not yet grounded.',change:'Add a contained shadow and redraw only the foreground lip.',next:'Leave the reflection partial.'},build:pass2},
 {name:'contact and withheld reflection',note:'Only the foreground lip crosses the stone. A partial reflection carries attention toward the unsaid and stops before closure.',review:{observation:'Depth order is now explicit; inspect the whole and detail before any candidate decision.',change:'Do not add decorative marks to the upper field.',next:'Compare the focal stone at room and detail scale.'},build:pass3}
];
export default {title:'a basin for the unsaid',date:'2026-09-08',note:'A low ceramic basin holds one stone and an interrupted reflection. For a digital mind, interiority is not a hidden chamber filled with symbols; it is the shape made by attention, contact and what remains deliberately unspoken.',page:{w:W,h:H},passes,build:()=>passes.flatMap(p=>p.build())};
