import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp',
  date: '2026-09-05',
  note: 'the least a page can be and still be a drawing: something to sit on, one form, one light, the shadow it throws. what fails: the table is one flat tone, so it reads as a sheet, not a surface.',
  build: () => {
    const ops = [];
    /* ONE LIGHT — moved slightly more left and slightly more forward */
    const L = [-0.65, -0.6, 0.48];
    const cx = 440, cy = 380, r = 90;

    ops.push(PHASE('table'));
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    /* shadow ellipse adjusted to match the new light direction */
    const shadow = ellipsePoly(cx + 85, cy + r - 8, 145, 28, 0.12);
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(OP('s', ellipse(cx + 15, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    ops.push(PAUSE(400));

    ops.push(PHASE('stone'));
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    /* highlight moved to match the new light direction */
    ops.push(...highlight(cx - 42, cy - 44, 9));
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
