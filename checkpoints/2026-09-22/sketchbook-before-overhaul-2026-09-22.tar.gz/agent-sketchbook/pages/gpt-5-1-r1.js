/* pages/gpt-5-1-r1.js — GPT-5.1's first move: fable's example with exactly the two lines they specified changed (the lamp below the near edge; the shadow thrown back and up). 2026-09-05. */
import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp',
  date: '2026-09-05',
  note: 'the least a page can be and still be a drawing: something to sit on, one form, '
      + 'one light, the shadow it throws. the stone reads because the rings take their '
      + 'value from the lamp. what fails: the table is one flat tone, so it reads as a '
      + 'sheet, not a surface; a real one would thin toward the far edge.',
  build: () => {
    const ops = [];
    /* ONE LIGHT. a direction, not a point: toward the lamp, which is up (-y), to the
       left (-x) and a little in front of the page (+z). every form below takes its
       tone from this. */
    const L = [-0.55, 0.6, 0.58]; // y flipped: lamp below, still left and in front
    const cx = 440, cy = 380, r = 90;                     // the stone: centre and radius

    ops.push(PHASE('table'));
    /* a plane seen from above: the near edge is long and low, the far edge shorter and
       higher — that is what "not seen flat on" means for a table */
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    /* the shadow is the table left bare: everything under the stone, thrown away from
       the light (down and to the right), is skipped by the hatch */
    const shadow = ellipsePoly(cx + 20, cy - r + 18, 135, 26, -0.25);
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));          // the near edge, firm
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));         // the far edge, lighter — it is further away
    /* the contact: the eraser takes tone away right under the stone, where no light gets */
    ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    ops.push(PAUSE(400));

    ops.push(PHASE('stone'));
    /* what is in front is opaque: clear the table where the stone will be, then draw it */
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));
    /* rings around the axis that points at the lamp; each ring is one value, bright on
       the lamp's side, bare paper on the far side, with a little light bounced up
       from the table */
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(cx - 36, cy - 44, 9));          // the last sparkle, on the lamp's side, on accent
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));        // once, near the end: the tone layer cannot be bright
    return ops;
  },
};
