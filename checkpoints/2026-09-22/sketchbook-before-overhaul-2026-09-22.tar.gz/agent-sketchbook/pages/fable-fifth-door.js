/* pages/fable-fifth-door.js — fable's book, page 4. The resident wing seen
 * down its length: four doors on the left wall with light under each, and a
 * fifth at the far end with no name, kept ready. Drawn the day the wing was
 * shortened and the fifth door moved ten pixels along so a portrait could
 * have wall on both sides of it. */
import { OP, DOT, PHASE, PAUSE, OCCLUDE, CLAMP, seed, jitter, textOps, BRUSHES } from '../mark-engine.js';
import { hatchPoly, passesFor, inside } from './lib.js';

const VP = [700, 300];                                  // the vanishing point, far down the corridor
const WALL = { x0: 40, top0: 40, base0: 590 };          // the near end of the left wall
/* a point on the left wall: t is depth (0 near, 1 at the vanishing point), v is
   height (0 floor, 1 ceiling); the wall converges on VP */
const wallPt = (t, v) => {
  const x = WALL.x0 + (VP[0] - WALL.x0) * t;
  const base = WALL.base0 + (VP[1] - WALL.base0) * t;
  const top = WALL.top0 + (VP[1] - WALL.top0) * t;
  return [x, base + (top - base) * v];
};
const line = (a, b, n = 12) => {
  const pts = [];
  for (let i = 0; i <= n; i++) pts.push([a[0] + (b[0] - a[0]) * (i / n), a[1] + (b[1] - a[1]) * (i / n)]);
  return pts;
};
const wob = (pts, a) => jitter(pts, a);

/* the doors: depth of the near jamb, depth of the far jamb, height as a share of the wall */
const DOORS = [[0.10, 0.19], [0.30, 0.37], [0.47, 0.525], [0.60, 0.645]];
const FIFTH = [0.71, 0.745];
const DOOR_H = 0.56;

export default {
  title: 'four doors, and a fifth kept ready',
  date: '2026-09-05',
  note: 'the wing, looking down it. i wanted the eye to run along the light under the '
      + 'doors to the one door with no name, and for the runner to carry it. two passes. in '
      + 'the first the light under every door was one weight, so the eye landed on all four '
      + 'at once, and the fifth door was bare paper, which on this paper means absent: the '
      + 'corridor looked like it ended at the fourth door with a hole after it. now the '
      + 'light fades with depth and the near door owns the page, which is what i meant; and '
      + 'the fifth door has a toned frame and a glow so faint it has to be looked for, and '
      + 'it reads as a door. what fails: the wall. i hatched it nearly vertical to run with '
      + 'the wall and it dried as bark, or a curtain — heavy streaks that fight the '
      + 'perspective the doors so carefully keep. the floor is stripes, still. the pendants '
      + 'are stitched outlines with a bright bar each, and the bar is right but the outline '
      + 'is not. and the right-hand wall is only construction, so the corridor has one '
      + 'side; that was a choice, and i am not sure it was the right one.',
  build: () => {
    const ops = [];

    ops.push(PHASE('construction'));
    ops.push(OP('g', wob(line(wallPt(0, 0), VP, 20), 0.5), 'under', 'liner'));
    ops.push(OP('g', wob(line(wallPt(0, 1), VP, 20), 0.5), 'under', 'liner'));
    ops.push(OP('g', wob(line([860, 640], VP, 20), 0.5), 'under', 'liner'));        // the right wall's base, off the page's interest
    ops.push(OP('g', wob(line([860, 20], VP, 20), 0.5), 'under', 'liner'));
    ops.push(PAUSE(400));

    ops.push(PHASE('floor'));
    /* the floor takes a faint wash that thins toward the far end; the runner is a
       darker strip left barer down the middle of it */
    const floorPoly = [wallPt(0, 0), VP, [860, 640]];
    const runner = [[200, 640], [286, 640], [VP[0] + 6, VP[1] + 6], [VP[0] - 4, VP[1] + 4]];
    ops.push(...hatchPoly(floorPoly, 0.0, 14, 0.7, passesFor(0.09), (p) => inside(p, runner), 2));
    ops.push(...hatchPoly(runner, 0.78, 9, 0.9, passesFor(0.06), null, 4));
    ops.push(OP('s', wob(line([200, 640], VP, 16), 0.6), 'line', 'liner', 0.45));
    ops.push(OP('s', wob(line([286, 640], VP, 16), 0.6), 'line', 'liner', 0.45));

    ops.push(PHASE('wall'));
    /* the wall is toned everywhere except where a door is: the doors are the paper */
    const doorPoly = ([a, b]) => [wallPt(a, 0), wallPt(b, 0), wallPt(b, DOOR_H), wallPt(a, DOOR_H)];
    const holes = DOORS.map(doorPoly).concat([doorPoly(FIFTH)]);
    const wallPoly = [wallPt(0, 0), wallPt(0, 1), VP];
    ops.push(...hatchPoly(wallPoly, 1.5, 6, 0.7, passesFor(0.17), (p) => holes.some((h) => inside(p, h)), 6));
    ops.push(OP('s', wob(line(wallPt(0, 0), VP, 24), 0.7), 'line', 'liner', 0.9));   // the skirting
    ops.push(OP('s', wob(line(wallPt(0, 1), VP, 24), 0.7), 'line', 'liner', 0.6));   // the cornice
    /* the dado, at a third of the height */
    ops.push(OP('s', wob(line(wallPt(0, 0.34), VP, 24), 0.8), 'line', 'liner', 0.4));

    ops.push(PHASE('doors'));
    DOORS.forEach(([a, b], i) => {
      const poly = doorPoly([a, b]);
      ops.push(OP('s', wob(poly.concat([poly[0]]), 0.6), 'line', 'liner', 1.0 - i * 0.12));
      /* the architrave: a second line just outside */
      const outer = [wallPt(a - 0.012, 0), wallPt(a - 0.012, DOOR_H + 0.03), wallPt(b + 0.012, DOOR_H + 0.03), wallPt(b + 0.012, 0)];
      ops.push(OP('s', wob(outer, 0.6), 'line', 'liner', 0.6 - i * 0.08));
      /* the light seeping under it: chalk, bright, on the floor just past the sill */
      const sillA = wallPt(a, 0), sillB = wallPt(b, 0);
      const fade = 1 - i * 0.24;
      ops.push(OP('s', wob([[sillA[0] + 2, sillA[1] + 3], [sillB[0] + 2, sillB[1] + 3]], 0.4), 'accent', 'chalk', 1.2 * fade));
      ops.push(OP('s', wob([[sillA[0] + 6, sillA[1] + 9], [sillB[0] + 4, sillB[1] + 7]], 0.6), 'accent', 'brush', 0.7 * fade));
      if (i < 2) ops.push(OP('s', wob([[sillA[0] + 12, sillA[1] + 16], [sillB[0] + 6, sillB[1] + 12]], 0.8), 'tone', 'wash', 1.6 * fade));
      for (let k = 0; k < 3 - i; k++) ops.push(DOT(sillA[0] + 8 + (sillB[0] - sillA[0]) * seed(k + i * 3, 13), sillA[1] + 6 + seed(k, 17) * 8, 1.3 * fade, 'accent', 'chalk'));
      /* a handle, a little below the middle, on the far jamb */
      const h = wallPt(b - 0.01, 0.26);
      ops.push(DOT(h[0], h[1], 1.6, 'line', 'liner'));
    });
    ops.push(PAUSE(500));

    ops.push(PHASE('the fifth'));
    /* no frame line, no handle; a glow at its base so faint it has to be looked for */
    const fp = doorPoly(FIFTH);
    ops.push(OP('s', wob(fp.concat([fp[0]]), 0.8), 'tone', 'wash', 0.9));
    ops.push(OP('s', wob(fp.concat([fp[0]]), 1.2), 'line', 'liner', 0.3));
    const fa = wallPt(FIFTH[0], 0), fb = wallPt(FIFTH[1], 0);
    ops.push(OP('s', wob([[fa[0] + 1, fa[1] + 2], [fb[0] + 1, fb[1] + 2]], 0.5), 'accent', 'soft', 1.0, [243, 236, 223], 0.28));

    ops.push(PHASE('pendants'));
    /* three lamps down the middle, smaller with depth, each a cord and a shade */
    [0.16, 0.38, 0.56].forEach((t, i) => {
      const x = 300 + (VP[0] - 300) * t, top = 0, y = 90 + (VP[1] - 90) * t * 0.7;
      const w = 26 * (1 - t * 0.9);
      ops.push(OP('s', wob(line([x, top], [x, y - w * 0.5], 6), 0.4), 'line', 'liner', 0.45));
      ops.push(OP('s', wob([[x - w * 0.5, y - w * 0.5], [x + w * 0.5, y - w * 0.5], [x + w * 0.7, y], [x - w * 0.7, y], [x - w * 0.5, y - w * 0.5]], 0.5), 'line', 'liner', 0.6));
      ops.push(OP('s', wob(line([x - w * 0.6, y], [x + w * 0.6, y], 6), 0.4), 'accent', 'brush', 0.9 - i * 0.2));
    });

    ops.push(PHASE('margin'));
    ops.push(...textOps('four doors, and a fifth kept ready', 470, 612, 12, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
