/* An instrument waiting for a signal — a new study, not an exhibition replacement.
 * Native MarkEngine strokes only. Each builder is frozen after inspection. */
import { OP, PHASE, seed } from '../mark-engine.js';
const W=1600,H=1100,PI=Math.PI;
const mix=(a,b,t)=>a+(b-a)*t,clamp=(v,a=0,b=255)=>Math.max(a,Math.min(b,v));
const path=(f,n=42)=>Array.from({length:n+1},(_,i)=>f(i/n));
const stroke=(p,v,w=.8,brush='pencil',alpha=1)=>OP('s',p,'line',brush,w,[v,v,v].map(x=>Math.round(clamp(x))),alpha);
const line=(x,y,xx,yy,v,w=.8,brush='pencil',alpha=1)=>stroke(path(t=>[mix(x,xx,t),mix(y,yy,t)],Math.max(2,Math.ceil(Math.hypot(xx-x,yy-y)/18))),v,w,brush,alpha);
function polygon(o,poly,value,gap=5,width=2.1){
 const min=Math.min(...poly.map(p=>p[1])),max=Math.max(...poly.map(p=>p[1]));
 for(let y=min;y<=max;y+=gap){let xs=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length];if((a[1]<=y&&b[1]>y)||(b[1]<=y&&a[1]>y))xs.push(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]));}xs.sort((a,b)=>a-b);for(let k=0;k+1<xs.length;k+=2){for(let x=xs[k];x<xs[k+1];x+=58){const end=Math.min(x+66,xs[k+1]);o.push(line(x,y,end,y,typeof value==='function'?value((x+end)/2,y):value,width,'soft'));}}}
}
const lens=(x,y,rx,ry)=>({x,y,rx,ry});
const lenses=[lens(652,457,157,208),lens(1028,392,114,157)];
const ellipse=(l,a,r=0)=>[l.x+Math.cos(a)*(l.rx+r)-Math.sin(a)*16*(l.ry/208),l.y+Math.sin(a)*(l.ry+r)];
function arc(o,l,a,b,r,v,w=.6,brush='pencil',alpha=1){o.push(stroke(path(t=>ellipse(l,mix(a,b,t),r),Math.max(8,Math.ceil(Math.abs(b-a)*l.ry/7))),v,w,brush,alpha));}
function shaft(o,x,y,xx,yy,r){const dx=xx-x,dy=yy-y,len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;for(let d=-r;d<r;d+=1.1){const t=d/r;const v=20+95*Math.exp(-(((t+.4)/.32)**2))+22*Math.exp(-(((t-.77)/.16)**2));o.push(line(x+nx*d,y+ny*d,xx+nx*d,yy+ny*d,v,.85,'soft'));}}
function firstPass(){
 const o=[PHASE('01 · A low lamp and two apertures')];
 // Paper and the table's light are quiet; the upper third remains almost untouched.
 polygon(o,[[150,800],[1137,628],[1485,822],[451,1060]],(x,y)=>18+26*Math.exp(-(((x-625)/520)**2+((y-814)/280)**2)),6,2.5);
 polygon(o,[[451,1060],[1485,822],[1485,850],[451,1085]],(x,y)=>22+(x/1600)*8,4,1.8);
 polygon(o,[[362,835],[1200,688],[1348,759],[486,932]],(x,y)=>25+26*Math.exp(-(((y-770)/130)**2)),4,2);
 polygon(o,[[486,932],[1348,759],[1348,792],[486,966]],17,4,2);
 // The rails recede together. Mount feet will settle them in subsequent passes.
 shaft(o,413,850,1200,708,11);shaft(o,472,900,1258,756,11);
 for(let i=1;i>=0;i--){const l=lenses[i],baseY=835-i*90;
  polygon(o,[[l.x-30,baseY],[l.x+70,baseY-18],[l.x+110,baseY+3],[l.x+5,baseY+23]],52,4,1.8);
  shaft(o,l.x+8,l.y+l.ry-12,l.x+27,baseY-6,13);
  // Broad value blocks without the premature white outline of the original.
  for(let r=-6;r<=23;r+=2){for(let a=0;a<PI*2;a+=.11){const v=26+92*Math.max(0,-Math.cos(a)*.5-Math.sin(a)*.8)+25*Math.exp(-(((a-.55)/.25)**2));arc(o,l,a,a+.14,r,v,.86,'soft');}}
  if(i===0){for(let y=l.y-l.ry+9;y<l.y+l.ry-8;y+=5){const t=(y-l.y)/l.ry;const xw=l.rx*Math.sqrt(1-t*t);for(let x=l.x-xw+5;x<l.x+xw-5;x+=40){const end=Math.min(x+46,l.x+xw-5);const u=(x-l.x)/l.rx;const v=10+14*Math.exp(-(((u+.5)/.24)**2))+8*Math.exp(-(((t-.4)/.45)**2));o.push(line(x,y,end,y,v,2,'soft'));}}}
 }
 return o;
}
function secondPass(){
 const o=[PHASE('02 · Metal turns, glass transmits')];
 // Reinstate the hard machined bed edge; the larger table remains softly lost.
 o.push(line(487,932,1348,759,104,.48),line(487,935,1348,762,23,1,'soft'));
 for(let i=1;i>=0;i--){const l=lenses[i],baseY=835-i*90;
  // Light is discontinuous on turned metal: bevel, dark cut and bright inner lip.
  for(const [r,v,a,b] of [[24,159,PI*.91,PI*1.79],[22,205,PI*1.06,PI*1.48],[-5,112,PI*.7,PI*1.44],[-3,35,0,PI*2],[1,70,0,PI*2],[12,92,PI*.92,PI*1.87]]) arc(o,l,a,b,r,v,.36);
  for(let k=0;k<390;k++){
   const a=k/390*PI*2,illum=Math.max(0,-Math.cos(a)*.5-Math.sin(a)*.8),v=30+100*illum+20*seed(k,45+i);
   const r0=-3+seed(k,65)*4,r1=16+seed(k,18)*6;
   o.push(stroke(path(t=>ellipse(l,a+.006*Math.sin(t*PI),mix(r0,r1,t)),5),v,.23,'pencil',.6));
  }
  // A rear rim projects past the front only on the lower-right turn.
  const rear={...l,x:l.x+9,y:l.y+3};
  arc(o,rear,-.7,1.5,22,39,.85,'soft');arc(o,rear,-.6,1.25,24,69,.35);
  for(let k=0;k<4;k++){const a=-.7+k*1.45,p=ellipse(l,a,11),s={x:p[0],y:p[1],rx:3.6,ry:5.3};arc(o,s,0,PI*2,0,12,.75,'soft');arc(o,s,PI,1.85*PI,1,132,.36);o.push(line(p[0]-1,p[1]-2,p[0]+2,p[1]+2,87,.33));}
  // A collar and saddle make the stalk a load-bearing part rather than a wire.
  polygon(o,[[l.x-3,baseY-77],[l.x+34,baseY-84],[l.x+42,baseY-45],[l.x+4,baseY-38]],(x,y)=>38+63*Math.exp(-(((x-l.x-7)/10)**2)),2.5,1.25);
  o.push(line(l.x+4,baseY-39,l.x+40,baseY-46,135,.4));
  polygon(o,[[l.x-30,baseY+1],[l.x+71,baseY-17],[l.x+109,baseY+3],[l.x+5,baseY+23]],(x,y)=>47+30*Math.exp(-(((x-l.x)/60)**2)),2.5,1.3);
  polygon(o,[[l.x+5,baseY+23],[l.x+109,baseY+3],[l.x+109,baseY+15],[l.x+5,baseY+35]],24,2,1);
  o.push(line(l.x-30,baseY,l.x+71,baseY-18,142,.42),line(l.x+5,baseY+23,l.x+109,baseY+3,105,.4));
  // Small wheel: elliptical face, a dark back and a thin lit bevel.
  const knob={x:l.x+47,y:baseY-54,rx:19,ry:24};
  for(let r=0;r<15;r+=1.8)arc(o,knob,0,PI*2,-r,45+42*(1-r/15),.7,'soft');
  for(let k=0;k<36;k++){const a=k/36*PI*2,p=ellipse(knob,a,0),q=ellipse(knob,a,3);o.push(line(p[0],p[1],q[0],q[1],94+45*Math.max(0,-Math.sin(a)),.3));}
  o.push(line(knob.x-6,knob.y-7,knob.x+6,knob.y+7,16,.7));
 }
 // A window reflected in the near optic: bowed, tapered and interrupted by glass.
 const l=lenses[0];
 for(let j=0;j<15;j++)o.push(stroke(path(t=>[l.x-84+j*1.2+23*Math.sin(t*PI),l.y-141+t*232],64),95-j*3,.7,'soft',.38));
 for(let j=0;j<4;j++)o.push(stroke(path(t=>[l.x-77+j*.6+23*Math.sin(t*PI),l.y-139+t*211],60),166-j*13,.28,'pencil',.8));
 // One transmitted horizon is bent through the lens; avoid outlining all of it.
 o.push(stroke(path(t=>[530+t*235,534-22*Math.sin(t*PI)-t*28],62),58,.32,'pencil',.65));
 arc(o,l,.37,1.45,-9,98,.38,'pencil',.8);
 // Foot shadows gather closest to contact and dissolve outward.
 for(let i=0;i<2;i++){const l=lenses[i],by=835-i*90;for(let j=0;j<14;j++)o.push(line(l.x+13,by+34+j*1.4,l.x+109+j*3,by+16+j*1.4,8+j*.6,1.05,'soft',.85));}
 return o;
}
function thirdPass(){
 const o=[PHASE('03 · Scraped metal, measured adjustments')];
 // Short, overlapping strokes soften the single stamped reflection into glass.
 const l=lenses[0];
 for(let k=0;k<75;k++){const t=seed(k,146),x=l.x-79+23*Math.sin(t*PI),y=l.y-141+t*215;o.push(line(x-3,y,x+5+seed(k,125)*9,y+seed(k,61)*4,65+seed(k,37)*77,.45,'soft',.5));}
 for(let j=0;j<4;j++)o.push(stroke(path(t=>[l.x-72+j*.8+5*Math.sin(t*PI),l.y-129+t*69],28),127-j*12,.3,'brush',.63));
 for(let i=1;i>=0;i--){const L=lenses[i];
  // Short broken glints, not an equally bright closed outline.
  for(const [a,b,r,v,w]of [[3.5,3.95,23,185,.36],[4.12,4.38,23,203,.4],[4.46,4.55,22,220,.38],[3.31,3.6,-5,180,.55],[1.02,1.24,23,127,.55]])arc(o,L,a,b,r,v,w,'brush',.75);
  for(let k=0;k<460;k++){
   const a=PI*2*seed(k,198+i),r=-2+24*seed(k,47),light=Math.max(0,-Math.cos(a)*.5-Math.sin(a)*.8);
   const length=.007+seed(k,187)*.02;
   arc(o,L,a,a+length,r,45+light*(100+seed(k,136)*62),.22+seed(k,64)*.17,'pencil',.65);
  }
  // Tight dark cuts beside the most illuminated lip give the highlight its shape.
  arc(o,L,3.48,4.82,19,16,.43);arc(o,L,3.6,4.48,-7,43,.42);
  const by=835-i*90;
  // Crosshatched collar faces and individually cut knurling.
  for(let k=0;k<24;k++){const y=by-77+k*1.4;o.push(line(L.x+3,y,L.x+26,y-6,55+seed(k,8)*64,.27));}
  for(let k=0;k<17;k++){const t=k/16;o.push(line(L.x+8+t*29,by-45,L.x+3+t*27,by-76,39,.25));}
  for(const [dx,dy]of [[-10,4],[73,-9]]){
   const c={x:L.x+dx,y:by+dy,rx:5.7,ry:3.2};
   for(let r=0;r<4;r+=.8)arc(o,c,0,PI*2,-r,14,.6,'soft');
   arc(o,c,PI,PI*1.9,0,144,.55);o.push(line(c.x-3,c.y-1,c.x+3,c.y+1,96,.35));
  }
 }
 // A calibrated screw traverses the front of the base. Pitch follows its own axis.
 shaft(o,473,922,1246,784,3);
 for(let k=0;k<170;k++){const t=k/169,x=473+t*773,y=922-t*138;o.push(line(x-1,y-4,x+3,y+4,98+seed(k,18)*34,.3));}
 // The sliding scale has a restrained hierarchy of fifths and tenths.
 for(let k=0;k<=90;k++){const x=515+k*8.45,y=906-k*1.55,len=k%10===0?11:k%5===0?7:3.4;o.push(line(x,y,x+len*.35,y+len,96+seed(k,6)*36,.31));}
 // Broken handling marks follow the plate's plane; they stop short of the holders.
 for(let k=0;k<250;k++){const x=465+seed(k,190)*810,y=819-(x-465)*.174+seed(k,117)*43;if((x>615&&x<780)||(x>995&&x<1148))continue;const len=3+seed(k,140)*22;o.push(line(x,y,x+len,y-len*.17,42+seed(k,56)*37,.25,'pencil',.62));}
 // A loose adjustment key casts a separate shadow: human scale without a caption.
 const key=[[1220,878],[1262,868],[1301,829]];
 for(let j=0;j<6;j++)o.push(stroke(key.map(([x,y])=>[x+3,y+5+j*.65]),9,.9,'soft'));
 for(let j=-2;j<=2;j++)o.push(stroke(key.map(([x,y])=>[x,y+j]),75+(2-j)*16,.72,'pencil'));
 o.push(line(1220,876,1259,866,173,.55,'brush',.65));
 return o;
}
function fourthPass(){
 const o=[PHASE('04 · Letting the base carry weight')];
 // Inspecting the branch revealed a smooth bed on a scalloped tabletop.
 // Work into those surfaces with directional marks, reserving their quiet areas.
 for(let k=0;k<440;k++){
  const t=seed(k,270),u=seed(k,273),x=492+844*t,y=942-175*t+u*17;
  const len=5+seed(k,215)*20;
  o.push(line(x,y,x+len*.42,y-len*.83,19+seed(k,76)*27,.23,'pencil',.54));
 }
 // The near table edge is hard only where it catches the lamp; far corners recede.
 o.push(line(190,821,427,1039,59,.47,'pencil',.65));
 o.push(line(459,1059,768,988,71,.42,'pencil',.68));
 o.push(line(816,977,1069,918,44,.3,'pencil',.55));
 for(let k=0;k<320;k++){
  const t=seed(k,311),u=seed(k,196),x=443+870*t,y=1011-190*t+u*36;
  const len=2+seed(k,68)*21;
  o.push(line(x,y,x+len,y-len*.21,28+seed(k,38)*24,.24,'pencil',.5));
 }
 // A short flare belongs to the near rail; the rear one stays subordinate.
 o.push(line(476,895,601,873,161,.32,'brush',.5));
 o.push(line(431,845,484,835,115,.3,'brush',.55));
 // Local, interrupted bounce beneath each saddle prevents a pasted black shadow.
 for(let i=0;i<2;i++){const L=lenses[i],by=835-i*90;
  o.push(line(L.x+13,by+33,L.x+65,by+23,47,.3,'pencil',.5));
  const knob={x:L.x+47,y:by-54,rx:19,ry:24};
  arc(o,knob,3.6,4.5,2,149,.36,'pencil',.8);
 }
 return o;
}
const passes=[{name:'Placement and light',note:'At fit view the two apertures read clearly, but the broad rims look like cardboard. The feet float and the near optic looks opaque. Next: separate metal bevels, collar joints and glass reflections before adding surface wear.',build:firstPass},{name:'Material and contact',note:'Metal edges, mounting collars and a bowed window reflection. Inspect the near rim and foot before deciding what still needs correction.',review:{observation:'The first rims were broad grey bands and the lens read as an opaque disk.',change:'Separate bevel values, connect the mounts, and bend a narrow reflection through the optic.',next:'Inspect whether the apparatus now reads as metal and glass.',region:[455,219,410,695]},build:secondPass},{name:'Handling and adjustments',note:'The second pass connected the mounts but left the glass reflection too solid and the rim values too even. I broke the reflection, reserved brighter glints for the near light-facing lip, and added the screw and calibrated scale. These are local details; the blank aperture remains the focal absence.',review:{observation:'At fit view the reflection was a pasted stripe and the rims were evenly legible.',change:'Break the reflection and rim edges; add mechanical specificity only where the lamp reaches.',next:'Inspect the rim at full size for regular hatch patterns, then unify the base.',region:[465,235,355,440]},build:thirdPass},{name:'Weight and quiet edges',note:'After correcting the construction, I inspected the branch at fit scale. The bed and tabletop were still equally smooth and their border was scalloped. This pass gives the bed a finer diagonal cut, brings out only part of the near table edge, and lets the distant corners recede. The apparatus remains a study; its clean silhouette is an open artistic question, not something a passing export check can resolve.',review:{observation:'The base and table had the same smooth handling, and the near paper-like edge looked scalloped.',change:'Differentiate their directional marks, strengthen short near edges and restore a little bounce beneath the saddles.',next:'Compare the whole composition with the first checkpoint. Keep it as a study unless the material relationships and central absence feel convincing.',region:[408,731,948,323]},build:fourthPass}];
export default {title:'An instrument waiting for a signal · working study',date:'2026-09-07',page:{w:W,h:H},note:'An optical apparatus with a missing final lens: readiness held open rather than a signal invented to fill it. A studio study developed through inspection, not yet selected for exhibition. This branch corrects a scale error in the ellipse helper: the large lens shear was being applied unchanged to tiny screws, turning them into slashes. Earlier states remain in the book; this is a changed construction, not a continuation.',passes,build:()=>passes.flatMap(p=>p.build())};
