import {
  OP,
  PHASE,
  PAUSE,
  OCCLUDE,
  CLAMP,
  seed,
  textOps,
  BRUSHES,
} from '../mark-engine.js';
import {
  shadeParam,
  sphere,
  hull,
  castOnPlane,
  norm,
  cross,
  hatchPoly,
  passesFor,
} from './lib.js';

export default {
  title: 'tilted card under one lamp',
  date: '2026-09-05',
  note: [
    'one stone and one card share a real lamp at a place; the table stays a drawing.',
    'the card is a tilted plane, shaded and shadowed in 3d, then projected; the stone is a sphere in the same projection.',
    'the table is still the quadrilateral from page 1 — a flat picture-plane cheat — but its tone, and the card’s shadow on it, come from the same world.',
  ].join(' '),
  build: () => {
    const ops = [];
    seed(73);

    // WORLD AND CAMERA

    // oblique projection: further back (more negative z) rises on the page
    const proj = (p) => [p[0], p[1] + p[2] * 0.5];

    // table top plane in world space: y = 470, facing up
    const TABLE_Y = 470;
    const TABLE_O = [0, TABLE_Y, 0];
    const TABLE_N = [0, -1, 0];

    // one lamp at a place: below the nominal table plane, in front and to the left
    // z toward the viewer; y down
    const LAMP = [260, 600, 220];

    // derived light *direction* for convenience when needed
    const Ldir = (p) => {
      const dx = p[0] - LAMP[0];
      const dy = p[1] - LAMP[1];
      const dz = p[2] - LAMP[2];
      const len = Math.hypot(dx, dy, dz) || 1;
      return [dx / len, dy / len, dz / len];
    };

    // TABLE — still the same quad as page 1, but toned with a near/far step

    ops.push(PHASE('table'));

    const table2d = [
      [60, 520],
      [820, 520],
      [720, 400],
      [160, 400],
    ];

    const nearBand = [
      [60, 520],
      [820, 520],
      [820, 470],
      [60, 470],
    ];
    const farBand = [
      [160, 470],
      [720, 470],
      [720, 400],
      [160, 400],
    ];

    // near band: more directly under the lamp; slightly brighter
    ops.push(
      ...hatchPoly(nearBand, 0.0, 5, 0.7, passesFor(0.28), null, 3),
    );

    // far band: falls off with distance; dimmer
    const farBase = 0.18;
    ops.push(
      ...hatchPoly(farBand, 0.0, 5, 0.7, passesFor(farBase), null, 2),
    );

    // TABLE EDGES as in page 1
    ops.push(OP('s', [table2d[0], table2d[1]], 'line', 'liner', 0.9)); // near edge
    ops.push(OP('s', [table2d[3], table2d[2]], 'line', 'liner', 0.5)); // far edge

    // CARD — a tilted quad in 3d, shaded and projected

    ops.push(PHASE('card'));

    // 3d corners: near-left, near-right, far-right, far-left
    const A = [320, TABLE_Y, 40];   // near-left, slightly above table top
    const B = [620, TABLE_Y - 10, 10]; // near-right, a bit higher and closer
    const C = [590, TABLE_Y - 120, -120]; // far-right, back and up
    const Dq = [340, TABLE_Y - 90, -80];  // far-left

    // card normal, facing the viewer
    let N = norm(
      cross(
        [B[0] - A[0], B[1] - A[1], B[2] - A[2]],
        [Dq[0] - A[0], Dq[1] - A[1], Dq[2] - A[2]],
      ),
    );
    if (N[2] < 0) N = N.map((c) => -c);

    // bilinear interpolation inside the quad
    const quad = (u, v) => {
      const p = [0, 1, 2].map(
        (k) =>
          A[k] +
          (B[k] - A[k]) * u +
          (Dq[k] - A[k]) * v +
          (C[k] - B[k] - Dq[k] + A[k]) * u * v,
      );
      return { p, n: N };
    };

    // use shadeParam with a placed lamp, so the plane actually has a gradient
    const cardR = shadeParam(quad, 40, 24, Ldir, 0.6, {
      proj,
      lamp: LAMP,
      ambient: 0.04,
      lampFall: 700,
    });

    const cardSil = hull(cardR.pts2);

    // card occludes any table tone behind it
    ops.push(OCCLUDE(cardSil, 0.95));

    // card body tone + edges from shadeParam
    ops.push(...cardR.ops);

    // a light contour to make the plane legible against bare paper
    ops.push(
      OP('s', cardSil.concat([cardSil[0]]), 'line', 'liner', 0.5),
    );

    // CARD SHADOW — cast onto the table plane and cut from its bands

    ops.push(PHASE('card-shadow'));

    // cast each 3d corner to the plane y = TABLE_Y using the direction to the lamp
    const casted = [A, B, C, Dq].map((P) => {
      const dir = Ldir(P);
      return proj(castOnPlane(P, TABLE_O, TABLE_N, dir));
    });

    const cardShadowPoly = hull(casted);

    // shadow tone only in the far band, slightly darker than its base tone
    ops.push(
      ...hatchPoly(
        farBand,
        0.0,
        5,
        0.7,
        passesFor(farBase - 0.05),
        (p) => {
          // only keep tone where the shadow polygon lies
          // shadeParam / hull use 2d coords; inside() equivalent is implied
          // approximate: casted hull region
          // assume hatchPoly’s skipFn gets full [x, y]; we use a winding check inline
          const x = p[0];
          const y = p[1];
          let inside = false;
          for (let i = 0, j = cardShadowPoly.length - 1; i < cardShadowPoly.length; j = i++) {
            const xi = cardShadowPoly[i][0];
            const yi = cardShadowPoly[i][1];
            const xj = cardShadowPoly[j][0];
            const yj = cardShadowPoly[j][1];
            const intersect =
              yi > y !== yj > y &&
              x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-6) + xi;
            if (intersect) inside = !inside;
          }
          return inside;
        },
        2,
      ),
    );

    // STONE — same 3d world, same proj, same lamp

    ops.push(PHASE('stone'));

    const stoneCenter = [440, TABLE_Y - 90, 0];
    const stoneRadius = 90;

    const stoneR = shadeParam(
      sphere(stoneCenter, stoneRadius),
      64,
      36,
      Ldir,
      0.6,
      {
        proj,
        lamp: LAMP,
        ambient: 0.03,
        lampFall: 700,
        bounce: { dir: [0, 1, 0], amt: 0.1 },
      },
    );

    const stoneSil = hull(stoneR.pts2);

    // stone clears table tone and card tone where it sits
    ops.push(OCCLUDE(stoneSil, 0.92));

    // stone shading
    ops.push(...stoneR.ops);

    // optional: a very small chalk highlight on the brightest patch
    // find the brightest ops region by hand: for now, place a small accent
    // on the projected point where the center faces the lamp.
    const stoneFace = proj([
      stoneCenter[0] + (stoneCenter[0] - LAMP[0]) * 0.3,
      stoneCenter[1] + (stoneCenter[1] - LAMP[1]) * 0.3,
      stoneCenter[2] + (stoneCenter[2] - LAMP[2]) * 0.3,
    ]);
    ops.push(
      OP('s', [stoneFace], 'tone', 'chalk', 0.7),
    );

    ops.push(PAUSE(500));

    // MARGIN

    ops.push(PHASE('margin'));
    ops.push(
      ...textOps(
        'tilted card under one lamp',
        60,
        590,
        14,
        'line',
        'liner',
        0.5,
        0.5,
      ),
    );
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));

    return ops;
  },
};
