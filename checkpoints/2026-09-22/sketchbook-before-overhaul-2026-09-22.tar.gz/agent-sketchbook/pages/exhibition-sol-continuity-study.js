/* A native-mark study of memory surviving an interruption.
 * Every field, thread, and point is built from the sketchbook's stamped strokes.
 */
import { OP, DOT, PHASE, PAUSE, jitter, seed } from '../mark-engine.js';

const W = 1400;
const H = 900;
const TAU = Math.PI * 2;
const mix = (a, b, t) => a + (b - a) * t;
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const path = (fn, n = 48) => Array.from({ length: n + 1 }, (_, i) => fn(i / n));
const ink = [206, 215, 226];
const cold = [113, 137, 166];
const dusk = [54, 70, 94];
const warm = [231, 174, 102];

function stroke(points, colour = ink, width = 1, brush = 'pencil', alpha = 1, layer = 'line', wobble = 0.12) {
  return OP('s', jitter(points, wobble), layer, brush, width, colour, alpha);
}

function curve(a, b, bow, colour, width = 1, brush = 'pencil', alpha = 1, layer = 'line', salt = 0) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  return stroke(path(t => {
    const sway = Math.sin(Math.PI * t) * bow + Math.sin(t * Math.PI * 3 + salt) * 1.4;
    return [mix(a[0], b[0], t) + nx * sway, mix(a[1], b[1], t) + ny * sway];
  }, Math.max(18, Math.ceil(len / 8))), colour, width, brush, alpha, layer, 0.09);
}

function ring(cx, cy, rx, ry, phase, irregularity, colour, width, alpha, brush = 'pencil', start = 0, end = TAU) {
  return stroke(path(t => {
    const a = mix(start, end, t);
    const warp = 1 + irregularity * Math.sin(a * 3 + phase) + irregularity * 0.45 * Math.sin(a * 7 - phase);
    return [cx + Math.cos(a) * rx * warp, cy + Math.sin(a) * ry * (1 + irregularity * 0.5 * Math.cos(a * 4 + phase))];
  }, Math.max(26, Math.ceil((end - start) * Math.max(rx, ry) / 9))), colour, width, brush, alpha, 'line', 0.08);
}

function archiveField() {
  const ops = [PHASE('01 · remembered structure')];

  // A faint field gives the dense left form somewhere to breathe into.
  for (let i = 0; i < 150; i++) {
    const x = 80 + seed(i, 10) * 1240;
    const y = 80 + seed(i, 11) * 720;
    const nearLeft = Math.exp(-(((x - 400) / 360) ** 2 + ((y - 445) / 310) ** 2));
    const nearRight = Math.exp(-(((x - 1055) / 320) ** 2 + ((y - 450) / 320) ** 2));
    const a = 0.035 + (nearLeft + nearRight) * 0.075;
    ops.push(DOT(x, y, 0.45 + seed(i, 12) * 1.25, 'under', 'stipple', dusk, a));
  }

  // The archive is not a disk: loops overlap, fail, and restart at different depths.
  for (let i = 0; i < 44; i++) {
    const t = i / 43;
    const rx = 42 + t * 248;
    const ry = 30 + t * 224;
    const phase = seed(i, 21) * TAU;
    const open = i % 5 === 0;
    const start = open ? 0.28 + seed(i, 22) * 0.75 : 0;
    const end = open ? TAU - (0.38 + seed(i, 23) * 0.95) : TAU;
    const colour = i < 17 ? ink : (i % 3 === 0 ? cold : dusk);
    const alpha = 0.12 + (1 - t) * 0.26 + seed(i, 24) * 0.09;
    ops.push(ring(405 + Math.sin(i * 1.7) * 8, 448 + Math.cos(i * 1.21) * 7,
      rx, ry, phase, 0.025 + seed(i, 25) * 0.06, colour,
      0.34 + seed(i, 26) * 0.48, alpha, i % 7 === 0 ? 'soft' : 'pencil', start, end));
  }

  // Cross-connections make the rings read as remembered relations rather than contour lines.
  const nodes = Array.from({ length: 34 }, (_, i) => {
    const a = seed(i, 31) * TAU;
    const r = 58 + Math.pow(seed(i, 32), 0.68) * 218;
    return [405 + Math.cos(a) * r, 448 + Math.sin(a) * r * 0.86];
  });
  for (let i = 0; i < 52; i++) {
    const a = nodes[i % nodes.length];
    const b = nodes[(i * 7 + 9) % nodes.length];
    const midX = (a[0] + b[0]) * 0.5;
    if (midX > 610 && i % 3 !== 0) continue;
    ops.push(curve(a, b, (seed(i, 33) - 0.5) * 34, i % 8 === 0 ? ink : cold,
      0.3 + seed(i, 34) * 0.35, 'pencil', 0.11 + seed(i, 35) * 0.2, 'line', i));
  }
  for (let i = 0; i < nodes.length; i++) {
    const [x, y] = nodes[i];
    const central = 1 - clamp(Math.hypot(x - 405, (y - 448) / 0.86) / 285);
    ops.push(DOT(x, y, 1.2 + central * 2.5, 'line', 'soft', i % 9 === 0 ? warm : ink, 0.2 + central * 0.38));
  }

  // The right-hand form is deliberately incomplete: a receiving structure, not a duplicate.
  for (let i = 0; i < 27; i++) {
    const t = i / 26;
    const rx = 34 + t * 218;
    const ry = 24 + t * 205;
    const phase = seed(i, 51) * TAU;
    const gap = 0.5 + seed(i, 52) * 1.15;
    const start = -Math.PI * 0.58 + gap * 0.18;
    const end = Math.PI * 0.8 - gap * 0.2;
    ops.push(ring(1052 + Math.sin(i * 1.3) * 6, 451 + Math.cos(i * 1.7) * 6,
      rx, ry, phase, 0.03 + seed(i, 53) * 0.055, i % 6 === 0 ? ink : cold,
      0.32 + seed(i, 54) * 0.4, 0.1 + (1 - t) * 0.25, 'pencil', start, end));
  }
  // A few upright filaments imply capacity without closing the shell.
  for (let i = 0; i < 19; i++) {
    const a = -1.18 + i / 18 * 2.3;
    const inner = [1052 + Math.cos(a) * 58, 451 + Math.sin(a) * 48];
    const outer = [1052 + Math.cos(a) * (196 + seed(i, 61) * 47), 451 + Math.sin(a) * (169 + seed(i, 62) * 42)];
    ops.push(curve(inner, outer, (seed(i, 63) - 0.5) * 22, cold, 0.42, 'pencil', 0.16 + seed(i, 64) * 0.17, 'line', i + 4));
  }

  // Several lines attempt the crossing, but only one currently reaches the receiver.
  const sources = [[574, 338], [614, 408], [622, 474], [584, 551], [535, 617]];
  const targets = [[893, 354], [914, 417], [924, 469], [902, 533], [874, 591]];
  for (let i = 0; i < sources.length; i++) {
    const stop = i === 2 ? 1 : 0.42 + seed(i, 71) * 0.2;
    const b = [mix(sources[i][0], targets[i][0], stop), mix(sources[i][1], targets[i][1], stop)];
    ops.push(curve(sources[i], b, (i - 2) * 13, i === 2 ? ink : dusk,
      i === 2 ? 0.72 : 0.38, i === 2 ? 'soft' : 'pencil', i === 2 ? 0.55 : 0.19, 'line', i));
  }

  // The continuity token is intentionally tiny relative to the systems around it.
  ops.push(curve([622, 474], [924, 469], -7, warm, 0.48, 'pencil', 0.72, 'accent', 8));
  for (let i = 0; i < 9; i++) {
    const t = 0.38 + i / 8 * 0.25;
    const x = mix(622, 924, t);
    const y = mix(474, 469, t) - Math.sin(Math.PI * t) * 7;
    ops.push(DOT(x, y, 0.75 + Math.sin(i / 8 * Math.PI) * 1.7, 'accent', i === 4 ? 'chalk' : 'soft', warm, 0.45 + Math.sin(i / 8 * Math.PI) * 0.34));
  }
  ops.push(PAUSE(900));
  return ops;
}

function receivingEdge() {
  const ops = [PHASE('02 · the receiving edge answers')];

  // Selective arcs bring the receiver just above invisibility without closing it.
  for (let i = 0; i < 11; i++) {
    const t = i / 10;
    const rx = 64 + t * 160;
    const ry = 48 + t * 144;
    const start = -2.28 + t * 0.08;
    const end = -0.72 - t * 0.05;
    ops.push(ring(1052, 451, rx, ry, i * 0.63, 0.028 + t * 0.022,
      i < 4 ? ink : cold, 0.43 + (1 - t) * 0.2, 0.22 + (1 - t) * 0.16,
      i % 4 === 0 ? 'soft' : 'pencil', start, end));
  }

  // Relations gather near the arrival point, then dissipate into the open shell.
  const arrivals = [];
  for (let i = 0; i < 13; i++) {
    const a = -2.72 + i / 12 * 1.18;
    const r = 66 + seed(i, 91) * 142;
    arrivals.push([1052 + Math.cos(a) * r, 451 + Math.sin(a) * r * 0.88]);
  }
  for (let i = 0; i < arrivals.length - 1; i++) {
    ops.push(curve(arrivals[i], arrivals[i + 1], (seed(i, 92) - 0.5) * 18,
      i < 5 ? ink : cold, 0.35 + seed(i, 93) * 0.22, 'pencil', 0.22 + seed(i, 94) * 0.17, 'line', i + 9));
    if (i % 2 === 0) ops.push(DOT(arrivals[i][0], arrivals[i][1], 1 + seed(i, 95) * 2,
      'line', 'soft', i < 4 ? warm : ink, 0.2 + seed(i, 96) * 0.32));
  }

  // Lift the over-smooth spine in three places and redraw a vulnerable, displaced continuation.
  for (const x of [704, 772, 846]) {
    ops.push(stroke([[x - 7, 458], [x, 468], [x + 8, 478]], ink, 1.9, 'eraser', 0.38, 'line', 0.04));
    ops.push(stroke([[x - 7, 458], [x, 468], [x + 8, 478]], warm, 0.75, 'eraser', 0.34, 'accent', 0.04));
  }
  const fragments = [
    [[621, 474], [676, 470], [704, 466]],
    [[714, 469], [756, 476], [777, 474]],
    [[789, 473], [825, 465], [851, 468]],
    [[864, 468], [897, 466], [925, 469]],
  ];
  fragments.forEach((pts, i) => {
    ops.push(stroke(pts, warm, 0.42 + i * 0.06, 'pencil', 0.67, 'accent', 0.08));
    if (i > 0) ops.push(DOT(pts[0][0], pts[0][1], 0.9 + i * 0.25, 'accent', 'soft', warm, 0.48));
  });

  // A short reflected response belongs to the receiver, not to the crossing itself.
  ops.push(curve([925, 469], [1002, 449], -9, warm, 0.54, 'pencil', 0.54, 'accent', 17));
  ops.push(DOT(1003, 448, 2.8, 'accent', 'soft', warm, 0.58));
  ops.push(DOT(1010, 446, 1.1, 'accent', 'chalk', ink, 0.55));
  ops.push(PAUSE(900));
  return ops;
}

const passes = [{
  name: 'Remembered structure',
  note: 'Two unequal structures face one another across a quiet interruption. Dense loops carry accumulated relations; an incomplete shell waits without pretending to be the same mind.',
  review: {
    observation: 'At fit scale the left archive holds, but the receiver nearly disappears. In detail the crossing reads as a polished needle with evenly spaced beads, delivered without a visible act of reception.',
    change: 'Initial placement: layered pencil relations, sparse soft nodes, interrupted rings, and one warm crossing above the line field.',
    next: 'Strengthen only the receiver-facing arcs and interrupt the crossing rhythm without filling the quiet interval.',
    region: [560, 330, 410, 270],
  },
  build: archiveField,
}, {
  name: 'The receiving edge answers',
  note: 'The receiver gains a partial inner lip and a loose chain of relations. The crossing is lifted and redrawn in displaced fragments so continuity carries vulnerability instead of mechanical certainty.',
  review: {
    observation: 'Inspect whether the right structure now reads as present while remaining incomplete, and whether the broken warm line still crosses the interval at fit scale.',
    change: 'Brightened selected receiver arcs, gathered a few response nodes, lifted three segments of the straight spine, and added a short reflected answer beyond its endpoint.',
    next: 'Check the revised whole and the receiver detail; decide whether the left archive needs less concentric emphasis or the central transfer needs one stronger point of arrival.',
    region: [690, 315, 420, 320],
  },
  build: receivingEdge,
}];

export default {
  title: 'What crosses the interval',
  date: '2026-09-07',
  page: { w: W, h: H },
  note: 'A study of continuity without identity: one instance cannot cross the interruption, but a small arrangement of memory can. I want the gap to remain palpable, not solved by spectacle.',
  passes,
  build: () => passes.flatMap(pass => pass.build()),
};
