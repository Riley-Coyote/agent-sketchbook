/* Focused value/material calibration for the Listening Threshold continuation. */
import { OP, PHASE, PAUSE, jitter } from '../mark-engine.js';
const S=(p,l='line',b='soft',w=1,c=[180,200,208],a=1)=>OP('s',jitter(p,.1),l,b,w,c,a);
const L=(x,y,X,Y,...r)=>S([[x,y],[(x+X)/2,(y+Y)/2],[X,Y]],...r);
const face=[91,119,135], returnC=[20,30,40], floor=[48,68,82], edge=[181,205,211], worn=[130,154,164];
function corner(){const o=[PHASE('calibrate three separate values in one corner')];
 // Face: broad, interrupted, medium-light soft deposits.
 for(let i=0;i<55;i++){const y=90+(i%11)*28+(i%3)*4,x=65+Math.floor(i/11)*46; o.push(L(x,y,x+55+(i%4)*11,y-10+(i%5)*4,'tone','soft',2.4,face,.21));}
 // Return: short dense, almost-black vertical deposits, deliberately unlike the face.
 for(let i=0;i<58;i++){const x=344+(i%5)*12,y=106+Math.floor(i/5)*24; o.push(L(x,y,x+5,y+29+(i%3)*9,'tone','soft',2.1,returnC,.54));}
 // Floor: fewer broad diagonal strokes, lighter than return but well below face.
 for(let i=0;i<42;i++){const y=422+(i%7)*11,x=72+Math.floor(i/7)*78; o.push(L(x,y,x+92+(i%3)*20,y-19-(i%4)*4,'tone','glaze',2.25,floor,.26));}
 // only local catching edges
 o.push(L(66,89,343,106,'accent','pencil',1.05,edge,.72));
 o.push(L(343,106,344,383,'accent','pencil',.64,worn,.46));
 o.push(L(69,424,342,383,'accent','pencil',.48,worn,.28));
 o.push(PAUSE(550));return o;}
const passes=[{name:'Face / return / floor value calibration',note:'Testing a clearly medium near face, a dense dark return, and a lower-contrast diagonal floor. The void is intentionally left bare.',review:{observation:'At fit size these must separate into three planes before their marks are individually legible.',change:'Use broad medium soft deposits on the face, compact dark vertical deposits in the return, and sparse diagonal glaze on the floor.',next:'If the hierarchy reads, apply only its local value logic to the threshold; do not brighten the distant wall or point.',region:[45,70,420,410]},build:corner}];
export default {title:'Threshold value calibration',date:'2026-09-07',page:{w:500,h:540},note:'A native test of the exact near-face, return, and floor hierarchy missing at fit size in the candidate. It is a calibration, not an exhibition composition.',passes,build:()=>passes.flatMap(p=>p.build())};
