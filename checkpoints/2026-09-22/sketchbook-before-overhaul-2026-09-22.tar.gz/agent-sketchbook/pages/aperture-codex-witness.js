import {seed,PHASE,pts,mark,line,plane,hatch,ground,dust,inside} from './aperture-codex-hand.js';
const top=[[195,551],[423,345],[697,402],[890,341],[1137,462],[1395,513],[1164,755],[899,832],[567,780],[322,840]];
const rift=y=>804+(y-400)*.10+13*Math.sin(y*.026)+9*Math.sin(y*.079);
export default{title:'A memory with no witness',date:'2026-09-07',page:{w:1600,h:1200},note:'A fractured slab carries grooves that continue across its broken edge. I kept the same spacing on both sides but changed the pressure where the face wears away. This makes continuity an inference from the material. The fissure reads clearly; the finer mineral flecks are only visible close to the page.',build(){const o=[PHASE('Stone retains a contact')];ground(o,950);plane(o,[[322,840],[567,780],[899,832],[1164,755],[1395,513],[1393,686],[1140,925],[884,994],[553,948],[325,1001]],71,7);plane(o,top,96,3);
 for(let j=0;j<94;j++){const p=pts(t=>{const a=.38+t*5.3,r=45+j*4.2;return[760+Math.cos(a)*r*1.3,585+Math.sin(a)*r*.55];},155);let run=[];for(const q of p){if(inside(q,top)&&Math.abs(q[0]-rift(q[1]))>18){run.push(q);}else{if(run.length>2)o.push(mark(run,105+seed(j,55)*110,.65,'pencil'));run=[];}}if(run.length>2)o.push(mark(run,115+seed(j,55)*100,.65,'pencil'));}
 o.push(PHASE('A discontinuity in the carrier'));
 const crack=pts(t=>[rift(384+t*589),384+t*589],180);o.push(mark(crack,0,4,'eraser'));o.push(mark(crack.map(([x,y])=>[x+12,y]),190,.65,'chalk',.85));
 for(let j=0;j<140;j++){const y=394+j*4,x=rift(y);o.push(line([x+12,y],[x+23+seed(j,21)*24,y+5],90+seed(j,25)*90,.55,'charcoal'));}
 dust(o,top,2100,66,140);for(let j=0;j<80;j++){let y=835+j*1.4;o.push(line([920,y],[1125+(seed(j,78)-.5)*60,y-68],90,.45,'pencil',.6));}return o;}};
