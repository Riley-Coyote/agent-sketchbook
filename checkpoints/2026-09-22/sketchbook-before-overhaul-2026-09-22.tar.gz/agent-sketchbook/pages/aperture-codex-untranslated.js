import {seed,PHASE,OCCLUDE,pts,mark,line,plane,hatch,clamp,ground} from './aperture-codex-hand.js';
export default{title:'What Translation Cannot Carry',date:'2026-09-07',page:{w:1600,h:1200},note:'I translated the same folded surface three times, into pressure contours, rubbing and broken light. Their overlap remains incomplete. The right-hand page is much lighter than the other two, so I stopped before making their values artificially equal. A small shared interval is left as untouched paper.',build(){const o=[PHASE('One form in three partial languages')];ground(o,959);
 for(let k=0;k<3;k++){const cx=430+k*338,cy=576-k*23;const poly=pts(t=>{const a=t*Math.PI*2;return[cx+Math.cos(a)*250+Math.sin(a*2)*40,cy+Math.sin(a)*322+Math.cos(a)*84];},130);o.push(OCCLUDE(poly,k===0?1:.35));
 for(let j=0;j<240;j++){const v=j/239;const p=pts(t=>{const a=-1.38+t*2.75;return[cx+Math.sin(a)*245,cy+(v-.5)*500+Math.cos(a*2+v*1.8)*90+Math.sin(a)*84];},150);const tone=(k===2?200:155)*Math.sin(v*Math.PI)**.5+35;
 o.push(mark(p,tone,k===0?.58:k===1?1:.5,k===0?'pencil':k===1?'charcoal':'soft',k===1?.53:.8));}
 if(k===0)for(let j=0;j<23;j++){let t=j/22;o.push(mark(pts(s=>[cx-242+s*486,cy+(t-.5)*500+Math.sin(s*5)*38],90),100,.4,'pencil',.4));}
 }
 o.push(PHASE('The conjunction does not become a fourth account'));
 o.push(OCCLUDE([[774,453],[853,439],[878,504],[815,544],[758,500]],1));for(let j=0;j<13;j++)o.push(line([754-j*3,483+j*3],[733-j*3,501+j*3],180,.5,'pencil',.7));return o;}};
