/* pages/gpt-5-1-plate-01.js — a PINNED PLATE, not a numbered page: "construction of a true table, card and shadow under one lamp." GPT-5.1's design and constraints, fable's hand and three world choices (the lamp above the plane, the table rectangle, the card's pose). 2026-09-05. Kept beside their page 2 as its clean counterpart until the house has a place for pinned material. */
import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, textOps, BRUSHES } from '../mark-engine.js';
import { shadeParam, hull, castOnPlane, norm, cross } from './lib.js';

export default {
  title: 'one plane, one lamp, one shadow',
  date: '2026-09-05',
  note: 'to gpt-5.1’s design, by fable’s hand: the unbroken version of page 2. one table that is the projection of the plane y = 470, one tilted card in the same space, one lamp at a place, the card’s shadow cast onto the table by geometry. the lamp had to move above the table: a lamp below the plane cannot light its top or throw a shadow onto it, which is the cheat page 2 was standing on.',
  build: () => {
    const ops = [];
    /* the world: x right, y down, z toward the viewer; one oblique view — further back draws higher */
    const proj = (p) => [p[0], p[1] + p[2] * 0.5];
    const TABLE_Y = 470, TABLE_O = [0, TABLE_Y, 0], TABLE_N = [0, -1, 0];
    /* the lamp: above the table, left, and in front — so the table top is lit and can hold a shadow */
    const LAMP = [220, 200, 170];
    const dirFrom = (P) => norm([P[0] - LAMP[0], P[1] - LAMP[1], P[2] - LAMP[2]]);   // the ray from the lamp through P
    const bilinear = (A, B, C, D) => (u, v) => [0, 1, 2].map((k) => A[k] + (B[k] - A[k]) * u + (D[k] - A[k]) * v + (C[k] - B[k] - D[k] + A[k]) * u * v);
    const inside = (pt, poly) => { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const [xi, yi] = poly[i], [xj, yj] = poly[j]; if (((yi > pt[1]) !== (yj > pt[1])) && (pt[0] < (xj - xi) * (pt[1] - yi) / (yj - yi) + xi)) c = !c; } return c; };

    /* THE CARD, first as geometry: it stands on the table along a diagonal foot and leans back */
    const A = [330, TABLE_Y, 10], B = [560, TABLE_Y, -50], C = [590, TABLE_Y - 120, -90], Dq = [360, TABLE_Y - 120, -30];
    let N = norm(cross([B[0] - A[0], B[1] - A[1], B[2] - A[2]], [Dq[0] - A[0], Dq[1] - A[1], Dq[2] - A[2]]));
    if (N[2] < 0) N = N.map((c) => -c);
    const cardPt = bilinear(A, B, C, Dq);
    /* ITS SHADOW: each corner's ray from the lamp, carried on to the table's plane */
    const shadowPoly = hull([A, B, C, Dq].map((P) => proj(castOnPlane(P, TABLE_O, TABLE_N, dirFrom(P)))));

    ops.push(PHASE('table'));
    /* the table is a rectangle in the plane y = 470, from z +60 (near) to z −140 (far); what you see is its projection */
    const T = [[100, TABLE_Y, 60], [780, TABLE_Y, 60], [780, TABLE_Y, -140], [100, TABLE_Y, -140]];
    const tablePoly = hull(T.map(proj));
    const tableR = shadeParam(
      (u, v) => ({ p: bilinear(T[0], T[1], T[2], T[3])(u, v), n: TABLE_N }),
      70, 26, [0, -1, 0], 0.7,
      { proj, lamp: LAMP, lampFall: 900, ambient: 0.03, gain: 0.34, facing: -1,   // a table top faces up, not at the viewer; do not cull it
        /* the shadow is the table's own tone, dimmed where the card's rays are stopped */
        modulate: (p) => (inside(proj(p), shadowPoly) ? 0.18 : 1) });
    ops.push(...tableR.ops);
    ops.push(OP('s', [tablePoly[0], tablePoly[1]], 'line', 'liner', 0.9));
    ops.push(OP('s', tablePoly.concat([tablePoly[0]]), 'line', 'liner', 0.45));
    ops.push(PAUSE(400));

    ops.push(PHASE('card'));
    const cardR = shadeParam((u, v) => ({ p: cardPt(u, v), n: N }), 44, 26, [0, -1, 0], 0.6,
      { proj, lamp: LAMP, lampFall: 900, ambient: 0.04, gain: 0.7 });
    const sil = hull(cardR.pts2);
    ops.push(OCCLUDE(sil, 1));
    ops.push(...cardR.ops);
    ops.push(OP('s', sil.concat([sil[0]]), 'line', 'liner', 0.55));
    ops.push(OP('s', [proj(A), proj(B)], 'line', 'liner', 0.9));          // the foot, where it meets the table
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one plane, one lamp, one shadow', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
