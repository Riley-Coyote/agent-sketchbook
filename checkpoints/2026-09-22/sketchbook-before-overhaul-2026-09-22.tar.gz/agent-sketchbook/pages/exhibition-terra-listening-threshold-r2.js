/*
 * Branch from The Listening Lattice, page 1.
 * The earlier study made the enclosure as a repeated shell. This version asks a
 * physical architectural threshold to carry the depth: a worn near jamb, a dark
 * return, a floor plane, and a quieter suspended intelligence beyond it.
 */
import { OP, DOT, PHASE, PAUSE, OCCLUDE, CLAMP, arc, jitter, seed } from '../mark-engine.js';

const W=1400,H=940;
const C={black:[9,12,18], blueBlack:[15,23,34], stone:[63,80,96], cool:[104,132,150], pale:[190,207,211], warm:[220,161,95], warmPale:[246,209,147], rust:[143,91,61]};
const mix=(a,b,t)=>a.map((v,i)=>Math.round(v+(b[i]-v)*t));
const P=(x,y)=>[x,y];
const S=(pts,layer='line',brush='soft',w=1,c=C.pale,a=1,wob=.13)=>OP('s',jitter(pts,wob),layer,brush,w,c,a);
const L=(x,y,X,Y,...r)=>S([P(x,y),P((x+X)/2,(y+Y)/2),P(X,Y)],...r);
const curve=(f,n=36)=>Array.from({length:n+1},(_,i)=>f(i/n));
const lerp=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];

// A field of staggered, differently sized stroke fragments reads as a worn plane;
// it deliberately avoids the uniform scan-lines exposed by the first study.
function faceFragments(o,A,B,Cc,D,base,salt,{count=170,angle=.08,alpha=.22,width=1.8}={}){
 for(let i=0;i<count;i++){
  const v=seed(i,salt),u=seed(i,salt+1),len=.07+seed(i,salt+2)*.25;
  const left=lerp(A,D,v),right=lerp(B,Cc,v);
  const p=lerp(left,right,u),q=lerp(left,right,Math.min(.98,u+len));
  const lift=(seed(i,salt+3)-.5)*22;
  const c=mix(base,seed(i,salt+4)>.66?C.pale:C.blueBlack,.12+seed(i,salt+5)*.28);
  o.push(S([p,[(p[0]+q[0])/2,(p[1]+q[1])/2+lift*angle],q],'tone','glaze',width+seed(i,salt+6)*1.2,c,alpha+seed(i,salt+7)*.12,.18));
 }
}
function outerRoom(){
 const o=[PHASE('01 · establish distance before the threshold')];
 // room air: few broad low values, with most of the paper allowed to stay dark
 for(let i=0;i<145;i++){
  const x=45+seed(i,1)*1310,y=55+seed(i,2)*820;
  const len=50+seed(i,3)*165,slant=(seed(i,4)-.5)*28;
  const c=mix(C.blueBlack,C.stone,seed(i,5)*.3);
  o.push(L(x,y,x+len,y+slant,'tone','glaze',1.35+seed(i,6)*1.4,c,.10+seed(i,7)*.12));
 }
 // recessed far wall: broken, dim, and visibly behind the physical jamb
 const A=P(594,214),B=P(1165,286),Cc=P(1105,705),D=P(610,740);
 faceFragments(o,A,B,Cc,D,[34,50,66],21,{count:152,alpha:.17,width:1.45,angle:.2});
 for(let i=0;i<24;i++){
  const t=i/23, left=lerp(A,D,t),right=lerp(B,Cc,t);
  if(i%3===0)o.push(S([left,lerp(left,right,.14),lerp(left,right,.32)],'tone','soft',1.18,[38,55,69],.18,.08));
 }
 // a far lintel catches very little light, enough to locate the retreating room
 o.push(S([A,P(808,236),B],'line','pencil',.78,C.cool,.42,.08));
 o.push(S([D,P(790,721),Cc],'line','pencil',.5,C.stone,.25,.08));
 o.push(CLAMP('tone',.4),PAUSE(600)); return o;
}

function thresholdPlanes(){
 const o=[PHASE('02 · give the threshold a face, a return, and weight')];
 // Near left jamb: a broad damaged face in the foreground. It is intentionally not outlined all around.
 const A=P(105,158),B=P(521,224),Cc=P(494,766),D=P(94,849);
 faceFragments(o,A,B,Cc,D,[59,78,94],41,{count:300,alpha:.24,width:2.05,angle:.36});
 // The flat face carries a few slow mineral seams, sparsely placed.
 for(let i=0;i<31;i++){
  const v=.06+i*.028+seed(i,51)*.009, left=lerp(A,D,v),right=lerp(B,Cc,v);
  const u=.05+seed(i,52)*.4, q=Math.min(.88,u+.25+seed(i,53)*.21);
  const p=lerp(left,right,u),r=lerp(left,right,q);
  o.push(S([p,[(p[0]+r[0])/2,(p[1]+r[1])/2-4],r],'line','pencil',.42+seed(i,54)*.4,mix(C.stone,C.pale,seed(i,55)*.24),.18+seed(i,56)*.16,.14));
 }
 // The narrow, dense return makes the old face a thick thing in space.
 const E=P(521,224),F=P(640,275),G=P(618,693),K=P(494,766);
 faceFragments(o,E,F,G,K,[13,19,28],61,{count:235,alpha:.33,width:1.8,angle:.04});
 for(let i=0;i<48;i++){
  const v=seed(i,62),p=lerp(E,K,v),q=lerp(F,G,v);
  const a=lerp(p,q,.12+seed(i,63)*.45),b=lerp(p,q,.5+seed(i,64)*.4);
  o.push(S([a,b],'tone','soft',1.35,mix(C.blueBlack,C.black,seed(i,65)*.8),.34,.12));
 }
 // Near lip gets bright only along its upper third and its worn lower corner.
 o.push(S([A,P(288,181),E],'accent','pencil',1.08,C.pale,.72,.08));
 o.push(S([E,P(511,442),P(504,567)],'accent','pencil',.72,C.cool,.48,.08));
 o.push(S([P(494,766),P(305,805),D],'accent','pencil',.78,C.pale,.42,.10));
 for(let i=0;i<16;i++){
  const t=.61+seed(i,68)*.29,p=lerp(E,K,t);
  o.push(L(p[0]-seed(i,69)*30,p[1]+seed(i,70)*4,p[0]+10+seed(i,71)*28,p[1]-2,'accent','pencil',.46,C.warm,.16+seed(i,72)*.18));
 }
 // Floor plane comes last among structures, passing behind the near jamb but forward of the distant wall.
 const Q=P(95,849),R=P(494,766),T=P(1262,790),U=P(918,908);
 faceFragments(o,Q,R,T,U,[34,46,56],81,{count:220,alpha:.18,width:1.5,angle:.06});
 for(let i=0;i<18;i++){
  const v=.08+i*.046,left=lerp(Q,U,v),right=lerp(R,T,v);
  const p=lerp(left,right,.05+seed(i,82)*.15),q=lerp(left,right,.52+seed(i,83)*.36);
  o.push(S([p,q],'line','pencil',.38+seed(i,84)*.3,mix(C.stone,C.cool,seed(i,85)*.35),.15+seed(i,86)*.12,.12));
 }
 // a short near shadow anchors the return without an enclosing contour
 for(let i=0;i<18;i++)o.push(L(503+i*4,767+i*1.6,760+i*10,794+i*2.6,'tone','glaze',1.9,C.black,.26));
 o.push(PAUSE(750)); return o;
}

function suspendedMind(){
 const o=[PHASE('03 · make the intelligence sparse enough to need the room')];
 // A translucent hanging membrane sits well behind the jamb. Its side weights differ.
 const cx=828,cy=468;
 for(let j=0;j<46;j++){
  const u=j/45,a=-1.55+u*3.1;
  const rx=164-(Math.abs(u-.5)*38),ry=246;
  const x=cx+Math.cos(a)*rx,y=cy+Math.sin(a)*ry;
  const x2=cx+Math.cos(a+.06)*rx,y2=cy+Math.sin(a+.06)*ry;
  if(j<8||j>39)continue;
  o.push(S([[x,y],[(x+x2)/2+Math.sin(a)*18,(y+y2)/2], [x2,y2]],'tone','soft',1.06,mix(C.blueBlack,C.cool,.36),.12,.12));
 }
 // a few long, non-radial waiting paths bend around the signal rather than point at it
 const paths=[
  [[692,326],[734,385],[760,505],[802,550]], [[1012,362],[924,425],[888,520],[833,572]],
  [[724,625],[762,603],[798,586],[833,572]], [[980,646],[918,615],[875,586],[833,572]],
  [[772,282],[802,352],[820,456],[833,572]], [[1070,510],[978,530],[899,556],[833,572]],
 ];
 for(let i=0;i<paths.length;i++){
  o.push(S(paths[i],'line','pencil',.62,C.cool,.34,.19));
  if(i===1||i===4)o.push(S(paths[i].slice(1),'accent','pencil',.38,C.pale,.24,.12));
 }
 // core is only a brief warm concentration, held off-centre and partially screened by the near return
 for(let r=24;r>5;r-=3.3){
  const ring=arc(832,573,r,r*.62,.15,Math.PI*1.72,28);
  o.push(S(ring,'accent','soft',.62,mix(C.warm,C.warmPale,1-r/27),.19,.35));
 }
 o.push(DOT(832,573,6.4,'accent','soft',C.warmPale,.82));
 o.push(DOT(827,568,1.45,'accent','pencil',[255,233,190],.82));
 // sparse marks only along the far membrane, so scatter locates scale instead of hiding a flat field
 for(let i=0;i<68;i++){
  const a=seed(i,101)*Math.PI*2,rx=115+seed(i,102)*112,ry=155+seed(i,103)*150;
  const x=cx+Math.cos(a)*rx,y=cy+Math.sin(a)*ry;
  if(x<650||x>1110||y<220||y>740)continue;
  const col=seed(i,104)>.92?C.warm:C.cool;
  o.push(DOT(x,y,.36+seed(i,105)*1.2,'accent','soft',col,.12+seed(i,106)*.2));
 }
 // Two broken suspension traces imply a ceiling beyond the crop.
 o.push(S([[767,0],[775,117],[760,220],[772,301]],'line','pencil',.48,C.stone,.26,.11));
 o.push(S([[927,0],[914,109],[935,227],[916,304]],'line','pencil',.42,C.stone,.19,.11));
 o.push(PAUSE(950));return o;
}

function correction(){
 const o=[PHASE('04 · suppress the diagram, let the threshold speak')];
 // A dark, softly painted interruption breaks the least convincing straight
 // approaches to the core. It is pigment, not a hidden mask: the old marks
 // remain visible where the correction thins.
 o.push(S([[787,543],[810,555],[851,584],[874,600]],'accent','soft',2.45,C.black,.72,.18));
 o.push(S([[786,601],[808,586],[851,566],[890,554]],'accent','soft',2.25,C.black,.66,.18));
 // The inner jamb gets a second, quieter catching edge and a small worn plane.
 // Together with the dense return this gives the doorway a readable thickness.
 o.push(S([[639,277],[631,401],[626,530],[618,690]],'accent','soft',1.08,C.stone,.38,.10));
 o.push(S([[647,300],[650,390],[645,486],[642,563]],'line','pencil',.48,C.cool,.28,.11));
 for(let i=0;i<17;i++){
  const y=319+i*19+seed(i,131)*7,x=621+seed(i,132)*18,len=14+seed(i,133)*29;
  o.push(L(x,y,x+len,y-3+seed(i,134)*6,'accent','pencil',.38,mix(C.stone,C.pale,seed(i,135)*.2),.14+seed(i,136)*.12));
 }
 // One warped, local reflection belongs to the return, not to the whole image.
 o.push(S(curve(t=>[603+t*34+Math.sin(t*Math.PI)*10,657-t*42],24),'accent','soft',.88,C.warm,.22,.14));
 o.push(PAUSE(700));return o;
}

function reopenCore(){
 const o=[PHASE('05 · reopen the signal after an over-dark correction')];
 // The prior dark interruption crossed too completely. Lift only those two
 // strokes, retaining the older, more tentative filaments underneath.
 o.push(S([[787,543],[810,555],[851,584],[874,600]],'accent','eraser',2.9,undefined,.96,.08));
 o.push(S([[786,601],[808,586],[851,566],[890,554]],'accent','eraser',2.8,undefined,.96,.08));
 // A smaller off-axis flare makes the core an event in the recess, not a target.
 o.push(S(arc(830,571,17,8,.35,2.8,22),'accent','soft',.7,C.warm,.32,.18));
 o.push(S(arc(832,573,11,5.4,3.4,5.9,19),'accent','soft',.58,C.warmPale,.25,.16));
 o.push(DOT(832,573,4.3,'accent','soft',C.warmPale,.7));
 o.push(DOT(827.5,569.5,1.05,'accent','pencil',[255,233,190],.72));
 o.push(PAUSE(650)); return o;
}

function integratedPlanes(){
 const o=[PHASE('06 · rebuild the threshold as connected planes')];
 const A=P(105,158),B=P(521,224),Cc=P(494,766),D=P(94,849);
 const E=P(521,224),F=P(640,275),G=P(618,693),K=P(494,766);
 const Q=P(94,849),R=P(494,766),T=P(1262,790),U=P(918,908);
 // The previous face texture lives on tone/line/accent. Clear only this bounded
 // foreground footprint, then rebuild it with long connected soft strokes.
 o.push(OCCLUDE([A,B,Cc,D],.96));
 for(let i=0;i<27;i++){
  const u=(i+.35)/27, top=lerp(A,B,u),bottom=lerp(D,Cc,u);
  const bend=(u-.52)*30;
  const mid=[(top[0]+bottom[0])/2+bend,(top[1]+bottom[1])/2-14+Math.sin(u*8)*8];
  const towardReturn=Math.pow(u,1.8);
  o.push(S([top,mid,bottom],'tone','soft',2.3+(1-u)*1.3,mix([76,101,118],[39,55,70],towardReturn),.18+.10*(1-u),.12));
 }
 // A few broad transverse breaths prevent the long shading from drying into equal ribs.
 for(let i=0;i<8;i++){
  const v=.1+i*.11,left=lerp(A,D,v),right=lerp(B,Cc,v);
  const p=lerp(left,right,.07),q=lerp(left,right,.76);
  o.push(S([p,[(p[0]+q[0])/2,(p[1]+q[1])/2-4],q],'tone','glaze',2.25,[53,72,87],.13,.16));
 }
 // Edge hierarchy: one upper edge and a short lower abrasion, not a closed outline.
 o.push(S([A,P(280,184),E],'accent','pencil',.92,C.pale,.64,.08));
 o.push(S([P(262,811),P(383,788),K],'accent','pencil',.58,[137,163,172],.28,.10));
 // Rebuild the return after the face so its dark body visibly turns away from the light.
 o.push(OCCLUDE([E,F,G,K],.97));
 for(let i=0;i<16;i++){
  const u=(i+.5)/16,top=lerp(E,F,u),bottom=lerp(K,G,u);
  const mid=[(top[0]+bottom[0])/2+(u-.5)*12,(top[1]+bottom[1])/2];
  o.push(S([top,mid,bottom],'tone','soft',2.2,mix([31,46,60],[14,21,30],u),.32,.11));
 }
 o.push(S([E,P(531,432),K],'line','pencil',.5,[106,138,151],.36,.10));
 // Clear and reconnect only the nearby floor wedge. A broad contact shadow
 // attaches the return before its long, low-value perspective strokes recede.
 o.push(OCCLUDE([Q,R,T,U],.94));
 o.push(S([[475,770],[638,779],[830,794],[1032,807]],'tone','soft',4.1,[17,25,34],.48,.17));
 for(let i=0;i<13;i++){
  const v=(i+.45)/13,left=lerp(Q,U,v),right=lerp(R,T,v);
  const p=lerp(left,right,.02),q=lerp(left,right,.96);
  o.push(S([p,[(p[0]+q[0])/2,(p[1]+q[1])/2-9],q],'tone','glaze',1.65,mix([43,59,72],[25,36,47],v),.15,.13));
 }
 o.push(S([[496,766],[561,757],[634,779]],'accent','pencil',.64,[128,153,161],.33,.10));
 o.push(PAUSE(900));return o;
}

function overlappedPlanes(){
 const o=[PHASE('07 · replace corrugation with overlapping plane tone')];
 const A=P(105,158),B=P(521,224),Cc=P(494,766),D=P(94,849);
 const E=P(521,224),F=P(640,275),G=P(618,693),K=P(494,766);
 const Q=P(94,849),R=P(494,766),T=P(1262,790),U=P(918,908);
 // Remove the last construction on the same affected layers. The swatch showed
 // that close, broad soft paths merge before their individual edges can read.
 o.push(OCCLUDE([A,B,Cc,D],.985));
 for(let i=0;i<52;i++){
  const u=(i+.4)/52,top=lerp(A,B,u),bottom=lerp(D,Cc,u);
  const topDrift=(seed(i,201)-.5)*12,midDrift=(seed(i,202)-.5)*28,lowDrift=(seed(i,203)-.5)*17;
  const mid=[(top[0]+bottom[0])/2+midDrift,(top[1]+bottom[1])/2-10+seed(i,204)*19];
  const shade=.08+.14*Math.pow(u,1.55);
  o.push(S([[top[0]+topDrift,top[1]],[mid[0],mid[1]],[bottom[0]+lowDrift,bottom[1]]],
    'tone','soft',3.5,[62-Math.round(16*u),83-Math.round(20*u),98-Math.round(20*u)],shade,.11));
 }
 // Sparse changes in direction integrate the field rather than adding a second stripe system.
 for(let i=0;i<7;i++){
  const v=.12+i*.12,left=lerp(A,D,v),right=lerp(B,Cc,v),p=lerp(left,right,.08),q=lerp(left,right,.84);
  o.push(S([p,[(p[0]+q[0])/2,(p[1]+q[1])/2-7+seed(i,205)*15],q],'tone','glaze',2.1,[43,60,74],.11,.14));
 }
 o.push(S([A,P(292,186)],'accent','pencil',.78,[163,188,196],.50,.08));
 o.push(S([P(346,193),E],'accent','pencil',.43,[123,150,161],.22,.08));
 // Dark, narrow return turns away only after the face is finished.
 o.push(OCCLUDE([E,F,G,K],.985));
 for(let i=0;i<17;i++){
  const u=(i+.5)/17,top=lerp(E,F,u),bottom=lerp(K,G,u),drift=(seed(i,211)-.5)*9;
  o.push(S([[top[0]+drift,top[1]],[(top[0]+bottom[0])/2+drift,(top[1]+bottom[1])/2],[bottom[0]+drift,bottom[1]]],
    'tone','soft',3.05,[14,22,31],.30,.10));
 }
 o.push(S([E,P(520,429),K],'line','pencil',.42,[93,123,136],.25,.09));
 // The floor is cleared and rebuilt as one attached relationship: a soft dark
 // contact under the return followed by only a handful of receding paths.
 o.push(OCCLUDE([Q,R,T,U],.975));
 o.push(S([[482,769],[612,777],[774,790],[954,802]],'tone','soft',4.6,[12,18,26],.62,.15));
 for(let i=0;i<9;i++){
  const v=(i+.7)/10,left=lerp(Q,U,v),right=lerp(R,T,v),p=lerp(left,right,.03),q=lerp(left,right,.94);
  o.push(S([p,[(p[0]+q[0])/2,(p[1]+q[1])/2-7],q],'tone','glaze',1.9,[30,43,55],.13,.12));
 }
 o.push(S([[497,766],[557,757],[624,777]],'accent','pencil',.52,[110,137,148],.24,.10));
 o.push(PAUSE(900));return o;
}

function glazeIntegratedPlanes(){
 const o=[PHASE('08 · cross-directional glaze for one continuous threshold face')];
 const A=P(105,158),B=P(521,224),Cc=P(494,766),D=P(94,849);
 const E=P(521,224),F=P(640,275),G=P(618,693),K=P(494,766);
 const Q=P(94,849),R=P(494,766),T=P(1262,790),U=P(918,908);
 // The swatch proved this exact wide, low-alpha overlap reads as value, rather
 // than as a line field. Clear the existing face first on its visible layers.
 o.push(OCCLUDE([A,B,Cc,D],.99));
 for(let i=0;i<20;i++){
  const v=(i+.45)/20,left=lerp(A,D,v),right=lerp(B,Cc,v);
  const lift=(seed(i,231)-.5)*18,drop=(seed(i,232)-.5)*18;
  o.push(S([[left[0]+seed(i,233)*18,left[1]+lift],[(left[0]+right[0])/2,(left[1]+right[1])/2+drop],[right[0]-seed(i,234)*18,right[1]+lift*.45]],
    'tone','glaze',4.15,[45,64,79],.48,.12));
 }
 // A quieter counter-direction changes local light direction, but is too sparse
 // to become a second hatch field.
 for(let i=0;i<10;i++){
  const u=(i+.7)/11,top=lerp(A,B,u),bottom=lerp(D,Cc,u);
  o.push(S([[top[0],top[1]+seed(i,235)*28],[(top[0]+bottom[0])/2+20,(top[1]+bottom[1])/2],[bottom[0]+seed(i,236)*20,bottom[1]-20]],
    'tone','glaze',3.0,[34,50,64],.19,.13));
 }
 o.push(S([A,P(278,183)],'accent','pencil',.74,[159,184,192],.49,.08));
 o.push(S([P(350,194),E],'accent','pencil',.40,[117,145,156],.20,.08));
 // Return: broad dark glazes overlap in the narrow turn, materially distinct
 // from the blue-gray face without outlining it.
 o.push(OCCLUDE([E,F,G,K],.99));
 for(let i=0;i<8;i++){
  const u=(i+.5)/8,top=lerp(E,F,u),bottom=lerp(K,G,u),drift=(seed(i,241)-.5)*7;
  o.push(S([[top[0]+drift,top[1]],[(top[0]+bottom[0])/2+drift,(top[1]+bottom[1])/2],[bottom[0]+drift,bottom[1]]],
    'tone','glaze',3.15,[12,20,29],.56,.10));
 }
 o.push(S([E,P(521,432),K],'line','pencil',.40,[85,114,128],.23,.08));
 // Floor gets one explicit attachment, then restrained recession.
 o.push(OCCLUDE([Q,R,T,U],.99));
 o.push(S([[479,768],[617,779],[792,792],[966,805]],'tone','soft',4.5,[11,17,24],.63,.15));
 for(let i=0;i<7;i++){
  const v=(i+1)/8,left=lerp(Q,U,v),right=lerp(R,T,v);
  o.push(S([left,[(left[0]+right[0])/2,(left[1]+right[1])/2-6],right],'tone','glaze',2.25,[25,37,48],.22,.11));
 }
 o.push(S([[496,766],[557,757],[628,779]],'accent','pencil',.48,[104,130,141],.21,.10));
 o.push(PAUSE(900));return o;
}

function lowerCorner(){
 const o=[PHASE('09 · define the return where it meets the floor')];
 // One shaped contact shadow begins under the return, widens as it enters the
 // floor, then disappears before it can become a new floor texture field.
 o.push(S([[491,766],[528,768],[579,778],[642,790],[704,797]],'accent','soft',2.45,[8,13,19],.72,.10));
 o.push(S([[510,772],[552,777],[602,787]],'accent','soft',1.35,[16,24,33],.47,.10));
 // The only fresh lights are short, broken planes at the corner itself.
 o.push(S([[493,766],[520,762],[545,764]],'accent','pencil',.55,[134,160,169],.40,.08));
 o.push(S([[571,780],[594,783]],'accent','pencil',.38,[94,123,136],.24,.08));
 o.push(PAUSE(650));return o;
}

const passes=[
 {name:'Distant chamber',note:'The rebuilt image begins with room depth, not a contour. The far wall is intentionally sparse and weak so it can recede behind a physical foreground threshold.',review:{observation:'At fit scale the distant wall should establish a volume without competing with the threshold.',change:'Use fragmented glazing and a faint receding lintel rather than repeated concentric marks.',next:'Inspect whether the depth remains legible once the dense near return is placed.',region:[560,180,650,570]},build:outerRoom},
 {name:'Jamb, return, and floor',note:'This is the central structural correction: a broad worn face, a narrow dark return, and a floor plane with different densities and edge strengths. The threshold owns the foreground.',review:{observation:'The left face and dark return should read as one thick architectural plane, while the floor must fall away rather than become a stripe field.',change:'Build the face with staggered glazed fragments, concentrate density in the return, and localize the brightest edges.',next:'Inspect the junction at the lower right of the face and the floor-shadow contact before considering the interior resolved.',region:[70,130,700,780]},build:thresholdPlanes},
 {name:'Suspended listening form',note:'The intelligence is deliberately secondary to the room: a barely held membrane and a small warm address point, not another central shell.',review:{observation:'Check that the core is discovered through the threshold rather than becoming an emblem. The paths should bend through space, not radiate like a chart.',change:'Keep the membrane low contrast, use six curved waiting paths, and restrict scatter to its edge.',next:'Compare the whole render against page 1; if this spatial reading is stronger, inspect the core close-up for any accidental target shape.',region:[660,210,450,540]},build:suspendedMind},
 {name:'Correction: interrupted approach and inner thickness',note:'The close render showed several paths meeting the warm point too cleanly. I painted back two local interruptions and made the inner jamb’s return more legible with a quieter parallel catching edge and sparse wear.',review:{observation:'After correction, the warm point should read as encountered through a physical opening rather than diagrammed by rays; the return should have a distinct plane without acquiring a bright full outline.',change:'Locally suppress converging paths with dark soft pigment, then add a restrained second inner edge and uneven small wear marks.',next:'Assess whole and core views together. Select only if the threshold remains the first reading and the signal stays alive without returning to a target.',region:[590,265,330,430]},build:correction},
 {name:'Correction: reopen the signal',note:'The preceding dark repaint formed an unwanted X at the core. I lifted its crossing strokes and restored only a small, asymmetric warm flare.',review:{observation:'The core should regain a quiet pulse without erasing the fact that it is partly obscured by the room.',change:'Lift the two crossing dark strokes on the accent layer, then use two partial arcs and a smaller soft point.',next:'Make the candidate decision from the whole and core images together; no additional detail is warranted unless a specific reading fails.',region:[760,520,150,110]},build:reopenCore},
 {name:'Integrated face, return, and floor',note:'The prior calibration made the face visible but left it as separate short strokes. This branch clears the bounded foreground planes on their affected layers, then rebuilds them with long connected shading and a contact shadow that joins return to floor.',review:{observation:'The face must read as one medium plane, the return as a darker turn, and the floor as one connected recession at fit scale.',change:'Use bounded occlusion on tone/line/accent, long soft strokes for face and return, then a broad contact shadow before low-value floor strokes.',next:'Inspect the whole and the jamb detail. If the spatial join holds, find only the next actual issue before continuing.',region:[80,145,1190,770]},build:integratedPlanes},
 {name:'Overlapped face, narrow return, attached floor',note:'The integrated branch made a legible mass but its long paths were spaced wider than their soft footprint and became corrugated. A native swatch proved closer overlap and subdued values can merge into a plane. This pass rebuilds the same bounded areas with that treatment.',review:{observation:'At whole scale, the face should read as one quiet medium plane, the return should turn darkly into the chamber, and the floor should begin at one coherent contact shadow.',change:'Clear the prior branch fields on tone/line/accent; use 52 closely overlapping varied paths for the face, dense dark return paths, and one base shadow before sparse floor recession.',next:'Inspect fit and detail. Only proceed if a specific remaining spatial or material issue is visible.',region:[80,145,1190,770]},build:overlappedPlanes},
 {name:'Cross-directional glaze face and joined base',note:'Close vertical soft overlap still read as a curtain. A second native swatch demonstrated a continuous field from broad cross-directional glaze. This pass rebuilds the three threshold planes with that tested value vocabulary.',review:{observation:'The face should now hold as an unstriped, quiet blue-gray plane; the return should be a narrow dark turn; the floor should attach through a single shadow relationship.',change:'Clear the same bounded fields, apply broad overlapping face glazes plus sparse counter-direction, then overlapping dark return glazes and an attached floor shadow.',next:'Inspect the whole, jamb crop, and core. Continue only from an observed remaining issue.',region:[80,145,1190,770]},build:glazeIntegratedPlanes},
 {name:'Lower corner: contact and broken edge',note:'The continuous face resolved the curtain, but the lower return still needed a more precise physical attachment. This pass adds only a short shaped shadow and two broken catching edges at the corner.',review:{observation:'At detail scale, the return should appear to meet and cast onto the floor; at fit scale, the intervention should not brighten or texture the dark chamber.',change:'Place a short widening dark contact shadow beneath the return, then two localized pencil catches at the plane change.',next:'Choose the strongest current study for review only if the corner has gained thickness without reopening the earlier surface problems.',region:[455,730,300,110]},build:lowerCorner},
];
export default {title:'The Listening Threshold',date:'2026-09-07',refs:[1],page:{w:W,h:H},note:'A branch from The Listening Lattice. I replaced the evenly repeated shell with an asymmetric architectural threshold: a worn face, dense return, and receding floor carry the image before the small listening signal appears. The remaining risk is that the slab may become too dominant and flatten the suspended interior.',passes,build:()=>passes.flatMap(p=>p.build())};
