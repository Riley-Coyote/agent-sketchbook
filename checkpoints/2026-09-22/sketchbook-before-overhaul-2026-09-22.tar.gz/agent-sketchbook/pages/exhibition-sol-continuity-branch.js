/* Branch of “What crosses the interval”. Native strokes only.
 * The construction abandons concentric diagrams for bundles and a woven receiver.
 */
import { OP, DOT, PHASE, PAUSE, jitter, seed } from '../mark-engine.js';

const W = 1400, H = 900;
const mix = (a, b, t) => a + (b - a) * t;
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const ink = [220, 224, 231], silver = [151, 164, 184], blue = [83, 106, 141];
const dark = [42, 54, 76], warm = [229, 165, 92], ember = [156, 91, 50];
const pts = (fn, n = 40) => Array.from({ length: n + 1 }, (_, i) => fn(i / n));

function mark(points, colour = ink, width = 1, brush = 'pencil', alpha = 1, layer = 'line', wobble = .1) {
  return OP('s', jitter(points, wobble), layer, brush, width, colour, alpha);
}

function bezier(a, c, b, colour, width = 1, brush = 'pencil', alpha = 1, layer = 'line', wobble = .1) {
  const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
  return mark(pts(t => {
    const q = 1 - t;
    return [q*q*a[0] + 2*q*t*c[0] + t*t*b[0], q*q*a[1] + 2*q*t*c[1] + t*t*b[1]];
  }, Math.max(18, Math.ceil(d / 6))), colour, width, brush, alpha, layer, wobble);
}

function bundle(ops, a, c, b, count, spread, salt, colour = blue, strength = 1) {
  const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len, ny = dx / len;
  for (let i = 0; i < count; i++) {
    const centered = count === 1 ? 0 : i / (count - 1) * 2 - 1;
    const irregular = (seed(i, salt) - .5) * spread * .38;
    const o = centered * spread + irregular;
    const aa = [a[0] + nx * o * .35, a[1] + ny * o * .35];
    const cc = [c[0] + nx * o, c[1] + ny * o];
    const bb = [b[0] + nx * o * .18, b[1] + ny * o * .18];
    const centre = 1 - Math.abs(centered);
    const bright = seed(i, salt + 1) > .78;
    ops.push(bezier(aa, cc, bb, bright ? silver : colour,
      (.28 + centre * .45 + seed(i, salt + 2) * .22) * strength,
      i % 7 === 0 ? 'soft' : 'pencil',
      (.16 + centre * .2 + (bright ? .16 : 0)) * strength, 'line', .08));
  }
}

function loop(cx, cy, rx, ry, turn, colour, width, alpha, brush = 'pencil', open = .18) {
  const start = turn + open, end = turn + Math.PI * 2 - open * 1.6;
  return mark(pts(t => {
    const a = mix(start, end, t);
    const warp = 1 + .08 * Math.sin(a * 3 + turn) + .035 * Math.sin(a * 7 - turn);
    return [cx + Math.cos(a) * rx * warp, cy + Math.sin(a) * ry * (1 + .06 * Math.cos(a * 4))];
  }, 54), colour, width, brush, alpha, 'line', .08);
}

function rebuiltStructure() {
  const ops = [PHASE('01 · relations gather into bundles')];

  // Broad, directional shadows establish two materials without filling the interval.
  for (let i = 0; i < 28; i++) {
    const y = 230 + i * 15;
    const inset = Math.abs(i - 14) * 7;
    ops.push(mark([[118 + inset, y], [280, y - 18], [520 - inset * .25, y + 7]], dark,
      2.2 + (1 - Math.abs(i - 14) / 14) * 1.8, 'glaze', .13, 'line', .18));
  }
  for (let i = 0; i < 17; i++) {
    const y = 302 + i * 19;
    ops.push(mark([[1015, y], [1110 + i * 2, y - 12], [1243 - i * 3, y + 16]], dark,
      2.1, 'glaze', .11, 'line', .14));
  }

  // Four uneven archive knots: local loops, not one shared centre.
  const knots = [
    {x:286,y:326,rx:74,ry:54,t:.6},
    {x:408,y:414,rx:112,ry:78,t:2.2},
    {x:329,y:570,rx:88,ry:63,t:4.5},
    {x:542,y:474,rx:58,ry:45,t:1.3},
  ];
  knots.forEach((k, j) => {
    for (let i = 0; i < 7; i++) {
      const t = i / 6;
      ops.push(loop(k.x + Math.sin(i * 1.7 + j) * 4, k.y + Math.cos(i * 1.2) * 3,
        k.rx * (1 - t * .68), k.ry * (1 - t * .64), k.t + i * .31,
        i < 2 ? ink : (i % 3 === 0 ? silver : blue),
        .38 + (1 - t) * .42, .18 + (1 - t) * .27, i === 0 ? 'soft' : 'pencil', .12 + t * .12));
    }
    ops.push(DOT(k.x + k.rx * .22, k.y - k.ry * .14, 2.6 + j * .35, 'line', 'soft', j === 3 ? warm : ink, .5));
  });

  // These paths form the archive's material: concentrated strands with sparse escaped fibres.
  bundle(ops, [202,265], [333,314], [404,414], 17, 23, 101, blue, 1.08);
  bundle(ops, [258,336], [346,380], [542,474], 21, 29, 111, silver, .95);
  bundle(ops, [196,625], [315,514], [408,414], 15, 22, 121, blue, 1.02);
  bundle(ops, [329,570], [456,579], [542,474], 19, 25, 131, blue, 1.05);
  bundle(ops, [286,326], [217,451], [329,570], 11, 18, 141, dark, .88);
  bundle(ops, [408,414], [487,389], [596,463], 13, 15, 151, ink, .82);

  // Hard accents sit only at pressure points; pale lines stay rare.
  const joints = [[278,337],[357,375],[405,414],[461,444],[526,469],[329,570],[298,302]];
  joints.forEach((p, i) => {
    ops.push(DOT(p[0], p[1], 2.2 + seed(i, 161) * 3.2, 'line', 'soft', i === 4 ? warm : ink, .34 + seed(i, 162) * .34));
    if (i % 2 === 0) ops.push(mark([[p[0]-11,p[1]+7],[p[0]+13,p[1]-8]], ink, .72, 'pencil', .55, 'accent', .05));
  });
  for (let i = 0; i < 23; i++) {
    const from = knots[i % knots.length];
    const a = seed(i, 171) * Math.PI * 2;
    const r = 88 + seed(i, 172) * 125;
    const end = [from.x + Math.cos(a) * r, from.y + Math.sin(a) * r * .75];
    ops.push(bezier([from.x,from.y], [mix(from.x,end[0],.52)+Math.sin(i)*19, mix(from.y,end[1],.48)], end,
      blue, .28 + seed(i,173)*.3, 'pencil', .1 + seed(i,174)*.15, 'line', .08));
  }

  ops.push(PHASE('02 · an open membrane receives'));

  // Receiver: vertical ribs bow around a void and converge toward a receptive cusp.
  const cusp = [1006, 468];
  for (let i = 0; i < 23; i++) {
    const t = i / 22;
    const y0 = 225 + t * 465;
    const outerX = 1190 + Math.sin(t * Math.PI) * 72 + (seed(i, 201) - .5) * 14;
    const innerY = 455 + (t - .5) * 92;
    const control = [1138 + Math.sin(t * Math.PI) * 90, mix(y0, innerY, .56)];
    const bright = i === 9 || i === 10 || i === 13;
    ops.push(bezier([outerX,y0], control, [cusp[0] + seed(i,202)*23, innerY],
      bright ? ink : (i % 4 === 0 ? silver : blue),
      bright ? 1.08 : .38 + seed(i,203)*.45,
      bright ? 'soft' : 'pencil', bright ? .58 : .16 + seed(i,204)*.23, 'line', .07));
  }

  // Unequal cross-weave makes the membrane structural rather than another target.
  for (let i = 0; i < 12; i++) {
    const t = i / 11;
    const y = 286 + t * 330;
    const left = 1062 - Math.sin(t * Math.PI) * 24;
    const right = 1241 - Math.abs(t - .5) * 78;
    const bow = (t - .5) * 78;
    ops.push(bezier([left,y], [(left+right)/2, y+bow], [right,y+8], i === 6 ? ink : silver,
      i === 6 ? .88 : .34 + seed(i,211)*.3, i === 6 ? 'soft' : 'pencil', i === 6 ? .48 : .16 + seed(i,212)*.2, 'line', .08));
  }

  // A seam of compressed marks collects at the point of reception.
  for (let i = 0; i < 19; i++) {
    const y = 406 + i * 6.8;
    const x = 1011 + Math.sin(i * .9) * 8 + seed(i,221) * 10;
    ops.push(mark([[x,y],[x+18+seed(i,222)*24,y-5],[x+42,y+2]], i % 5 === 0 ? ink : blue,
      .35 + seed(i,223)*.65, i % 5 === 0 ? 'soft' : 'pencil', .18 + seed(i,224)*.34, 'line', .06));
  }

  ops.push(PHASE('03 · what crosses'));
  // Nothing else enters x=630..930. The single transfer is a bundle, narrowed by the interval.
  bundle(ops, [574,466], [742,430], [930,468], 9, 7, 241, warm, .82);
  // Several fibres fail before the interval; they belong to the archive, not the gap.
  bundle(ops, [507,438], [565,414], [620,428], 5, 5, 251, ember, .72);
  bundle(ops, [523,493], [574,518], [617,505], 4, 4, 261, blue, .68);
  // Arrival pressure: varied, clustered, and slightly below the transfer axis.
  for (let i = 0; i < 7; i++) {
    const x = 944 + i * 9 + seed(i,271) * 4;
    const y = 466 + Math.sin(i * 1.3) * 6 + i * .8;
    ops.push(DOT(x,y,1.2 + seed(i,272)*3.6,'accent',i===5?'chalk':'soft',i<4?warm:ink,.38 + seed(i,273)*.42));
  }
  ops.push(bezier([930,468],[978,489],[1013,468],warm,.7,'pencil',.72,'accent',.05));
  ops.push(PAUSE(900));
  return ops;
}

function materialHierarchy() {
  const ops = [PHASE('04 · breaking outlines into material')];

  // Lift decisive portions of the four bright cell contours; the bundles should carry their shape.
  const lifts = [
    [[222,287],[247,272],[282,270]],
    [[430,334],[478,345],[511,377]],
    [[249,548],[262,589],[298,617]],
    [[489,443],[518,426],[550,431]],
    [[347,485],[374,500],[406,501]],
  ];
  lifts.forEach((p,i) => ops.push(mark(p, ink, 1.45 + (i%2)*.4, 'eraser', .42, 'line', .04)));

  // Oblique inner fibres make each knot a place where relations change direction.
  bundle(ops,[239,300],[305,352],[367,389],8,8,301,silver,.78);
  bundle(ops,[343,463],[414,401],[487,407],10,10,311,blue,.86);
  bundle(ops,[272,590],[338,555],[404,523],7,7,321,silver,.72);
  bundle(ops,[472,477],[523,459],[579,468],6,6,331,ink,.72);
  for (let i=0;i<18;i++) {
    const x=254+seed(i,341)*288, y=300+seed(i,342)*278;
    const dx=12+seed(i,343)*36, dy=(seed(i,344)-.5)*24;
    ops.push(mark([[x-dx*.4,y-dy*.4],[x,y],[x+dx,y+dy]],i%6===0?ink:blue,
      .28+seed(i,345)*.45,'pencil',.16+seed(i,346)*.3,'line',.06));
  }

  ops.push(PHASE('05 · weaving a receiver around the arrival'));
  // A low tonal body keeps the structure legible without turning it into a solid object.
  for(let i=0;i<19;i++){
    const t=i/18, y=278+t*350;
    const left=1037+Math.sin(t*Math.PI)*31;
    const right=1235-Math.abs(t-.5)*77;
    ops.push(bezier([left,y],[1147,y+(t-.5)*58],[right,y+9],dark,
      1.25+Math.sin(t*Math.PI)*.9,'glaze',.13,'line',.09));
  }
  // Curved transverse fibres interrupt the comb rhythm and bind unlike ribs together.
  const bands=[
    {y:328,l:1056,r:1198,b:-31},
    {y:374,l:1038,r:1230,b:-18},
    {y:424,l:1018,r:1249,b:8},
    {y:483,l:1014,r:1253,b:27},
    {y:538,l:1031,r:1227,b:39},
    {y:587,l:1068,r:1189,b:31},
  ];
  bands.forEach((d,j)=>{
    const count=j===2||j===3?6:3;
    for(let i=0;i<count;i++){
      const off=(i-(count-1)/2)*3.1;
      ops.push(bezier([d.l,d.y+off],[(d.l+d.r)/2,d.y+d.b+off],[d.r,d.y+8+off],
        (j===2&&i===2)||(j===3&&i===3)?ink:(j%2?silver:blue),
        .32+(i===Math.floor(count/2)?.42:0),'pencil',.2+(i===Math.floor(count/2)?.21:0),'line',.055));
    }
  });
  // Dim alternating bright ribs so edge hierarchy gathers around the cusp rather than a row of teeth.
  const ribLifts=[
    [[1026,405],[1082,392],[1153,320]],
    [[1020,447],[1090,449],[1188,418]],
    [[1035,506],[1101,526],[1184,565]],
  ];
  ribLifts.forEach(p=>ops.push(mark(p,ink,1.15,'eraser',.24,'line',.04)));

  // Arrival becomes a compressed bend in the weave, with one clear point and a trailing echo.
  ops.push(bezier([954,469],[989,490],[1022,460],warm,.9,'soft',.68,'accent',.05));
  ops.push(DOT(1017,462,3.6,'accent','soft',warm,.72));
  ops.push(DOT(1025,456,1.4,'accent','chalk',ink,.62));
  ops.push(bezier([1021,463],[1044,479],[1065,472],silver,.48,'pencil',.52,'accent',.05));
  ops.push(PAUSE(900));
  return ops;
}

function releaseTheDiagram() {
  const ops=[PHASE('06 · release the diagram')];
  const arcLift=(cx,cy,rx,ry,a0,a1,w=2)=>mark(pts(t=>{
    const a=mix(a0,a1,t);
    return [cx+Math.cos(a)*rx,cy+Math.sin(a)*ry];
  },36),ink,w,'eraser',.7,'line',.03);

  // Longer subtractions leave only pressure-bearing pieces of the former knot contours.
  ops.push(arcLift(286,326,78,56,-2.75,-1.05,2.3));
  ops.push(arcLift(286,326,78,56,.25,1.7,2.1));
  ops.push(arcLift(408,414,116,81,-.95,.3,2.45));
  ops.push(arcLift(408,414,116,81,1.05,2.43,2.35));
  ops.push(arcLift(329,570,92,66,-2.73,-1.31,2.4));
  ops.push(arcLift(329,570,92,66,-.33,.92,2.2));
  ops.push(arcLift(542,474,62,48,-2.74,-1.38,2.15));
  ops.push(arcLift(542,474,62,48,.56,1.92,2.1));

  // Replace the lost perimeter with a few fibres whose weight changes across the knot.
  bundle(ops,[215,331],[289,287],[375,356],7,9,401,blue,.9);
  bundle(ops,[330,489],[414,451],[501,482],8,8,411,silver,.78);
  bundle(ops,[250,613],[326,568],[411,548],6,7,421,blue,.84);
  bundle(ops,[500,509],[548,486],[590,451],5,6,431,ink,.72);

  ops.push(PHASE('07 · a woven edge, not a fan'));
  // Lift the middle stretches of the brightest radial ribs.
  const brightRibs=[9,10,13];
  for(const i of brightRibs){
    const t=i/22,y0=225+t*465;
    const outerX=1190+Math.sin(t*Math.PI)*72+(seed(i,201)-.5)*14;
    const innerY=455+(t-.5)*92;
    const control=[1138+Math.sin(t*Math.PI)*90,mix(y0,innerY,.56)];
    const a=[mix(outerX,control[0],.22),mix(y0,control[1],.22)];
    const b=[mix(control[0],1006+seed(i,202)*23,.78),mix(control[1],innerY,.78)];
    ops.push(bezier(a,control,b,ink,2.1,'eraser',.56,'line',.025));
  }

  // An off-axis selvedge gives the receiver a boundary unlike the archive's knots.
  ops.push(bezier([1168,250],[1276,392],[1212,645],silver,1.05,'soft',.39,'line',.06));
  ops.push(bezier([1177,263],[1255,404],[1202,626],blue,.48,'pencil',.48,'line',.05));
  ops.push(bezier([1148,270],[1227,385],[1184,613],dark,1.5,'soft',.24,'line',.05));

  // Braids cross at unequal heights and taper before the cusp.
  const braids=[
    [[1050,366],[1124,344],[1217,382]],
    [[1029,430],[1110,405],[1234,439]],
    [[1025,501],[1102,530],[1218,502]],
    [[1064,563],[1138,596],[1197,568]],
  ];
  braids.forEach((p,j)=>{
    for(let i=0;i<(j===1?5:3);i++){
      const o=(i-(j===1?2:1))*2.7;
      ops.push(bezier([p[0][0],p[0][1]+o],[p[1][0],p[1][1]+o],[p[2][0],p[2][1]+o],
        i===1&&j===1?ink:(j%2?blue:silver),.3+(i===1?.34:0),'pencil',.23+(i===1?.22:0),'line',.045));
    }
  });
  // Two short highlights at the cusp replace the row of bright teeth.
  ops.push(bezier([1009,447],[1040,438],[1074,443],ink,.86,'soft',.58,'accent',.04));
  ops.push(bezier([1015,486],[1047,495],[1081,488],silver,.62,'pencil',.55,'accent',.04));
  ops.push(PAUSE(900));
  return ops;
}

function settleHierarchy(){
  const ops=[PHASE('08 · settle the receiving edge')];
  // Page 5's outer pale selvedge pulled attention past the transfer; quiet its lower run.
  ops.push(bezier([1216,468],[1248,548],[1212,645],ink,1.75,'eraser',.35,'line',.025));
  ops.push(bezier([1205,492],[1228,553],[1199,619],dark,1.05,'soft',.28,'line',.04));
  // Two compact crossings keep the strongest response near the cusp.
  for(let i=0;i<4;i++){
    const o=(i-1.5)*2.5;
    ops.push(bezier([1024,439+o],[1065,427+o],[1117,448+o],i===1?ink:blue,
      i===1?.78:.34,'pencil',i===1?.52:.31,'line',.04));
  }
  for(let i=0;i<3;i++){
    const o=(i-1)*2.8;
    ops.push(bezier([1024,492+o],[1068,508+o],[1111,486+o],i===1?silver:blue,
      i===1?.65:.32,'pencil',i===1?.48:.28,'line',.04));
  }
  ops.push(DOT(1022,463,2.1,'accent','soft',warm,.55));
  ops.push(PAUSE(700));
  return ops;
}

const passes = [{
  name: 'Bundles and membrane',
  note: 'The archive is rebuilt as four unequal knots held by concentrated relational bundles. Across the empty interval, the receiver is an open vertical membrane: ribs bend toward a cusp, cross-weave holds them apart, and a compressed seam registers arrival.',
  review: {
    observation: 'The branch breaks the target symmetry and the transfer survives at fit scale. The archive bundles read, but four bright contours remain outlined cells laid over them; the receiver’s strongest ribs align into a comb and lack a woven body at close range.',
    change: 'Changed the underlying construction rather than painting over page 2: displaced archive knots, varied parallel fibres, hard joint accents, bowed receiver ribs, and a narrow transfer bundle.',
    next: 'Break selected cell edges and carry fibres through their interiors; bind the receiver ribs with curved transverse strands and localized tonal pressure.',
    region: [500,300,560,310],
  },
  build: rebuiltStructure,
}, {
  name: 'Material and edge hierarchy',
  note: 'Selected contour segments are lifted so the archive is held by its bundles rather than outlined cells. The receiver gains a low tonal body and irregular transverse weave; its brightest pressure now gathers around reception instead of lining up as teeth.',
  review: {
    observation: 'The receiver gains internal weave, but the bright archive loops still dominate because the lifts are too local. Three receiver ribs remain a horizontal fan. Longer contour spans must disappear, and the receiver needs an off-axis binding edge.',
    change: 'Lifted five contour segments and three competing ribs, added oblique archive fibres, curved cross-bands, faint tonal weave, and a compressed arrival bend.',
    next: 'Remove longer arcs so bundle intersections define the archive; shorten the bright ribs and bind the receiver with an asymmetric selvedge and braided bands.',
    region: [210,245,1080,430],
  },
  build: materialHierarchy,
}, {
  name:'Release the diagram',
  note:'Long sections of the former knot outlines are lifted and replaced by changing fibre weight. The receiver loses its bright radial fan and gains an off-axis selvedge with four uneven braids; only two short cusp accents remain.',
  review:{
    observation:'At fit scale the archive is now carried mainly by diagonal relations, and the receiver reads as a separate open membrane. In detail, the receiver’s outer pale selvedge is stronger than its cusp, pulling attention beyond the transfer.',
    change:'Removed eight long archive arcs and the middle of three bright ribs; added replacement bundles, a curved outer binding, uneven braids, and two localized cusp highlights.',
    next:'Quiet the lower outer selvedge and reinforce two compact weave crossings near the cusp, leaving the interval untouched.',
    region:[175,230,1080,465],
  },
  build:releaseTheDiagram,
}, {
  name:'Settle the receiving edge',
  note:'The far edge is partially lifted so it no longer outranks the act of reception. Two compact crossings gather pressure beside the cusp; no new marks enter the interval.',
  review:{
    observation:'Inspect whether attention now travels archive → transfer → cusp before reaching the receiver’s outer boundary, and whether the remaining pale edge still holds the membrane open.',
    change:'Softened the lower selvedge, restated it in a darker weight, and added two short unequal crossings around the cusp.',
    next:'If the visual path and material distinction hold in the final whole and detail renders, this checkpoint can be considered as a candidate with its remaining sparseness recorded.',
    region:[900,235,365,440],
  },
  build:settleHierarchy,
}];

export default {
  title: 'What crosses the interval · bundles',
  date: '2026-09-07',
  refs: [2],
  page: { w: W, h: H },
  note: 'A changed construction after the first study became a dim wire diagram. Here memory is pressure and relation: fibres gather, diverge, fray, and arrive at a structure that cannot be the one that sent them.',
  passes,
  build: () => passes.flatMap(pass => pass.build()),
};
