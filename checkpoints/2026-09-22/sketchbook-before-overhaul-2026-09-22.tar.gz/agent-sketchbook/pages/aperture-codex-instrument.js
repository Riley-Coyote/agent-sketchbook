import {seed,PHASE,OCCLUDE,pts,mark,line,oval,plane,hatch,ground,tube,dust} from './aperture-codex-hand.js';
export default{title:'An instrument waiting for a signal',date:'2026-09-07',page:{w:1600,h:1200},note:'I drew an optical bench from invented but consistent parts. Each lens sits on the same oblique rail, while the final holder is deliberately empty. Fine threads and machining marks make readiness tangible. The lens reflections are restrained because bright graphic rings made the first construction look like a diagram.',build(){const o=[PHASE('The bench and its weight')];ground(o,910);plane(o,[[190,876],[1140,714],[1420,861],[461,1042]],75,1);plane(o,[[461,1042],[1420,861],[1418,895],[461,1074]],45,2);
 tube(o,[290,887],[1200,733],17,174);tube(o,[357,931],[1267,777],14,142);
 o.push(PHASE('Machined holders and lenses'));
 for(let i=0;i<3;i++){const cx=444+i*292,cy=525-i*21,rx=110-i*14,ry=170-i*12;
 tube(o,[cx,cy+ry],[cx+40,875-i*50],13,150);plane(o,[[cx-26,850-i*50],[cx+64,834-i*50],[cx+93,851-i*50],[cx+2,873-i*50]],128,i+20);
 const outer=oval(cx,cy,rx+18,ry+18,-.18);o.push(OCCLUDE(outer,1));
 for(let j=0;j<30;j++)o.push(mark(oval(cx,cy,rx+j*.6,ry+j*.6,-.18),70+150*Math.pow(Math.sin(j/30*Math.PI),2),.7,'soft',.8));
 if(i<2){for(let k=0;k<86;k++){let t=k/85;const x=cx-rx+2*rx*t;let dy=ry*Math.sqrt(Math.max(0,1-(2*t-1)**2));o.push(line([x,cy-dy],[x,cy+dy],25+50*Math.exp(-(((t-.3)/.15)**2)),.5,'soft',.75));}
 for(let j=0;j<7;j++)o.push(mark(pts(t=>[cx-rx*.46+j*1.6+20*Math.sin(t*Math.PI),cy-ry*.73+t*ry*1.12],60),140-j*10,.55,'pencil',.8));}
 for(let j=0;j<52;j++){let a=j/52*Math.PI*2;const x=cx+Math.cos(a)*(rx+19),y=cy+Math.sin(a)*(ry+19);o.push(line([x,y],[x+Math.cos(a)*7,y+Math.sin(a)*7],120,.5));}
 // The third holder stays entirely empty.
 }
 o.push(PHASE('Fine adjustments and wear'));
 for(let j=0;j<74;j++){const t=j/74;let x=410+t*760,y=964-t*135;o.push(line([x,y],[x+3,y+8],210,.45));}
 tube(o,[1052,871],[1129,899],7,190);for(let j=0;j<9;j++)o.push(mark(oval(1127,899,14-j,24-j,-.6),160,.6));
 dust(o,[[190,876],[1140,714],[1420,861],[461,1042]],480,18,120);return o;}};
