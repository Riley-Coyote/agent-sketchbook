// Drawing vocabulary for the Aperture folio. All visible tone is made of
// ordered engine strokes; this file never paints a bitmap or fills a path.
import { OP, DOT, PHASE, OCCLUDE, seed, jitter } from '../mark-engine.js';
export { seed, PHASE, OCCLUDE };
export const lerp=(a,b,t)=>a+(b-a)*t;
export const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
export const pts=(fn,n=60)=>Array.from({length:n+1},(_,i)=>fn(i/n));
export const grey=v=>[v,v,v].map(x=>Math.round(clamp(x,0,255)));
export const mark=(p,v=180,w=.6,brush='pencil',alpha=1,layer='line')=>OP('s',jitter(p,.27),layer,brush,w,grey(v),alpha);
export const line=(a,b,v=180,w=.6,brush='pencil',alpha=1)=>mark(pts(t=>a.map((x,i)=>lerp(x,b[i],t)),Math.max(2,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/25))),v,w,brush,alpha);
export const curve=(a,b,c,d)=>pts(t=>a.map((x,i)=>(1-t)**3*x+3*(1-t)**2*t*b[i]+3*(1-t)*t*t*c[i]+t**3*d[i]),70);
export const oval=(x,y,rx,ry,ang=0)=>pts(t=>[x+Math.cos(t*Math.PI*2)*rx*Math.cos(ang)-Math.sin(t*Math.PI*2)*ry*Math.sin(ang),y+Math.cos(t*Math.PI*2)*rx*Math.sin(ang)+Math.sin(t*Math.PI*2)*ry*Math.cos(ang)],160);
export function edge(poly,v=190,w=.65){return mark([...poly,poly[0]],v,w)}
export function hatch(ops,poly,v=90,gap=3,slant=.4,salt=0,brush='pencil'){
 const ymin=Math.min(...poly.map(p=>p[1]-slant*p[0])),ymax=Math.max(...poly.map(p=>p[1]-slant*p[0]));
 for(let y=ymin;y<ymax;y+=gap){const xs=[];
  for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],ya=a[1]-slant*a[0],yb=b[1]-slant*b[0];if((ya<=y&&yb>y)||(yb<=y&&ya>y))xs.push(a[0]+(b[0]-a[0])*(y-ya)/(yb-ya));}
  xs.sort((a,b)=>a-b);for(let k=0;k+1<xs.length;k+=2){const drift=(seed(y,salt)-.5)*.8;ops.push(line([xs[k],y+slant*xs[k]],[xs[k+1],y+slant*xs[k+1]+drift],v*(.7+.3*seed(y,salt+8)),brush==='soft'?.8:.62,brush,.85));}
 }
}
export function plane(ops,poly,v=95,salt=0){ops.push(OCCLUDE(poly,1));hatch(ops,poly,v,2.5,-.27,salt,'soft');hatch(ops,poly,v*.72,5.2,.8,salt);ops.push(edge(poly,v+35,.8));}
export function dust(ops,poly,n=350,salt=1,v=140){const xs=poly.map(p=>p[0]),ys=poly.map(p=>p[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
 for(let i=0;i<n;i++){const x=lerp(minX,maxX,seed(i,salt)),y=lerp(minY,maxY,seed(i,salt+1));let inside=false;for(let a=0,b=poly.length-1;a<poly.length;b=a++){if(((poly[a][1]>y)!==(poly[b][1]>y))&&x<(poly[b][0]-poly[a][0])*(y-poly[a][1])/(poly[b][1]-poly[a][1])+poly[a][0])inside=!inside;}
 if(inside)ops.push(line([x,y],[x+2+seed(i,salt+2)*6,y-1],v,.35,'chalk',.55));}
}
export function ground(ops,y=950){for(let i=0;i<140;i++){const xx=200+seed(i,41)*1200,yy=y+seed(i,42)*120;ops.push(line([xx,yy],[xx+12+seed(i,43)*90,yy-3],38+seed(i,44)*26,.45,'charcoal',.6));}}
export function tube(ops,A,B,r=8,v=180){const dx=B[0]-A[0],dy=B[1]-A[1],l=Math.hypot(dx,dy),N=[-dy/l,dx/l];const poly=[A.map((x,i)=>x-N[i]*r),B.map((x,i)=>x-N[i]*r),B.map((x,i)=>x+N[i]*r),A.map((x,i)=>x+N[i]*r)];ops.push(OCCLUDE(poly,1));for(let k=-r;k<=r;k+=.9){const value=25+v*Math.exp(-(((k+r*.45)/(r*.63))**2));ops.push(line(A.map((x,i)=>x+N[i]*k),B.map((x,i)=>x+N[i]*k),value,.65,'soft'));}ops.push(line(poly[0],poly[1],v,.7));}
export function inside(p,poly){let result=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){if(((poly[i][1]>p[1])!==(poly[j][1]>p[1]))&&p[0]<(poly[j][0]-poly[i][0])*(p[1]-poly[i][1])/(poly[j][1]-poly[i][1])+poly[i][0])result=!result;}return result;}
export function clipped(ops,path,poly,v=130,w=.55,brush='pencil',alpha=.8){let run=[];const flush=()=>{if(run.length>1)ops.push(mark(run,v,w,brush,alpha));run=[];};for(const p of path){if(inside(p,poly))run.push(p);else flush();}flush();}
