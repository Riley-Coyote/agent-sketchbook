/* Native overlap study: prove a continuous plane before revising the threshold. */
import { OP, PHASE, PAUSE, CLAMP, jitter, seed } from '../mark-engine.js';
const S=(p,l='tone',b='soft',w=1,c=[70,91,106],a=1)=>OP('s',jitter(p,.09),l,b,w,c,a);
const L=(x,y,X,Y,...r)=>S([[x,y],[(x+X)/2,(y+Y)/2],[X,Y]],...r);
function study(){const o=[PHASE('overlapping soft field, dark return, shared base shadow')];
 // Close spacing + broad soft footprint: these strokes must merge before their
 // individual paths become the image. Their directions drift locally.
 for(let i=0;i<50;i++){
  const x=62+i*6.2,tilt=(seed(i,1)-.5)*20,bulge=(seed(i,2)-.5)*18;
  o.push(S([[x,75],[x+bulge,240],[x+tilt,420]],'tone','soft',3.55,[53+Math.round(seed(i,3)*13),74+Math.round(seed(i,4)*13),89+Math.round(seed(i,5)*15)],.19,.12));
 }
 // A few lateral soft breaths break the one-direction field without becoming bands.
 for(let i=0;i<9;i++){
  const y=105+i*36+(seed(i,6)-.5)*12;
  o.push(L(78,y,336,y-13+(seed(i,7)-.5)*18,'tone','glaze',2.2,[44,62,77],.16));
 }
 // Return is narrower and materially darker; it is laid down after the face.
 for(let i=0;i<13;i++){
  const x=374+i*5.2,tilt=(seed(i,8)-.5)*7;
  o.push(S([[x,95],[x+tilt,242],[x+tilt*1.3,404]],'tone','soft',3.1,[16,25,35],.34,.10));
 }
 // Only one broken lit edge; continuous highlights would re-outline the object.
 o.push(L(60,75,222,82,'accent','pencil',.82,[165,190,198],.58));
 o.push(L(270,89,365,95,'accent','pencil',.48,[126,154,164],.24));
 // A single dark base shadow binds return to floor, followed by a quiet receding floor.
 o.push(S([[332,415],[398,421],[463,431]],'tone','soft',4.4,[12,18,26],.56,.12));
 for(let i=0;i<8;i++)o.push(L(55,438+i*10,456,410+i*8,'tone','glaze',1.7,[31,45,58],.14));
 o.push(CLAMP('tone',.4),PAUSE(650));return o;}
const passes=[{name:'Continuous face overlap calibration',note:'Testing a face made of close, overlapping soft strokes with locally varied direction. The goal is a plane before a pattern.',review:{observation:'At fit and crop scales, the face should read as one subdued value; the return should turn darker; the floor should meet the return through one shared shadow.',change:'Use 6.2px path spacing with wide soft stamps, cross the field only sparingly, and reserve accent for one broken edge.',next:'Only apply this vocabulary if the adjacent paths merge rather than remain bright ribs.',region:[45,60,430,420]},build:study}];
export default {title:'Continuous plane overlap swatch',date:'2026-09-07',page:{w:520,h:540},note:'A small native calibration for the Listening Threshold. It tests overlap and local directional variation, not a finished architecture.',passes,build:()=>passes.flatMap(p=>p.build())};
