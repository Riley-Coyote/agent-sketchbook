/* Second native calibration: cross-directional glaze field for a continuous plane. */
import { OP, PHASE, PAUSE, CLAMP, jitter, seed } from '../mark-engine.js';
const S=(p,l='tone',b='glaze',w=1,c=[45,63,77],a=1)=>OP('s',jitter(p,.11),l,b,w,c,a);
function field(){const o=[PHASE('wide cross-directional glaze overlap')];
 // Broad low-alpha paths overlap by more than their visible feather. Two loose
 // directions make value, while the uneven endpoints prevent a stripe field.
 for(let i=0;i<18;i++){
  const y=78+i*20+(seed(i,1)-.5)*12;
  o.push(S([[58,y],[232,y-12+(seed(i,2)-.5)*22],[430,y-24+(seed(i,3)-.5)*30]],'tone','glaze',4.3,[47,66,81],.54,.14));
 }
 for(let i=0;i<13;i++){
  const x=78+i*29+(seed(i,4)-.5)*10;
  o.push(S([[x,95],[x+68+(seed(i,5)-.5)*24,244],[x+118+(seed(i,6)-.5)*34,420]],'tone','glaze',3.4,[35,51,66],.34,.14));
 }
 // A darker turn is made with only a few overlapping broad strokes.
 for(let i=0;i<7;i++){
  const x=434+i*11;
  o.push(S([[x,96],[x+8,244],[x+4,413]],'tone','glaze',3.1,[13,21,30],.58,.10));
 }
 o.push(S([[60,78],[196,87]],'accent','pencil',.72,[158,184,193],.5,.08));
 o.push(S([[422,417],[474,426],[512,431]],'tone','soft',4.5,[11,17,25],.6,.12));
 for(let i=0;i<6;i++)o.push(S([[52,438+i*11],[300,420+i*6],[508,429+i*5]],'tone','glaze',2.3,[27,40,51],.25,.12));
 o.push(CLAMP('tone',.4),PAUSE(650));return o;}
const passes=[{name:'Cross-directional glaze field',note:'Testing broad, low-alpha glaze overlap for a continuous plane. The paths cross gently and end irregularly so they build value without becoming ribs.',review:{observation:'The face should read as one field at both fit and crop scale, with only the narrow return turning darker.',change:'Use close broad horizontal-leaning glazes plus a smaller counter-direction, then a compact dark return and one base shadow.',next:'Adopt only if the field stays continuous without a visible stripe direction.',region:[45,65,480,400]},build:field}];
export default {title:'Cross-directional glaze field',date:'2026-09-07',page:{w:560,h:540},note:'A native calibration for continuous value in the Listening Threshold face, after vertical soft overlap still read as a curtain.',passes,build:()=>passes.flatMap(p=>p.build())};
