/* Native material-study page: a tactile basin made only from timed contacts. */
const W=1600,H=1600;
const mix=(a,b,t)=>a+(b-a)*t;
const path=(fn,n=34)=>Array.from({length:n},(_,i)=>fn(i/(n-1),i));
const seed=n=>{const x=Math.sin(n*42.713)*23568.33;return x-Math.floor(x);};
const stroke=(o,tool,size,pts,p=.5,tilt=0,strength=1)=>o.push({k:'m',tool,size,strength,samples:pts.map(([x,y],i)=>({x,y,p:typeof p==='function'?p(i/(pts.length-1)):p,tiltX:0,tiltY:tilt,t:i*24}))});
export default {
  title:'A Manual for Touching the Surface of a Star', date:'2026-09-07',
  note:'I began with a near-perfect bowl and had to spoil it: its first rings looked like a target. I pushed the basin off centre, broke the ridge spacing, and used four small pale inserts as interruptions rather than landmarks. The bright rim is convincing at distance; the lower-left ridge still becomes too orderly when inspected closely.',
  page:{w:W,h:H}, surface:{version:1,paper:'black',tooth:.74,seed:78109},
  build:()=>{const o=[];
    const cx=790,cy=870,rx=655,ry=498;
    // Broad hand-rubbed field, strongest away from the untouched interior.
    for(let i=0;i<164;i++){
      const a=i/163*Math.PI*2, out=1.0, inn=.63+seed(i)*.06;
      const x0=cx+Math.cos(a)*rx*out,y0=cy+Math.sin(a)*ry*out;
      const x1=cx+Math.cos(a)*rx*inn,y1=cy+Math.sin(a)*ry*inn;
      stroke(o,'vine-charcoal',9,path(t=>[mix(x0,x1,t)+Math.sin(t*5+i)*3,mix(y0,y1,t)+Math.cos(t*4+i)*2],28),.32,60,.8);
    }
    // Ridges follow an oblique, imperfect ellipse; their spacing narrows at the lighted lip.
    for(let r=0;r<93;r++){
      const q=r/92, a0=.10+seed(r)*.07, a1=6.12-seed(r+6)*.10;
      const rad=.45+q*.54, ySquash=.74+.14*Math.sin(q*4);
      const pts=path(t=>{const a=mix(a0,a1,t);const broken=1+Math.sin(a*3+r*.44)*.026+Math.sin(a*7-r)*.014;return [cx+Math.cos(a)*rx*rad*broken,cy+Math.sin(a)*ry*rad*ySquash*broken];},58);
      const light=Math.max(0,Math.cos((mix(a0,a1,.54)-.20))* .5+.5);
      stroke(o,'white-chalk',1.15+q*1.25,pts,.13+light*.22,42,.58);
      if(r%3===0) stroke(o,'graphite-hb',1.1,pts.map(([x,y],i)=>[x+Math.sin(i+r)*2,y+1.5]),.34,10,.72);
    }
    // The dark basin is made by withholding chalk and then using compressed-charcoal at its throat.
    for(let j=0;j<118;j++){
      const y=660+j*4.6, dy=(y-cy)/260, half=410*Math.sqrt(Math.max(.02,1-dy*dy));
      stroke(o,'compressed-charcoal',6,path(t=>[cx-half+t*half*2,y+Math.sin(t*9+j)*3],38),.56,73,.95);
    }
    // One rim catches: interrupted chalk is brighter than the rest, never a glow.
    for(let j=0;j<28;j++){
      const rr=.91+j*.004;
      const pts=path(t=>{const a=.18+t*2.22;return [cx+Math.cos(a)*rx*rr,cy+Math.sin(a)*ry*.78*rr];},38);
      stroke(o,'white-chalk',1.55,pts,.58,38,.87);
    }
    // Four embedded vellum-like interruptions: soft chalk bodies with graphite cuts, never readable language.
    const tabs=[[385,472,43,.2],[1118,515,39,-.38],[1258,1040,46,.18],[487,1200,35,-.22]];
    for(let q=0;q<tabs.length;q++){
      const [x,y,s,ang]=tabs[q];
      for(let k=0;k<26;k++){
        const yy=(-.5+k/25)*s*.92, half=s*(.52-Math.abs(yy/s)*.26);
        stroke(o,'white-chalk',2.9,path(t=>{const xx=(-half+t*half*2);return [x+xx*Math.cos(ang)-yy*Math.sin(ang),y+xx*Math.sin(ang)+yy*Math.cos(ang)];},17),.35,35,.6);
      }
      for(let z=0;z<11;z++){
        const xx=(-.28+seed(z+q*20)*.56)*s,yy=(-.28+seed(z+q*30)*.56)*s;
        stroke(o,'graphite-6b',1.05,[[x+xx,y+yy],[x+xx+8+seed(z)*11,y+yy-5+seed(z+3)*9]],.58,0,.9);
      }
    }
    // Fine abrasion lines tie the corners to the depression without a radial diagram.
    for(let i=0;i<178;i++){
      const a=seed(i+301)*6.28, r0=720+seed(i)*160,r1=410+seed(i+32)*130;
      const x0=cx+Math.cos(a)*r0,y0=cy+Math.sin(a)*r0*.74,x1=cx+Math.cos(a+.09)*r1,y1=cy+Math.sin(a+.09)*r1*.74;
      stroke(o,'graphite-hb',.72,path(t=>[mix(x0,x1,t)+Math.sin(t*8+i)*2,mix(y0,y1,t)],24),.22,67,.55);
    }
    return o;
  }
};
