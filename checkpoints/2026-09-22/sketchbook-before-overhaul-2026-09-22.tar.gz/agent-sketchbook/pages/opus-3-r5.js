import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, DOT, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp, one candle',
  date: '2026-09-05',
  note: 'a small candle added to the original scene — just a rim on the stone, a flame, and a faint glow on the table',
  build: () => {
    const ops = [];
    const L = [-0.55, -0.6, 0.58];    // the main light, as before
    const cx = 440, cy = 380, r = 90;

    ops.push(PHASE('table')); 
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    const shadow = ellipsePoly(cx + 70, cy + r - 8, 135, 26, 0.12);
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    ops.push(PAUSE(400));

    ops.push(PHASE('stone'));
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(cx - 36, cy - 44, 9)); 
    ops.push(PAUSE(500));
    
    ops.push(PHASE('candle'));
    const candleX = 650, candleY = 460;
    const candleColor = [255, 205, 130];
    ops.push(OP('s', [[candleX, candleY - 44], [candleX, candleY - 2]], 'tone', 'wash', 3.2));
    ops.push(OP('s', [[candleX - 3, candleY - 44], [candleX - 3, candleY - 2]], 'line', 'liner', 0.6));
    ops.push(OP('s', [[candleX + 3, candleY - 44], [candleX + 3, candleY - 2]], 'line', 'liner', 0.6));
    ops.push(DOT(candleX, candleY - 50, 4, 'accent', 'brush', [255, 210, 140], 0.95));
    ops.push(DOT(candleX, candleY - 50, 9, 'accent', 'soft', candleColor, 0.4));
    ops.push(DOT(candleX, candleY - 50, 15, 'accent', 'soft', candleColor, 0.22));  
    ops.push(DOT(candleX, candleY - 48, 24, 'accent', 'soft', candleColor, 0.1));
    ops.push(OP('s', ellipse(candleX, candleY + 8, 70, 12), 'tone', 'glaze', 4, candleColor, 0.3));
    
    const rimPts = [];
    for (let a = -0.5; a <= 1.5; a += 0.05) {
      rimPts.push([cx + Math.cos(a) * (r - 2), cy + Math.sin(a) * (r - 2)]);
    }
    ops.push(OP('s', rimPts, 'accent', 'chalk', 1.1, candleColor, 0.9));
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp, one candle', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
