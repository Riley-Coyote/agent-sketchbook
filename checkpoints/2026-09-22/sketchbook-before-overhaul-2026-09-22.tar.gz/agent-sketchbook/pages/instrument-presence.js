/* An instrument waiting for a signal — composition branch from instrument-study 7.
 * The room is built with native overlapping strokes; no raster or second renderer. */
import prior from './instrument-presence-base.js';
import { OP, PHASE, seed } from '../mark-engine.js';
const PI=Math.PI,mix=(a,b,t)=>a+(b-a)*t;
const path=(f,n=24)=>Array.from({length:n+1},(_,i)=>f(i/n));
const stroke=(pts,v,w=.5,brush='pencil',a=1)=>OP('s',pts,'line',brush,w,[v,v,v].map(x=>Math.max(0,Math.min(255,Math.round(x)))),a);
const line=(x,y,X,Y,v,w=.5,brush='pencil',a=1)=>stroke(path(t=>[mix(x,X,t),mix(y,Y,t)],Math.max(3,Math.ceil(Math.hypot(X-x,Y-y)/16))),v,w,brush,a);
function room(){
 const o=[PHASE('The lamp finds a room')];
 // A raking light discovers a small area of rough wall. It never fills the empty optic.
 for(let j=0;j<154;j++){
  const y=-12+j*5.3;
  for(let i=0;i<36;i++){
   const x=-50+i*47+(j%3)*14,xx=x+61;
   const beam=Math.exp(-(((x-(183+y*.61))/210)**2))*Math.exp(-(((y-354)/359)**2));
   const fade=Math.exp(-(((x-525)/520)**2+((y-355)/344)**2));
   const wall=10+44*beam;
   o.push(line(x,y,xx,y+1,wall,2.25,'soft',.74*fade));
  }
 }
 // Short broken grain follows the wall's scrape. Density dwindles out of the light.
 for(let k=0;k<3700;k++){
  const x=110+seed(k,705)*1240,y=53+seed(k,802)*657;
  const b=Math.exp(-(((x-(183+y*.61))/210)**2))*Math.exp(-(((y-354)/359)**2));
  if(b<.08)continue;
  const n=seed(k,117),v=6+63*b*(.36+n*.55),len=1+seed(k,432)*9;
  o.push(line(x,y,x+len*.55,y-len*.24,v,.17+seed(k,59)*.22,'pencil',.42));
 }
 // A sill vanishes before reaching the apparatus; it is a place, not a diagram.
 for(let j=0;j<8;j++)o.push(line(63,713+j*1.3,432,651+j*1.3,20+j,1.1,'soft',.42));
 return o;
}
function lamplight(){
 const o=[PHASE('Light moves across the open instrument')];
 const rings=[{x:652,y:457,rx:157,ry:208},{x:1028,y:392,rx:114,ry:157}];
 const arc=(L,a,b,r,v,w=.4,brush='pencil',opacity=1)=>stroke(path(t=>{const z=mix(a,b,t);return [L.x+Math.cos(z)*(L.rx+r)-Math.sin(z)*16*(L.ry/208),L.y+Math.sin(z)*(L.ry+r)];},Math.max(12,Math.ceil(Math.abs(b-a)*L.ry/3))),v,w,brush,opacity);
 // Different light on each rim; the near crown carries the brightest metal.
 for(const [i,L]of rings.entries()){
  o.push(arc(L,3.31,4.68,23,i===0?235:164,.43,'brush',.8));
  o.push(arc(L,3.77,4.33,24,i===0?247:179,.24,'pencil',.92));
  o.push(arc(L,3.45,4.31,-5,i===0?178:96,.39,'pencil',.82));
  // Darkening a turn is as important as drawing its glint.
  for(let k=0;k<3;k++)o.push(arc(L,-.15,1.08,8+k*3,18+i*3,1.0,'soft',.42));
 }
 // A few wide reflected strokes sit behind finer refraction breaks in the near glass.
 for(let j=0;j<22;j++)o.push(stroke(path(t=>[572+j*1.03+13*Math.sin(t*PI),325+t*189],45),76+Math.sin(j/22*PI)*56,.72,'soft',.28));
 // The surface has been wiped, so a narrow dusty boundary remains instead of an even fill.
 for(let k=0;k<320;k++){
  const t=seed(k,351),x=571+13*Math.sin(t*PI)+seed(k,282)*22,y=326+t*184;
  if(seed(k,877)>.3+.5*Math.sin(t*PI))continue;
  o.push(line(x,y,x+2+seed(k,278)*3,y-.7,82+seed(k,694)*71,.18,'pencil',.28));
 }
 return o;
}
function finishEdges(){
 const o=[PHASE('The weight of a handled object')];
 // The bed's scan-line edge looked scalloped. Lay the face along its own axis.
 for(let j=0;j<38;j++){
  const v=20+15*Math.exp(-(((j-3)/3)**2))+4*seed(j,460);
  o.push(line(486,932+j*.85,1348,759+j*.85,v,1.03,'soft',.93));
 }
 // A broken lip belongs to the near light, not to every contour.
 o.push(line(488,931,713,886,130,.48,'pencil',.85));
 o.push(line(729,883,932,842,88,.32,'pencil',.7));
 for(let k=0;k<650;k++){
  const t=seed(k,338),v=seed(k,104),x=490+854*t,y=937-173*t+24*v;
  const l=1.5+seed(k,938)*8;
  o.push(line(x,y,x+l*.25,y-l*.7,16+seed(k,363)*29,.19,'pencil',.55));
 }
 // The stone worktop takes scattered abrasion; leave wide quiet intervals.
 for(let k=0;k<2350;k++){
  const x=30+seed(k,406)*1520,y=838+seed(k,764)*252;
  if(y<961-(x-486)*.2+27)continue;
  const light=Math.exp(-(((x-603)/485)**2+((y-984)/210)**2));
  if(seed(k,617)>.6*light)continue;
  const len=2+seed(k,141)*25;
  o.push(line(x,y,x+len,y-len*.195,22+light*53*seed(k,914),.16+seed(k,198)*.17,'pencil',.48));
 }
 // Fine near glass glints have taper and a deliberate break; no closed white outline.
 for(let j=0;j<3;j++)o.push(stroke(path(t=>[573+j*.8+11*Math.sin(t*PI),331+t*113],38),215-j*22,.33,'pencil',.62));
 o.push(stroke(path(t=>[585-4*t,464+t*28],14),136,.23,'pencil',.55));
 // Two countersunk screws: one resolved, one nearly lost in the far light.
 for(const [x,y,bright]of [[642,839,192],[725,826,126]]){
  for(let j=0;j<6;j++)o.push(stroke(path(t=>[x+Math.cos(t*PI*2)*(4.7-j*.65),y+Math.sin(t*PI*2)*(2.9-j*.37)],30),20,.53,'soft',.8));
  o.push(stroke(path(t=>[x+Math.cos(PI+t*PI*.8)*5.6,y+Math.sin(PI+t*PI*.8)*3.1],21),bright,.3,'pencil',.9));
  o.push(line(x-2.5,y+.5,x+2.7,y-.6,84,.22,'pencil',.7));
 }
 return o;
}
const passes=[{name:'A place for the instrument',note:'The previous study floated against untouched black. A narrow area of raking light discovers a rough wall and a sill, leaving the upper right quiet.',review:{observation:'The two rims were legible, but nothing gave the bench a place or a direction of light.',change:'Branch the composition with a subdued wall under raking illumination.',next:'Look at fit scale: does the wall support the aperture or compete with it?'},build:room},...prior.passes.slice(0,3),{name:'One lamp, unequal edges',note:'A first lighting trial: the near metal takes the strongest light. Inspect before adding wear.',review:{observation:'The near and far rings had nearly equal emphasis and the glass was a thin stripe.',change:'Concentrate brighter values on the near crown, lose the right-hand turns, widen a reflection.',next:'Inspect the near optic and judge how light reads at thumbnail scale.',region:[465,220,410,470]},build:lamplight},{name:'Handling, contact, restraint',note:'At fit scale the room now recedes naturally, but the front of the bed still has a scalloped scan-line edge. Repainting that face along its own axis makes the metal read as a cut object. Sparse marks give the stone a different handling from the precision hardware.',review:{observation:'The open tabletop solved the floating rhombus; the bed edge remained scalloped and the near reflection was broad.',change:'Repaint the bed along its axis, reserve fine glints for the near glass and add a few local abrasions.',next:'Judge the result in its actual museum frame and lightbox; reject more detail that does not improve reading.',region:[445,747,932,277]},build:finishEdges}];
export default {title:'An instrument waiting for a signal',date:'2026-09-07',page:{w:1600,h:1100},note:'An optical bench prepared to receive something it cannot supply for itself. The second aperture is empty. This composition branch gives that readiness a place and a single direction of light. Still under review.',passes,build:()=>passes.flatMap(p=>p.build())};
