import { OP, PHASE, PAUSE, CLAMP, OCCLUDE, jitter, seed } from '../mark-engine.js';
import { pts, tube, grey } from './aperture-codex-hand.js';
import { hatchPoly, passesFor } from './lib.js';
const W=1200,H=1600;
const hand=(ops,cx,cy,ang,s,key)=>{
 const ca=Math.cos(ang),sa=Math.sin(ang),pv=[-sa,ca], palm=[];
 for(let i=0;i<36;i++){const q=i/36*Math.PI*2,rx=58*s,ry=38*s;palm.push([cx+Math.cos(q)*rx*ca-Math.sin(q)*ry*sa,cy+Math.cos(q)*rx*sa+Math.sin(q)*ry*ca]);}
 ops.push(OCCLUDE(palm,1)); hatchPoly(palm,ang+.8,5,.1,passesFor(.42,{gain:.62}),null,20+s*10);
 for(let i=0;i<5;i++){const bx=cx+ca*(34*s+i*5)+pv[0]*(i-2)*10*s,by=cy+sa*(34*s+i*5)+pv[1]*(i-2)*10*s,bend=(i-2)*.035,tx=bx+Math.cos(ang+bend)*s*(86-i*8),ty=by+Math.sin(ang+bend)*s*(86-i*8);tube(ops,[bx,by],[tx,ty],7*s,105);ops.push(OP('s',jitter(pts(t=>[bx+(tx-bx)*t+pv[0]*Math.sin(t*Math.PI)*5*s,by+(ty-by)*t+pv[1]*Math.sin(t*Math.PI)*5*s],24),.08),'line','pencil',.7,grey(184),.7));}
 for(let i=0;i<6;i++) ops.push(OP('s',jitter(pts(t=>[cx+ca*(t*64-15)+pv[0]*(i*4-10)+Math.sin(t*4+i)*2,cy+sa*(t*64-15)+pv[1]*(i*4-10)+Math.sin(t*4+i)*2],22),.08),'line','pencil',.58,grey(176),.6));
};
export default {title:'the orchard of borrowed hands',date:'2026-09-07',note:'I removed the boxed palms and smooth schematic forks. The new page keeps a faint displaced underdrawing behind continuous charcoal trunks, then builds each hand as an oval palm with five uneven tapered fingers and small tendon lines. The lower gestures remain quieter by choice.',page:{w:W,h:H},build:()=>{
 const ops=[PHASE('01 · faint displaced orchard')];
 for(let i=0;i<15;i++){const a=1.15+(seed(i,2)-.5)*1.5,A=[600,1510],B=[600+Math.cos(a)*(420+seed(i,3)*350),1500-Math.sin(a)*(560+seed(i,4)*560)];ops.push(OP('s',jitter(pts(t=>[A[0]+(B[0]-A[0])*t+Math.sin(t*5+i)*8,A[1]+(B[1]-A[1])*t],110),.14),'under','soft',.8,grey(120),.22));}
 ops.push(PHASE('02 · continuous trunk and forks')); tube(ops,[602,1540],[590,980],92,108);tube(ops,[590,1010],[320,520],58,104);tube(ops,[592,1000],[870,425],62,104);tube(ops,[590,1110],[255,920],46,98);tube(ops,[600,1100],[1020,980],48,98);tube(ops,[570,870],[510,300],38,98);tube(ops,[650,800],[790,210],38,98);
 hand(ops,320,520,-1.95,.8);hand(ops,870,425,-.72,.7);hand(ops,255,920,-2.58,.6);hand(ops,1020,980,.22,.56);hand(ops,510,300,-1.48,.54);
 ops.push(PHASE('03 · bark and transferred contour')); for(let i=0;i<360;i++){const x=425+seed(i,91)*350,y=620+seed(i,92)*850,l=20+seed(i,93)*95;ops.push(OP('s',jitter(pts(t=>[x+Math.sin(t*5+i)*4,y-l*t],Math.ceil(l/4)),.1),'line','pencil',.58+seed(i,94)*.55,grey(155),.46));}
 for(const [x,y] of [[870,425],[1020,980],[255,920],[510,300]]) for(let k=0;k<4;k++) ops.push(OP('s',jitter(pts(t=>[x-5+t*10,y-2+Math.sin(t*4+k)*2],5),.05),'accent','chalk',.3,[165,68,40],.34));
 ops.push(PAUSE(800),CLAMP('tone',.4)); return ops; }};
