import {seed,PHASE,pts,mark,line,plane,hatch,tube,ground} from './aperture-codex-hand.js';
export default{title:'two witnesses, one chair',date:'2026-09-07',page:{w:1200,h:1600},note:'Sol’s concept is an ordinary chair held by two incompatible views. I anchored both accounts at the same front rail, then drew the second back and leg lightly, as a remembered pressure rather than a second object. The chair remains usable. The offset back is visibly unresolved instead of being erased into false agreement.',build(){const o=[PHASE('Two shadows, one place to sit')];ground(o,1300);
 hatch(o,[[445,1224],[629,1260],[1030,1419],[977,1468]],70,3,.28,1,'charcoal');hatch(o,[[466,1220],[641,1230],[254,1435],[126,1416]],47,3,-.3,2,'charcoal');
 const back=[[366,334],[737,292],[742,414],[372,460]];const seat=[[386,856],[738,782],[902,918],[521,1020]];
 tube(o,[377,382],[397,1131],14,154);tube(o,[743,331],[748,1084],13,117);plane(o,back,116,7);
 for(let i=0;i<6;i++)tube(o,[403+i*57,455-i*7],[427+i*57,833-i*9],8,120);
 plane(o,seat,155,8);plane(o,[[521,1020],[902,918],[898,955],[522,1055]],115,9);
 tube(o,[530,1037],[469,1291],17,155);tube(o,[887,945],[910,1185],15,115);tube(o,[397,885],[343,1194],12,74);
 tube(o,[471,1193],[910,1098],10,134);tube(o,[359,1110],[472,1192],8,90);
 o.push(PHASE('Another witness shares only the worn rail'));
 for(const [a,b] of [[[310,364],[372,903]],[[697,251],[738,782]],[[310,364],[697,251]],[[327,435],[704,327]],[[902,955],[861,1227]],[[386,856],[339,1229]]])o.push(line(a,b,102,.45,'pencil',.45));
 for(let j=0;j<55;j++){const x=544+j*5.8,y=1041-(x-544)*.258;o.push(line([x,y],[x+4+seed(j,17)*14,y-4],184,.45,'chalk',.9));}
 for(let j=0;j<36;j++)o.push(line([391+j*8.6,361-j*1.15],[386+j*8.6,419-j*1.15],170,.42,'pencil',.55));return o;}};
