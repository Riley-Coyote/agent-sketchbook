/* Native material-study page: every field is a sequence of dry-media gestures. */
const W = 1200, H = 1600;
const mix = (a,b,t) => a + (b-a)*t;
const path = (fn, n=32) => Array.from({length:n}, (_,i) => fn(i/(n-1), i));
const ellipse = (cx,cy,rx,ry,a=0,b=Math.PI*2,n=42) => path(t => [cx+Math.cos(mix(a,b,t))*rx, cy+Math.sin(mix(a,b,t))*ry],n);
const stroke = (ops, tool, size, pts, pressure=.45, tilt=0, strength=1) => ops.push({k:'m',tool,size,strength:Math.min(1,strength*(tool==='white-chalk'||tool.includes('eraser')?1:1.95)),samples:pts.map(([x,y],i)=>({x,y,p:typeof pressure==='function'?pressure(i/(pts.length-1)):pressure,tiltX:0,tiltY:tilt,t:i*22}))});
const seed = n => { const x=Math.sin(n*91.813)*43758.5453; return x-Math.floor(x); };

export default {
  title: 'The Witness That Cannot Wake',
  date: '2026-09-07',
  note: 'I wanted the face to be an actively worked absence rather than a blank mask. The first danger was that the tray became a row of symbols, so I kept its weather marks small and let the tilted body carry the page. The attendant silhouette is still a little too legible in the shoulder; it works better where it dissolves into the paper.',
  page: {w:W,h:H},
  surface: {version:1,paper:'toned',tooth:.68,seed:197403},
  build: () => {
    const o=[];
    // A quiet paper atmosphere, irregular enough to be felt only at close range.
    for(let i=0;i<155;i++){
      const y=70+i*8.8, x=70+seed(i)*45, len=1010+seed(i+11)*85;
      stroke(o,'graphite-hb',1.15,path(t=>[x+t*len,y+Math.sin(t*10+i)*1.2],35),.075,72,.38);
    }
    // Table plane, built before the figure. The shallow diagonals establish a seated angle.
    for(let i=0;i<112;i++){
      const y=1120+i*4.2;
      stroke(o,'graphite-2b',2.4,path(t=>[65+t*1070,y-t*85+Math.sin(t*6+i)*1.7],30),.13+(i/112)*.12,63,.62);
    }
    for(let i=0;i<36;i++) stroke(o,'vine-charcoal',5.5,path(t=>[120+t*920,1305+i*2.8-t*72],26),.11,55,.55);
    // Faint transferred observer, drawn early so the seated form can cover it.
    const ghost = [[700,355],[815,315],[907,384],[953,520],[930,795],[851,1018],[731,1045],[653,914],[647,657],[670,457],[700,355]];
    for(let j=0;j<29;j++) stroke(o,'graphite-hb',1.7,ghost.map(([x,y],i)=>[x+Math.sin(i*1.7+j)*2.2,y+Math.cos(i*.9+j)*2.7]),.13,12,.43);
    for(let j=0;j<48;j++){
      const x=674+seed(j+200)*250,y=400+seed(j+250)*610;
      stroke(o,'graphite-hb',1.1,[[x,y],[x+18+seed(j)*22,y+6+seed(j+1)*15]],.1,0,.35);
    }
    // Main seated torso: left shoulder forward, right shoulder quietly receding.
    const torso = [[190,775],[274,675],[415,639],[561,694],[628,855],[653,1082],[587,1212],[405,1254],[217,1161],[149,1002],[190,775]];
    for(let r=0;r<135;r++){
      const t=r/134, y=702+t*510, left=196+t*18+Math.sin(t*5)*24, right=571+t*46-Math.sin(t*4)*16;
      stroke(o,'graphite-6b',2.5,path(u=>[mix(left,right,u),y+Math.sin(u*5+r*.24)*4],38),.12+.21*Math.pow(t,1.5),62,.72);
    }
    // A turned, tilted head and the repeatedly lifted-away face.
    const head=ellipse(428,512,180,234,0,Math.PI*2,60);
    for(let r=0;r<96;r++){
      const yy=300+r*4.35, nx=(yy-510)/234, half=180*Math.sqrt(Math.max(.02,1-nx*nx));
      stroke(o,'graphite-6b',2.1,path(u=>[428-half+u*half*2,yy+Math.sin(u*7+r)*1.8],34),.11+.29*Math.max(0,1-uAbs(0)),70,.55);
    }
    // Hair is dense but never a cap: independent curls gather only at the upper left.
    for(let i=0;i<94;i++){
      const a=2.7+seed(i)*2.7, rr=142+seed(i+9)*80, cx=430+Math.cos(a)*rr,cy=480+Math.sin(a)*rr;
      stroke(o,'compressed-charcoal',2.6,path(t=>[cx+t*(22+seed(i+21)*32),cy+Math.sin(t*7+i)*10-t*20],17),.3,35,.82);
    }
    // The erased oval: accumulated graphite is lifted in unequal, patient passes.
    for(let i=0;i<77;i++){
      const y=386+i*3.2, n=(y-507)/124, half=105*Math.sqrt(Math.max(.03,1-n*n));
      stroke(o,'kneaded-eraser',11,path(t=>[430-half+t*half*2,y+Math.sin(t*8+i)*2],23),.62,0,1);
    }
    for(let i=0;i<23;i++) stroke(o,'precision-eraser',1.25,ellipse(431,502,103-i*.9,126-i*.7,.15,2.25,29),.7,0,.8);
    // Neck and the two arms are deliberately foreshortened, with intervening garment creases.
    for(let i=0;i<46;i++) stroke(o,'graphite-2b',2,path(t=>[342+t*92,690+t*135+Math.sin(t*5+i)*5],22),.22,28,.7);
    for(let i=0;i<38;i++) stroke(o,'graphite-6b',2.4,path(t=>[220+t*212,923+t*110+Math.sin(t*8+i)*7],25),.24,58,.65);
    for(let i=0;i<41;i++) stroke(o,'graphite-6b',2.3,path(t=>[499+t*217,885+t*123+Math.sin(t*6+i)*5],25),.2,58,.6);
    // Tray: three nested edges and a deep shallow interior, not a diagrammatic rectangle.
    const tray=[[186,1112],[889,1059],[1022,1214],[298,1293],[186,1112]];
    for(let j=0;j<17;j++) stroke(o,'compressed-charcoal',3.1,tray.map(([x,y],i)=>[x+(i===0?j:-j*.2),y+j*.8]),.43,60,.9);
    for(let r=0;r<49;r++) stroke(o,'vine-charcoal',4,path(t=>[250+t*670,1140+r*2.5-t*55],27),.19+r*.003,58,.75);
    // Four minute phenomena reside within the tray: rain, moth wing, tide, dusted glass.
    for(let i=0;i<25;i++){const x=328+seed(i)*115,y=1150+seed(i+41)*78; stroke(o,'white-chalk',1.15,[[x,y],[x,y+9+seed(i+7)*16]],.42,0,.7);}
    for(let k=0;k<22;k++) stroke(o,'graphite-hb',1.1,ellipse(515,1182,42-k*.9,18-k*.32,.1,3.0,22),.28,0,.8);
    for(let i=0;i<31;i++) stroke(o,'white-chalk',.8,path(t=>[657+t*132,1167+Math.sin(t*Math.PI)*23+i*.35],23),.34,0,.7);
    for(let i=0;i<46;i++){const x=812+seed(i+90)*98,y=1135+seed(i+140)*101; stroke(o,'graphite-hb',.72,[[x,y],[x+seed(i+77)*12,y+seed(i+88)*4]],.3,0,.55);}
    // Hands recover a few articulate edges after the tray, and chalk holds the north light.
    for(let i=0;i<14;i++) stroke(o,'graphite-2b',1.5,path(t=>[250+t*165,1081+t*26+Math.sin(t*9+i)*2],18),.38,14,.8);
    for(let i=0;i<12;i++) stroke(o,'graphite-2b',1.5,path(t=>[814+t*125,1090-t*55+Math.sin(t*8+i)*2],18),.38,14,.8);
    for(let i=0;i<19;i++) stroke(o,'white-chalk',.65,path(t=>[219+t*347,744+t*37+Math.sin(t*5+i)*2],20),.27,0,.58);
    return o;
  }
};
function uAbs(){return 0;}
