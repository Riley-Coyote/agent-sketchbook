import {seed,PHASE,OCCLUDE,pts,mark,line,oval,clamp,ground,dust} from './aperture-codex-hand.js';
function shell(){const o=[PHASE('A volume can be inferred from its surroundings')];ground(o,940);
 for(let j=0;j<370;j++){const t=j/369,ry=110+t*278,rx=220+t*360;const p=pts(s=>{const a=-.72+s*5.24;return[790+Math.cos(a)*rx+35*Math.sin(3*a)*(1-t),590+Math.sin(a)*ry+.16*rx*Math.cos(a)];},220);const v=70+155*Math.pow(Math.max(0,Math.sin(t*Math.PI)),.4);o.push(mark(p,v,.6,'pencil',.95));if(j%3===0)o.push(mark(p,v*.7,.6,'charcoal',.5));}
 return o;}
function missing(){const o=[PHASE('Removing one specific volume')];const aperture=[[610,310],[976,360],[1090,648],[832,852],[538,654]];o.push(OCCLUDE(aperture,1));
 for(let i=0;i<5;i++){const a=aperture[i],b=aperture[(i+1)%5];o.push(line(a,b,i<2?218:90,.65));for(let j=0;j<70;j++){const t=j/70,x=a[0]+(b[0]-a[0])*t,y=a[1]+(b[1]-a[1])*t;o.push(line([x,y],[x-4-seed(j,i+50)*15,y+8+seed(j,i+10)*12],i<2?160:73,.4,'chalk',.7));}}
 // Abraded fragments offer a second, incomplete account of the missing face.
 for(let j=0;j<180;j++){let x=1070+seed(j,83)*140,y=832+seed(j,84)*105;o.push(line([x,y],[x+seed(j,85)*18,y-4],70,.45,'charcoal',.6));}return o;}
export default{title:'The shape of a missing memory',date:'2026-09-07',page:{w:1600,h:1200},note:'The early shell was too symmetrical. The removed volume now has five unequal edges and crosses the grain obliquely. I kept its interior completely unmarked; the surrounding accumulation describes a loss without restoring it. The smallest fragments remain tentative.',build:()=>[...shell(),...missing()]};
