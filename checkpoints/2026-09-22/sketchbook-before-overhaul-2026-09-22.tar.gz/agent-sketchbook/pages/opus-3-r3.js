import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, DOT, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, one lamp, one candle',
  date: '2026-09-05',
  note: 'a small candle added to the original scene — just a rim on the stone, a flame, and a faint glow on the table',
  build: () => {
    const ops = [];
    const L = [-0.55, -0.6, 0.58];    // the main light, as before
    const cx = 440, cy = 380, r = 90;

    ops.push(PHASE('table')); 
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    const shadow = ellipsePoly(cx + 70, cy + r - 8, 135, 26, 0.12);
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    ops.push(PAUSE(400));

    ops.push(PHASE('stone'));
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));
    ops.push(...sphereRings(cx, cy, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } }));
    ops.push(...highlight(cx - 36, cy - 44, 9)); 
    ops.push(PAUSE(500));
    
    ops.push(PHASE('candle'));
    const candleX = 650, candleY = 460;
    const candleColor = [255, 205, 130];
    ops.push(...hatchPoly([[candleX - 2, candleY - 24], [candleX + 2, candleY - 24], 
        [candleX + 2, candleY - 2], [candleX - 2, candleY - 2]], 0, 1, 0, passesFor(0.3), () => false, 1));
    ops.push(DOT(candleX, candleY - 26, 4, 'accent', 'brush', [255, 210, 140], 0.95));
    for (let i = 0; i < 5; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.random() * 3 + 2;
      ops.push(OP('s', [
        [candleX + Math.cos(a) * r, candleY - 26 + Math.sin(a) * r],
        [candleX + Math.cos(a + 0.8) * r, candleY - 26 + Math.sin(a + 0.8) * r]
      ], 'soft', 'soft', 0.6, candleColor, 0.15));
    }
    ops.push(OP('s', ellipse(candleX, candleY + 14, 60, 10), 'tone', 'glaze', 2.5, candleColor, 0.12));
    
    const rimPts = [];
    for (let a = -0.4; a < 1.4; a += 0.2) {
      rimPts.push([cx + Math.cos(a) * (r - 2), cy + Math.sin(a) * (r - 2)]);
    }
    ops.push(OP('s', rimPts, 'accent', 'chalk', 0.45, candleColor, 0.7));
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, one lamp, one candle', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
