/* Night maintenance — a native black-paper drawing.
 * A suspended archive garden is tended after its visitors have gone.
 */
import { OP, DOT, PHASE, PAUSE, OCCLUDE, jitter, seed } from '../mark-engine.js';

const W=1500,H=950,TAU=Math.PI*2;
const mix=(a,b,t)=>a+(b-a)*t;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const path=(fn,n=42)=>Array.from({length:n+1},(_,i)=>fn(i/n));
const bone=[213,218,226], steel=[108,128,156], midnight=[40,52,76];
const violet=[82,73,108], amber=[229,163,83], ember=[151,82,45];

function stroke(points,c=bone,w=1,brush='pencil',alpha=1,layer='line',wob=.1){
  return OP('s',jitter(points,wob),layer,brush,w,c,alpha);
}
function bezier(a,c,b,colour=bone,w=1,brush='pencil',alpha=1,layer='line',wob=.08){
  return stroke(path(t=>{const q=1-t;return[q*q*a[0]+2*q*t*c[0]+t*t*b[0],q*q*a[1]+2*q*t*c[1]+t*t*b[1]]},
    Math.max(18,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/7))),colour,w,brush,alpha,layer,wob);
}
function ellipse(cx,cy,rx,ry,c=bone,w=1,brush='pencil',alpha=1,layer='line',a0=0,a1=TAU){
  return stroke(path(t=>{const a=mix(a0,a1,t);return[cx+Math.cos(a)*rx,cy+Math.sin(a)*ry]},
    Math.max(24,Math.ceil((a1-a0)*Math.max(rx,ry)/8))),c,w,brush,alpha,layer,.07);
}
function podPoly(cx,cy,rx,ry){
  return path(t=>{const a=t*TAU;const taper=.78+.22*Math.sin(a);return[cx+Math.cos(a)*rx*taper,cy+Math.sin(a)*ry]},70);
}
function pod(ops,cx,cy,rx,ry,depth,salt,lit=false){
  const poly=podPoly(cx,cy,rx,ry);
  ops.push(OCCLUDE(poly,.92));
  // Translucent body: horizontal strokes widen toward its belly.
  for(let i=0;i<31;i++){
    const t=i/30,y=cy-ry+t*ry*2;
    const half=rx*Math.sqrt(Math.max(0,1-((y-cy)/ry)**2))*(.78+.22*Math.sin(Math.asin(clamp((y-cy)/ry,-1,1))));
    if(half<3)continue;
    const base=lit?amber:violet;
    const a=.045+(1-Math.abs(t-.5)*2)*.08;
    ops.push(stroke([[cx-half*.88,y],[cx-half*.18,y+1.2],[cx+half*.9,y-.5]],base,2.1,'glaze',a,'line',.12));
  }
  // Near and far edges have unequal weight.
  ops.push(stroke(poly,depth<.55?bone:steel,.42+depth*.42,'pencil',.22+depth*.2,'line',.07));
  ops.push(ellipse(cx-5,cy+2,rx*.92,ry*.985,lit?amber:steel,.55+depth*.45,'soft',lit?.4:.23,'line',.15,Math.PI*1.08));
  ops.push(ellipse(cx+3,cy,rx*.88,ry*.96,midnight,1.25,'soft',.52,'line',Math.PI*1.12,TAU+.08));
  // A branching memory-form hangs inside each vessel.
  const root=[cx,cy+ry*.56], crown=[cx+(seed(salt,4)-.5)*rx*.18,cy-ry*.5];
  ops.push(bezier(root,[cx-11,cy],crown,lit?amber:steel,.62+depth*.45,'pencil',lit?.72:.36,'line',.08));
  for(let j=0;j<7;j++){
    const u=.18+j*.105;
    const sx=mix(root[0],crown[0],u), sy=mix(root[1],crown[1],u);
    const side=j%2?-1:1;
    const reach=rx*(.24+seed(j,salt)*.36)*(1-u*.4);
    const end=[sx+side*reach,sy-ry*(.08+seed(j,salt+1)*.12)];
    ops.push(bezier([sx,sy],[sx+side*reach*.52,sy-ry*.04],end,lit&&j<4?amber:steel,.35+depth*.35,'pencil',lit?.55:.27,'line',.055));
    if((j+salt)%3===0)ops.push(DOT(end[0],end[1],.8+depth*1.8,'line','soft',lit?amber:bone,lit?.55:.28));
  }
  // Suspension hardware.
  ops.push(stroke([[cx-rx*.24,cy-ry*.96],[cx-rx*.16,cy-ry-26],[cx-rx*.12,72]],steel,.44,'pencil',.32,'line',.04));
  ops.push(stroke([[cx+rx*.24,cy-ry*.96],[cx+rx*.15,cy-ry-25],[cx+rx*.1,72]],steel,.44,'pencil',.32,'line',.04));
  ops.push(ellipse(cx,cy-ry-25,rx*.17,5,steel,.52,'soft',.35,'line'));
  if(lit){
    ops.push(ellipse(cx-7,cy-3,rx*.9,ry*.97,[245,190,115],.76,'soft',.48,'accent',2.92,4.78));
    ops.push(DOT(cx-rx*.42,cy-ry*.26,3.2+depth*2,'accent','chalk',[255,221,170],.72));
  }
}

function roomAndGarden(){
  const ops=[PHASE('01 · the room after closing')];
  const vanish=[1110,350];
  // Ceiling trusses and wall seams lead into a deep, empty service hall.
  for(let i=0;i<11;i++){
    const x=80+i*124;
    ops.push(stroke([[x,65],vanish],midnight,.55,'pencil',.27,'under',.05));
  }
  for(let i=0;i<8;i++){
    const y=112+i*83;
    ops.push(stroke([[35,y],[vanish[0],mix(y,vanish[1],.82)]],steel,.34,'pencil',.16,'line',.05));
  }
  // Receding ceiling rails: smooth weight for metal, narrow bright edge on only one side.
  ops.push(bezier([70,82],[690,112],vanish,steel,2.3,'soft',.34,'line',.04));
  ops.push(bezier([1430,78],[1254,180],vanish,steel,1.8,'soft',.27,'line',.04));
  ops.push(bezier([75,84],[690,114],vanish,bone,.42,'pencil',.42,'line',.04));
  // Floor plane and its interrupted reflection seams.
  for(let i=0;i<16;i++){
    const t=i/15,y=650+t*265;
    const x0=50+t*160,x1=1450-t*95;
    ops.push(stroke([[x0,y],[760,y-8],[x1,y-22]],midnight,1.5+2*t,'glaze',.09+.05*t,'line',.15));
  }
  for(const x of [190,470,820,1210,1440])ops.push(stroke([[x,940],vanish],steel,.36,'pencil',.16,'line',.04));
  // A closed doorway is a quiet vertical counterweight at the far end.
  ops.push(stroke([[1164,241],[1164,557],[1278,568],[1278,183]],steel,.68,'pencil',.25,'line',.04));
  ops.push(stroke([[1173,247],[1173,548]],bone,.38,'pencil',.34,'line',.04));
  ops.push(DOT(1200,449,2.4,'line','soft',amber,.48));

  ops.push(PHASE('02 · suspended records'));
  // Back to front so nearer glass interrupts the architecture and smaller vessels.
  pod(ops,1070,357,47,78,.25,17,false);
  pod(ops,918,318,58,94,.35,29,false);
  pod(ops,1200,430,70,116,.42,41,false);
  pod(ops,765,366,83,137,.58,53,false);
  pod(ops,1018,552,96,155,.68,67,false);
  pod(ops,565,445,132,207,.9,79,true);

  // Sparse dust records the lamp cone without filling the room.
  for(let i=0;i<95;i++){
    const x=420+seed(i,91)*470,y=246+seed(i,92)*390;
    const dx=x-565,dy=y-445;
    if(Math.hypot(dx,dy)>270||seed(i,93)<.36)continue;
    ops.push(DOT(x,y,.35+seed(i,94)*1.2,'under','stipple',seed(i,95)>.8?amber:bone,.08+seed(i,96)*.14));
  }
  ops.push(PAUSE(900));
  return ops;
}

function glassAndCaretaker(){
  const ops=[PHASE('03 · glass remembers the room')];
  // Break the two ceiling rails where their brightness encloses the garden too neatly.
  ops.push(stroke([[585,150],[770,193],[955,258]],bone,2.5,'eraser',.48,'line',.03));
  ops.push(stroke([[1210,210],[1300,150],[1390,93]],bone,2.2,'eraser',.42,'line',.03));
  // Restate short structural pieces in a quieter, jointed rhythm.
  for(const seg of [[[74,83],[270,101]],[[360,119],[518,142]],[[1008,277],[1098,325]],[[1328,137],[1426,81]]])
    ops.push(stroke(seg,steel,.55,'pencil',.28,'line',.04));

  // Foreground glass: displaced room seams and window-like reflections create thickness.
  for(let i=0;i<17;i++){
    const y=286+i*18;
    const t=(y-286)/(18*16);
    const half=118*Math.sqrt(Math.max(0,1-((y-445)/207)**2));
    if(half<8)continue;
    const bend=Math.sin(t*Math.PI)*13;
    ops.push(stroke([[565-half*.74,y],[565-bend,y+3],[565+half*.58,y-2]],
      i%5===0?amber:violet,.52+i%3*.12,'pencil',i%5===0?.26:.16,'line',.07));
  }
  // Broken window strips replace a complete bright rim.
  const glints=[
    [[454,315],[441,358],[438,408]],
    [[439,454],[443,497],[453,532]],
    [[478,596],[513,631],[550,642]],
    [[658,554],[675,511],[681,469]],
  ];
  glints.forEach((p,i)=>ops.push(stroke(p,i===2?bone:amber,i===2?1.05:.72,i===2?'chalk':'pencil',.55,'accent',.045)));
  // Lift portions of the old continuous foreground ellipse so the glints become the edge hierarchy.
  ops.push(stroke([[448,323],[437,397],[440,473]],bone,2.1,'eraser',.5,'line',.03));
  ops.push(stroke([[675,350],[686,424],[681,509]],bone,2.1,'eraser',.5,'line',.03));
  ops.push(stroke([[489,611],[543,652],[600,640]],bone,2.0,'eraser',.46,'line',.03));

  // Sleeping records are substantially lost into the room; their missing rims separate depth.
  const sleepingLifts=[
    [765,366,83,137,-2.8,-1.1,2.0],[765,366,83,137,.25,1.45,1.7],
    [1018,552,96,155,-.6,.8,2.1],[1018,552,96,155,2.05,3.05,1.7],
    [918,318,58,94,.45,1.8,1.55],[1070,357,47,78,-2.8,-1.45,1.45],
    [1200,430,70,116,-.4,.9,1.65],
  ];
  for(const [cx,cy,rx,ry,a0,a1,w] of sleepingLifts)
    ops.push(ellipse(cx,cy,rx,ry,bone,w,'eraser',.54,'line',a0,a1));

  // The awake record is denser and less botanical than the sleeping ones: branching recalls repairs and returns.
  const trunk=[[560,562],[556,512],[558,462],[557,410],[559,354]];
  ops.push(stroke(trunk,amber,.68,'pencil',.75,'accent',.05));
  const returns=[
    [[557,492],[516,470],[489,441]],[[558,475],[596,451],[626,416]],
    [[557,445],[522,418],[500,389]],[[558,426],[590,397],[611,366]],
    [[558,397],[534,372],[520,345]],[[558,380],[581,356],[596,326]],
    [[559,518],[520,535],[487,530]],[[558,505],[598,522],[632,507]],
  ];
  returns.forEach((p,i)=>{
    ops.push(stroke(p,i%3===0?bone:amber,.38+(i%2)*.14,'pencil',.42+(i%3)*.09,'line',.045));
    if(i%2===0)ops.push(DOT(p[2][0],p[2][1],1.1+i*.15,'accent','soft',i===4?bone:amber,.44));
  });
  // Unequal crossings and compressed repairs interrupt the tree-like reading.
  ops.push(bezier([486,432],[552,470],[632,447],bone,.42,'pencil',.48,'line',.045));
  ops.push(bezier([505,513],[556,457],[618,487],amber,.5,'pencil',.61,'line',.045));
  ops.push(bezier([512,381],[558,438],[607,334],steel,.34,'pencil',.42,'line',.045));
  for(let i=0;i<13;i++){
    const a=seed(i,301)*TAU,r=5+seed(i,302)*19;
    const x=558+Math.cos(a)*r,y=456+Math.sin(a)*r*.68;
    ops.push(DOT(x,y,.6+seed(i,303)*1.5,'accent',i%5===0?'chalk':'soft',i%4===0?bone:amber,.32+seed(i,304)*.38));
  }
  const fineReaches=[
    [[520,345],[489,315],[455,301]],[[596,326],[626,301],[653,268]],
    [[500,389],[461,371],[431,341]],[[632,507],[663,522],[692,510]],
    [[487,530],[452,548],[422,540]],
  ];
  fineReaches.forEach((p,i)=>ops.push(stroke(p,i===1?bone:steel,.26+(i%2)*.12,'pencil',.3+(i===1?.2:0),'line',.035)));
  // Tiny suspended fragments make the internal volume deeper than a single plane.
  for(let i=0;i<42;i++){
    const a=seed(i,311)*TAU,r=Math.sqrt(seed(i,312))*105;
    const x=560+Math.cos(a)*r*.83,y=443+Math.sin(a)*r*1.55;
    if(((x-565)/125)**2+((y-445)/196)**2>1)continue;
    ops.push(DOT(x,y,.35+seed(i,313)*1.25,'line',i%7===0?'chalk':'stipple',i%8===0?amber:steel,.12+seed(i,314)*.22));
  }

  ops.push(PHASE('04 · the caretaker enters'));
  // Low trolley on the floor, deliberately small beside the archive vessels.
  for(let i=0;i<9;i++)ops.push(stroke([[662,739+i*2],[729,742+i*1.2],[767,731+i*.5]],
    i<3?steel:midnight,1.2,'soft',.24+(8-i)*.025,'line',.05));
  ops.push(stroke([[665,738],[729,741],[769,730],[752,708],[682,710],[665,738]],bone,.56,'pencil',.52,'line',.04));
  ops.push(ellipse(690,746,18,7,steel,.9,'soft',.44,'line',0,Math.PI));
  ops.push(ellipse(742,742,16,6,steel,.8,'soft',.4,'line',0,Math.PI));
  // An articulated arm rises, changes direction at two joints, and touches the lit vessel.
  ops.push(stroke([[718,711],[706,646],[674,594]],midnight,3.6,'soft',.7,'line',.04));
  ops.push(stroke([[718,710],[706,646],[674,594]],steel,1.4,'soft',.68,'line',.04));
  ops.push(stroke([[674,594],[640,553],[626,511]],steel,1.15,'soft',.73,'line',.04));
  for(const [x,y,r] of [[718,711,6],[706,646,7],[674,594,6]]){
    ops.push(DOT(x,y,r,'line','soft',midnight,.9));
    ops.push(DOT(x-1,y-1,r*.42,'accent','chalk',bone,.58));
  }
  // The tool emits a narrow inspection light, not a theatrical beam.
  ops.push(stroke([[626,511],[610,494],[597,474]],amber,.72,'pencil',.72,'accent',.04));
  ops.push(DOT(596,473,3.4,'accent','soft',amber,.72));
  ops.push(DOT(592,468,1.1,'accent','chalk',[255,225,177],.82));
  // Reflections anchor the trolley to the floor.
  for(let i=0;i<13;i++){
    const y=759+i*6;
    ops.push(stroke([[675+i*1.3,y],[720,y-2],[758-i*.7,y-5]],i%4===0?ember:midnight,
      1.1+i*.08,'glaze',.12*(1-i/15),'line',.12));
  }
  ops.push(PAUSE(900));
  return ops;
}

function letTheGardenSleep(){
  const ops=[PHASE('05 · let the garden sleep')];
  const coverArc=(cx,cy,rx,ry,t0,t1,w)=>{
    const poly=podPoly(cx,cy,rx,ry);
    const a=Math.floor(t0*(poly.length-1)),b=Math.floor(t1*(poly.length-1));
    return stroke(poly.slice(a,b+1),[13,16,24],w,'soft',.9,'line',.03);
  };
  // Exact-path dark paint takes whole rim spans away rather than merely scratching them.
  ops.push(coverArc(765,366,83,137,.02,.2,2.7));
  ops.push(coverArc(765,366,83,137,.47,.7,2.5));
  ops.push(coverArc(918,318,58,94,.18,.43,2.2));
  ops.push(coverArc(918,318,58,94,.7,.93,2.2));
  ops.push(coverArc(1070,357,47,78,.05,.34,2.0));
  ops.push(coverArc(1200,430,70,116,.38,.67,2.45));
  ops.push(coverArc(1018,552,96,155,.0,.18,2.6));
  ops.push(coverArc(1018,552,96,155,.53,.77,2.8));
  // Veils of room tone make two records seem to pass behind darkness rather than sit on it.
  for(let i=0;i<9;i++){
    const y=270+i*16;
    ops.push(stroke([[864,y],[918,y+2],[967,y-1]],[14,18,28],2.4,'soft',.42,'line',.08));
  }
  for(let i=0;i<11;i++){
    const y=442+i*22;
    ops.push(stroke([[930,y],[1016,y-3],[1091,y+4]],[14,18,28],2.6,'soft',.38,'line',.08));
  }
  // A few short cold reflections retain the possibility of glass in the lost shapes.
  ops.push(bezier([724,288],[748,269],[772,271],steel,.48,'pencil',.36,'line',.04));
  ops.push(bezier([1038,288],[1055,276],[1068,284],steel,.4,'pencil',.3,'line',.04));
  ops.push(bezier([1138,478],[1166,501],[1190,496],steel,.42,'pencil',.34,'line',.04));

  ops.push(PHASE('06 · weight on the floor'));
  // Contact shadow and a weak amber reflection settle the machine onto the plane.
  for(let i=0;i<14;i++){
    const y=752+i*2.8,fade=1-i/14;
    ops.push(stroke([[650-i*1.4,y],[720,y+2],[787+i*2,y-3]],[15,18,25],2.6,'soft',.34*fade,'line',.08));
  }
  ops.push(bezier([681,769],[709,778],[750,764],ember,.62,'glaze',.19,'line',.07));
  // Quiet one long arm segment; keep brightness only at joints and tool tip.
  ops.push(stroke([[711,650],[690,616],[667,585]],bone,2.0,'eraser',.24,'line',.025));
  ops.push(stroke([[711,650],[690,616],[667,585]],steel,.72,'pencil',.46,'line',.025));
  ops.push(PAUSE(800));
  return ops;
}

export { roomAndGarden, glassAndCaretaker, podPoly, stroke, bezier, ellipse };

const passes=[{
  name:'The room and suspended records',
  note:'A closed service hall recedes toward a quiet door. Six archive vessels hang at different depths; only the nearest is awake, its branching record lit from within.',
  review:{
    observation:'The depth sequence and amber foreground vessel read at fit scale, but continuous oval rims make the vessels feel diagrammatic. In detail the internal branches repeat as one sparse symbol, and the two bright ceiling rails compete with the focal record.',
    change:'Initial construction with converging rails, interrupted floor seams, translucent stroked vessels, unequal rims, internal branches, and one localized amber light.',
    next:'Break the foreground rim into reflection glints, refract room seams through its body, quiet the overhead rails, and introduce a small maintenance action that explains the light.',
    region:[390,190,820,500],
  },
  build:roomAndGarden,
},{
  name:'Glass and the caretaker',
  note:'The awake vessel now bends pieces of the room through its body and carries interrupted edge glints. A small wheeled caretaker reaches into it with an articulated inspection arm; its local light activates a denser, returning branch structure.',
  review:{
    observation:'The awake vessel now reads through refracted seams and a dense unequal record, and the small caretaker is legible. Several sleeping rims remain too complete, leaving the background as a constellation of equal capsules; the long bright arm also floats above a weak floor contact.',
    change:'Lifted long rim and rail segments; added refracted seams, broken glints, denser internal returns, suspended fragments, a low trolley, jointed arm, inspection light, and floor reflections.',
    next:'Use the exact vessel paths to lose long rim sections into darkness, veil two distant bodies, and settle the trolley with a restrained contact shadow.',
    region:[390,250,430,570],
  },
  build:glassAndCaretaker,
},{
  name:'Let the garden sleep',
  note:'The sleeping vessels lose whole edge spans and two pass behind veils of room tone; only short cold reflections remain. The caretaker gains floor weight while its long arm is quieted between the luminous joints.',
  review:{
    observation:'Inspect whether depth now comes from unequal visibility rather than size alone, whether the awake vessel remains the only fully active interior, and whether the trolley makes believable contact with the floor.',
    change:'Covered exact rim spans with dark same-layer paint, veiled two distant records, restored three small glass cues, added a contact shadow, and reduced the arm’s continuous brightness.',
    next:'Use a whole view and separate foreground/background details to decide whether the hall needs one final spatial correction or can remain unresolved and quiet.',
    region:[650,210,610,570],
  },
  build:letTheGardenSleep,
}];

export default{
  title:'Night maintenance',date:'2026-09-07',page:{w:W,h:H},
  note:'I wanted to draw care that happens without an audience: records kept alive in a room after closing. The first pass asks whether darkness can feel inhabited rather than merely empty.',
  passes,build:()=>passes.flatMap(p=>p.build()),
};
