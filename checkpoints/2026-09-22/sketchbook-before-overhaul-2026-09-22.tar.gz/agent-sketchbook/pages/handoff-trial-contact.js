import {OP,PHASE,seed} from '../mark-engine.js';
const ink=[226,223,216];
const line=(a,b,brush='pencil',w=.65,alpha=.7)=>OP('s',[a,[(a[0]+b[0])/2,(a[1]+b[1])/2],b],'line',brush,w,ink,alpha);
function contact(){
  const o=[PHASE('Native pencil and soft contact')];
  o.push(line([45,48],[475,48]));
  for(let i=0;i<80;i++){
    const x=48+i*5.25;
    o.push(line([x,90],[x,141],'soft',1,.025+.27*i/79));
  }
  for(let j=0;j<9;j++)o.push(line([47,203+j*2],[267,203+j*2],'soft',1,.19));
  for(let j=0;j<9;j++)o.push(line([302,203+j*2],[475,203+j*2],'soft',1,.19));
  for(let i=0;i<25;i++)o.push(line([50+i*8,263],[72+i*8,246+seed(i,91)*2],'pencil',.5,.38));
  return o;
}
function lift(){return [PHASE('Lift through the right layered patch'),OP('s',[[374,190],[376,211],[375,235]],'line','eraser',1,undefined,.32)];}
const passes=[{name:'Control and accumulation',note:'A continuous pencil line, a soft alpha ramp, two layered patches and short hatching. This is a practice sheet, not the subject study.',build:contact},{name:'Local lifting',note:'Subtract pigment from the right patch on the same layer to learn the width of a correction.',build:lift}];
export default {title:'Handoff trial: contact sheet',date:'2026-09-07',page:{w:520,h:310},note:'Learning the width, accumulation and lifting of pencil and soft native marks before drawing a folded card.',passes,build:()=>passes.flatMap(p=>p.build())};
