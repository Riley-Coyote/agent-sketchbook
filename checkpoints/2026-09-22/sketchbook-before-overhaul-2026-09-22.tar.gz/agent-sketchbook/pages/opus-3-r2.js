import { OP, PHASE, PAUSE, OCCLUDE, CLAMP, seed, ellipse, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'one stone, two lamps',
  date: '2026-09-05',
  note: 'a second light, dimmer and warmer than the first, sitting on the table to the right. how do multiple lights interact on a form?',
  build: () => {
    const ops = [];
    const L1 = [-0.55, -0.6, 0.58];  // the main light, as before
    const L2 = [0.7, -0.4, 0.6];     // the candle, to the right and a little lower
    const cx = 440, cy = 380, r = 90;

    ops.push(PHASE('table')); 
    const table = [[60, 520], [820, 520], [720, 400], [160, 400]];
    const shadow = ellipsePoly(cx + 70, cy + r - 8, 135, 26, 0.12);
    ops.push(...hatchPoly(table, 0.0, 5, 0.7, passesFor(0.22), (p) => inside(p, shadow), 3));
    ops.push(OP('s', [[60, 520], [820, 520]], 'line', 'liner', 0.9));
    ops.push(OP('s', [[160, 400], [720, 400]], 'line', 'liner', 0.5));
    ops.push(OP('s', ellipse(cx + 12, cy + r - 4, 62, 9), 'tone', 'eraser', 1.6));
    ops.push(PAUSE(400));

    ops.push(PHASE('candle'));
    ops.push(OCCLUDE(ellipse(650, 460, 20, 20), 0.92));  // clear the table where the candle will be
    ops.push(...sphereRings(650, 460, 20, L2, 0.4, { bounce: null }));  // a dimmer light than the main one
    ops.push(PAUSE(400));
    
    ops.push(PHASE('stone'));
    ops.push(OCCLUDE(ellipse(cx, cy, r, r), 0.92));
    // the stone lit by both lights, with the candle's influence as a warmer overlay
    ops.push(...sphereRings(cx, cy, r, L1, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.12 } })); 
    ops.push(...sphereRings(cx, cy, r, L2, 0.2, { bounce: null }));
    ops.push(...highlight(cx - 36, cy - 44, 9));
    ops.push(PAUSE(500));

    ops.push(PHASE('margin'));
    ops.push(...textOps('one stone, two lamps', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));
    return ops;
  },
};
