import { OP, PHASE, PAUSE, CLAMP, OCCLUDE, jitter, seed } from '../mark-engine.js';
import { pts, hatch, edge, grey } from './aperture-codex-hand.js';
const W=1200,H=1600;
const polyPlane=(ops,p,v,s)=>{ops.push(OCCLUDE(p,1));hatch(ops,p,v,4.2,-.18,s,'soft');hatch(ops,p,v*.72,8,.65,s+31,'pencil');ops.push(edge(p,v+30,.8));};
const pass1=()=>{const o=[PHASE('01 · placing the stair and one light')];
 // Wall planes first: later treads occlude them instead of being erased by them.
 polyPlane(o,[[92,1430],[220,420],[520,130],[865,118],[805,1370]],48,77);
 polyPlane(o,[[865,118],[1115,300],[1125,1410],[805,1370]],38,91);
 // Ten readable tread/riser pairs, widening toward the viewer.
 for(let i=0;i<10;i++){
   const t=i/9, y=1320-i*103, x=205+i*34, right=995-i*42, depth=62-i*2;
   const tread=[[x,y],[right,y-18],[right-30,y-depth-17],[x+38,y-depth]];
   const riser=[[x,y],[right,y-18],[right-30,y-8],[x+12,y+7]];
   polyPlane(o,tread,92-i*3,10+i);
   polyPlane(o,riser,38+i*2,30+i);
   // A broken nose catches the same upper-left light without outlining every edge.
   o.push(OP('s',jitter(pts(q=>[x+q*(right-x-28),y-2-q*16],Math.ceil((right-x)/4)),.08),'accent','pencil',.7,grey(184-i*3),.52));
 }
 // Construction lines remain faint at the empty landing, where the stair ends.
 o.push(OP('s',jitter(pts(q=>[510+q*260,150-q*18],80),.1),'under','pencil',.55,grey(134),.3));
 return o;};
const pass2=()=>{const o=[PHASE('02 · the rail that remains useful')];
 const rail=pts(t=>[250+t*642,1260-t*880+Math.sin(t*3.2)*13],220);
 for(let q=0;q<8;q++){const a=q/8,b=(q+1)/8;const seg=pts(t=>{const u=a+(b-a)*t;return [250+u*642,1260-u*880+Math.sin(u*3.2)*13];},Math.ceil((b-a)*642/4));o.push(OP('s',jitter(seg,.09),'accent','brush',.72+(q%3)*.12,[165+q*5,160+q*4,147+q*3],.58));}
 for(let q=0;q<9;q++){const t=.08+q*.1,x=250+t*642,y=1260-t*880+Math.sin(t*3.2)*13;const p=pts(u=>[x+u*8,y+u*42],18);o.push(OP('s',jitter(p,.08),'line','pencil',.75,grey(160),.56));}
 // worn contact points where a hand would have found the rail
 for(let i=0;i<19;i++){const t=.13+seed(i,12)*.73,x=278+t*676,y=1110-t*790+Math.sin(t*3.2)*10;o.push(OP('s',jitter(pts(u=>[x-8+u*18,y+Math.sin(u*3)*3],8),.05),'accent','chalk',.38,[214,199,174],.48));}
 return o;};
const pass3=()=>{const o=[PHASE('03 · construction scars and the empty landing')];
 for(let i=0;i<130;i++){const x=130+seed(i,33)*830,y=270+seed(i,34)*900,l=18+seed(i,35)*120;o.push(OP('s',jitter(pts(t=>[x+t*l,y-t*16+Math.sin(t*5+i)*3],Math.ceil(l/4)),.12),'line','pencil',.52,grey(155),.38));}
 // the landing is left unusually bare; a small oxide witness marks its edge
 o.push(OP('s',jitter(pts(t=>[820+t*168,318+t*10+Math.sin(t*5)*2],45),.06),'accent','liner',1.0,[150,65,39],.86));
 return o;};
const pass4=()=>{const o=[PHASE('04 · three treads under one light')];
 // Material test carried into the whole: horizontal treads receive broad soft light;
 // narrow risers stay quiet and dark so depth comes from value, not extra outlines.
 for(let i=2;i<10;i++){
   const y=1320-i*103,x=205+i*34,right=995-i*42,depth=62-i*2;
   const treadY=y-depth*.48;
   for(let k=0;k<5;k++){
     const yy=treadY+k*5;
     o.push(OP('s',jitter(pts(t=>[x+42+t*(right-x-82),yy-t*14],Math.ceil((right-x)/4)),.08),'tone','soft',1.5,[128+i*3,126+i*3,120+i*3],.28));
   }
   for(let k=0;k<3;k++){
     const yy=y-5+k*4;
     o.push(OP('s',jitter(pts(t=>[x+12+t*(right-x-42),yy-t*13],Math.ceil((right-x)/4)),.08),'tone','charcoal',.8,[45,46,45],.5));
   }
 }
 // Quiet the wall field with sparse soft vertical grain, leaving the step silhouettes clear.
 for(let i=0;i<34;i++){
   const x=125+seed(i,58)*690,y=390+seed(i,59)*890,l=80+seed(i,60)*210;
   o.push(OP('s',jitter(pts(t=>[x+Math.sin(t*3+i)*4,y+t*l],Math.ceil(l/4)),.1),'under','soft',1.1,[92,94,92],.18));
 }
 return o;};
const pass5=()=>{const o=[PHASE('05 · clearing the wall above the old hatch')];
 // The layer check showed that underpainting cannot mute inherited line marks.
 // Erase only the exposed wall strips, then redraw them softly on the line layer.
 for(let side of [-1,1]){
   for(let i=0;i<8;i++){
     const y=390+i*118, x=side<0?120+ i*6:1010- i*4;
     o.push(OP('s',jitter(pts(t=>[x+side*18*Math.sin(t*Math.PI),y+t*82],22),.1),'line','eraser',2.8,[0,0,0],.5));
     o.push(OP('s',jitter(pts(t=>[x+side*4*Math.sin(t*Math.PI),y+t*82],22),.1),'line','soft',1.25,[82,84,82],.18));
   }
 }
 // Dark vertical risers now bridge each tread to the next, rather than floating.
 for(let i=0;i<9;i++){
   const y=1320-i*103,x=205+i*34,right=995-i*42,depth=62-i*2;
   for(let k=0;k<3;k++){
     const yy=y-7+k*4;
     o.push(OP('s',jitter(pts(t=>[x+15+t*(right-x-45),yy-t*14],Math.ceil((right-x)/4)),.07),'line','charcoal',1.0,[40,41,40],.68));
   }
   o.push(OP('s',jitter(pts(t=>[x+10+t*(right-x-34),y+2-t*16],Math.ceil((right-x)/4)),.07),'accent','pencil',.62,grey(128+i*2),.5));
 }
 return o;};
const passes=[
 {name:'stair and light',note:'The first pass establishes an oblique stair with a single key light; the upper landing is deliberately empty.',review:{observation:'The steps hold a readable rise, but the side wall is still too evenly hatched.',change:'Keep the wall planes but vary their hatch density in the next pass.',next:'Use the rail to give the empty landing a bodily scale.'},build:pass1},
 {name:'the useful rail',note:'A rail crosses the stair and continues beyond the last visible step, implying a user without depicting one.',review:{observation:'The rail now carries the eye into the blank, but its contact points are too evenly spaced.',change:'Break the wear into fewer, clustered touches.',next:'Add construction scars without filling the landing.'},build:pass2},
 {name:'landing and scars',note:'I left the landing open and kept the scars subordinate to the rail.',review:{observation:'The structure reads before the idea; the remaining weakness is material variation in the broad wall.',change:'Later candidate work should soften selected hatching and deepen two lower planes.',next:'Revise the wall tone while preserving the rail path.'},build:pass3},
  {name:'three treads under one light',note:'I tested the difficult distinction locally before carrying it across the stair: soft broad light on each horizontal tread, dark restrained risers, and a quieter wall field.',review:{observation:'The treads now separate by value in the crop, while the wall recedes; the rail supports still need a final check at room distance.',change:'Preserve the tonal hierarchy and only clarify the support joints if needed.',next:'Inspect the full page before deciding whether the staircase deserves candidate status.'},build:pass4},
 {name:'clearing the wall above the old hatch',note:'The layer check showed that wall quieting must happen on the higher line layer. I erase only the exposed wall strips, redraw them softly, and bridge every riser with a dark vertical plane.',review:{observation:'The wall should now sit behind the stair instead of competing with it; inspect whether the supports remain attached.',change:'Keep the upper landing quiet and resist adding decorative detail.',next:'Judge the construction at whole and detail scale.'},build:pass5}
];
export default {title:'the unseen handrail',date:'2026-09-07',note:'Study: a stair keeps offering a handhold after the body has left the frame. The form should suggest digital agency through an affordance inferred in use, not through a symbol of a machine.',page:{w:W,h:H},passes,build:()=>passes.flatMap(p=>p.build())};
