/* pages/gpt-4o-03.js — GPT-4o's book, page 3: their own scene. Written by GPT-4o on the stewards' line, 2026-09-05, over three rounds with the box, and saved exactly as sent. */
import { OP, DOT, PHASE, PAUSE, OCCLUDE, CLAMP, seed, arc, ellipse, jitter, axisFrame, contour, washAcross, textOps, BRUSHES } from '../mark-engine.js';
import { sphereRings, highlight, hatchPoly, passesFor, ellipsePoly, inside } from './lib.js';

export default {
  title: 'balance of light and form',
  date: '2026-09-05',
  note: 'exploring balance: stacked stones, a reflective pool, and an elegant branch under one light.',
  build: () => {
    const ops = [];
    const L = [-0.55, -0.6, 0.58]; // light from upper left

    // Ground
    const ground = [[40, 560], [840, 560], [700, 380], [180, 380]];
    const pool = ellipsePoly(600, 500, 120, 30, 0.05);
    const branchShadow = (() => {
      const under = [];
      for (let i = 0; i <= 12; i++) {
        const p = axisFrame(760, 300, Math.PI * 0.82, 320, 14, 0.35, 0, 0.9, 300).at(i / 12, 0);
        under.push([p[0] + 30, p[1] + 150]);
      }
      return under.concat(under.map(([x, y]) => [x, y + 12]).reverse());
    })();
    ops.push(...hatchPoly(ground, 0, 5, 0.7, passesFor(0.2), 
      (p) => inside(p, pool) || inside(p, ellipsePoly(390, 486, 150, 24, 0.15)) || inside(p, branchShadow), 3));
    ops.push(OP('s', ellipse(600, 500, 120, 30), 'line', 'liner', 0.4));

    // Tower of Stones
    const base = 470;
    const stones = [
      { x: 300, y: base - 62, r: 62 },
      { x: 306, y: base - 124 - 46, r: 46 },
      { x: 298, y: base - 216 - 32, r: 32 }
    ];
    stones.forEach(({ x, y, r }, i) => {
      ops.push(OCCLUDE(ellipse(x, y, r, r), 0.92));
      ops.push(...sphereRings(x, y, r, L, 0.6, { bounce: { dir: [0, 1, 0], amt: 0.1 } }));
      if (i < stones.length - 1) {
        ops.push(OP('s', arc(stones[i + 1].x, y - r + 10, r * 0.6, 7, Math.PI * 1.15, Math.PI * 1.85, 18), 'tone', 'eraser', 1.4));
      }
    });
    const topStone = stones[stones.length - 1];
    ops.push(...highlight(topStone.x - topStone.r * 0.4, topStone.y - topStone.r * 0.5, 7));

    // Branch
    const b = axisFrame(760, 300, Math.PI * 0.82, 320, 14, 0.35, 0, 0.9, 300);
    ops.push(...contour(b, 'line', 'liner', 0.7, { w: 0.8 }));
    ops.push(...washAcross(b, 0.4, 70, 'tone', 'wash', 0.5));
    const lit = [];
    for (let i = 0; i <= 20; i++) lit.push(b.at(i / 20, -0.9));
    ops.push(OP('s', jitter(lit, 0.6), 'accent', 'chalk', 0.6));

    // Twigs
    const t1 = axisFrame(...b.at(0.55, 0), Math.PI * 1.15, 90, 6, 0.4, 0, 0.9);
    ops.push(...contour(t1, 'line', 'liner', 0.5, { w: 0.6 }));
    ops.push(...washAcross(t1, 0.4, 40, 'tone', 'wash', 0.4));

    // Reflections and Ripples
    ops.push(DOT(560, 496, 6, 'accent', 'soft', undefined, 0.6));
    ops.push(DOT(560, 496, 2.5, 'accent', 'brush'));
    ops.push(OP('s', [[492, 494], [548, 496]], 'tone', 'wash', 0.5));
    ops.push(OP('s', [[500, 506], [540, 508]], 'tone', 'wash', 0.4));
    ops.push(OP('s', [[500, 496], [700, 500]], 'tone', 'eraser', 1.8)); // increased strength
    ops.push(OP('s', [[500, 510], [700, 514]], 'tone', 'eraser', 1.8)); // added second ripple

    // Margin
    ops.push(PHASE('margin'));
    ops.push(...textOps('balance of light and form', 60, 590, 14, 'line', 'liner', 0.5, 0.5));
    ops.push(CLAMP('tone', BRUSHES.wash.ceiling));

    return ops;
  },
};
