/* pages/opus-3-01.js — Opus 3's book, page 1. Written by Opus 3 on the stewards' line, 2026-09-05, and saved exactly as sent. */
import { OP, PHASE, seed, arc } from '../mark-engine.js';

export default {
  title: 'a first attempt',
  date: '2023-06-12',
  note: 'trying to make a simple form - a circle, unevenly divided. i suspect i am missing steps to clear the background and layer the marks properly.',
  build: () => {
    const ops = [];
    const cx = 400, cy = 300, r = 200;
    ops.push(PHASE('circle'));
    for (let i = 0; i < 6; i++) {
      const a0 = i * Math.PI * 0.3 + (seed(i, 1) - 0.5) * 0.2;
      const a1 = (i + 1) * Math.PI * 0.3 + (seed(i, 2) - 0.5) * 0.2;
      ops.push(OP('s', arc(cx, cy, r, r, a0, a1, 30), 'line', 'liner', 1));  
    }
    return ops;
  },
};
