import { OP, PHASE, OCCLUDE, seed } from '../mark-engine.js';
const PI=Math.PI, W=1600,H=1100;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const points=(f,n=48)=>Array.from({length:n+1},(_,i)=>f(i/n));
const norm=a=>{const l=Math.hypot(...a);return a.map(v=>v/l);};
const world=(u,v)=>[
  230+1050*u+43*Math.sin(PI*v)*Math.sin(2*PI*u),
  198+585*v+128*Math.sin(2*PI*u+.6)*Math.sin(PI*v)+170*Math.sin(PI*u)*(1-.48*v)-70*u,
  144*Math.sin(2.4*PI*u-.8)*(.43+.57*Math.sin(PI*v))+43*Math.sin(2*PI*v+3*u)
];
const project=([x,y,z])=>[x+.25*z,y-.4*z];
const p=(u,v)=>project(world(u,v));
function light(u,v){
 const d=.002,a=world(u-d,v),b=world(u+d,v),c=world(u,v-d),e=world(u,v+d);
 const U=b.map((x,i)=>x-a[i]),V=e.map((x,i)=>x-c[i]);
 const N=norm([U[1]*V[2]-U[2]*V[1],U[2]*V[0]-U[0]*V[2],U[0]*V[1]-U[1]*V[0]]),L=norm([-.48,-.56,1]);
 return .08+.92*Math.pow(Math.max(0,N.reduce((s,x,i)=>s+x*L[i],0)),2.1);
}
const mark=(pts,value,w=.5,brush='pencil',alpha=.9,layer='line')=>OP('s',pts,layer,brush,w,[value,value+1,value+3].map(x=>Math.round(clamp(x,0,255))),alpha);
const edge=()=>[...points(t=>p(t,0),100),...points(t=>p(1,t),60),...points(t=>p(1-t,1),100),...points(t=>p(0,1-t),60)];
function sheet(){
 const o=[PHASE('A suspended surface'),OCCLUDE(edge(),1)];
 // Continuous overlapping native soft strokes carry broad value; each follows a warp.
 for(let j=0;j<=450;j++){
  const u=j/450;
  for(let k=0;k<16;k++){
   const v=k/16,vm=v+1/32,low=Math.max(0,v-.018),high=Math.min(1,v+1/16+.018);
   o.push(mark(points(t=>p(u,low+t*(high-low)),14),18+116*light(u,vm),1.0,'soft',.88));
  }
 }
 return o;
}
function threads(){
 const o=[PHASE('Pressure shared between threads')];
 // Some warps tighten while others almost disappear into the body of the cloth.
 for(let i=0;i<=258;i++){
  const u=(i+.14*Math.sin(i*2.31))/258;
  for(let k=0;k<8;k++){
   const v=k/8,vm=v+1/16,l=light(u,vm),vary=.64+.36*seed(i,k+210);
   o.push(mark(points(t=>p(u,v+t/8),20),30+143*l*vary,.24+.11*seed(i,75),'pencil',.66));
  }
 }
 for(let j=0;j<=196;j++){
  const v=j/196;
  for(let k=0;k<10;k++){
   const u=k/10,um=u+.05,l=light(um,v);
   o.push(mark(points(t=>p(u+t/10,v+.0004*Math.sin(t*8+j)),15),18+110*l,.2,'pencil',.46));
  }
 }
 // The lower selvedge loosens into individual threads instead of a closed outline.
 for(let i=0;i<96;i++){
  const u=.04+.92*seed(i,622),L=5+28*seed(i,712),a=p(u,1);
  o.push(mark(points(t=>[a[0]+Math.sin(t*2.6+i)*t*8,a[1]+t*L],12),39+77*light(u,1),.3,'pencil',.66));
 }
 return o;
}

function tension(){
 const o=[PHASE('Held, with an edge left open')];
 const corners=[{u:0,to:[66,-20]},{u:1,to:[1463,-18]}];
 for(const {u,to} of corners){
  const a=p(u,0);
  o.push(mark(points(t=>[to[0]*(1-t)+a[0]*t,to[1]*(1-t)+a[1]*t],70),57,.42,'pencil',.76));
  o.push(mark(points(t=>[a[0]+Math.cos(t*PI*2)*3.4,a[1]+Math.sin(t*PI*2)*2.4],25),156,.38,'pencil',.8));
  for(let j=0;j<18;j++){
   const endU=u===0?.022+j*.004:1-(.022+j*.004),endV=.018+j*.003;
   o.push(mark(points(t=>p(u+(endU-u)*t,endV*t),24),58+52*seed(j,618),.2,'pencil',.43));
  }
 }
 // Thin fibres break out of the lower cloth and curl away from the repeated weave.
 for(let i=0;i<215;i++){
  const u=.12+.74*seed(i,635),a=p(u,.985),length=16+74*seed(i,119),sway=-20+40*seed(i,707);
  if(seed(i,73)>.5+.45*light(u,1))continue;
  o.push(mark(points(t=>[a[0]+sway*t+7*Math.sin(t*5+i)*t,a[1]+length*t-9*Math.sin(t*PI)],38),61+90*light(u,1),.22+seed(i,33)*.1,'pencil',.69));
 }
 // One loose warp has not been cut off; it continues as a changing, undecided line.
 const loose=p(.48,1);
 o.push(mark(points(t=>[loose[0]+96*t+24*Math.sin(t*4.5),loose[1]+160*t-60*t*t],85),143,.3,'pencil',.63));
 return o;
}

const passes=[
 {name:'A suspended surface',note:'The initial segmented underpainting created regular dark seams. This branch overlaps the native stroke ends and lets the upper edge sag between two attachments.',review:{observation:'The initial whole looked like a rectangular swatch with a dark seam at each short stroke boundary.',change:'Overlap tapered ends and alter the hanging curve before adding local detail.',next:'Check whether the painted fold now reads continuously and whether its top needs a visible support.'},build:sheet},
 {name:'Shared pressure',note:'Warp and weft describe unequal tension; the lower edge starts to loosen.',review:{observation:'The close texture needs to be judged separately from the large fold.',change:'Add fine crossing fibres and an unfinished lower edge.',next:'Inspect density, soft-stroke seams and the unsupported upper edge before continuing.',region:[630,410,470,430]},build:threads},
 {name:'Held, with an edge left open',note:'The surface now reads continuously, but it looked like a floating material sample. Fine ties attach its corners and loose fibres give the lower edge an unfinished duration. A later inspection found the row of cutouts too graphic; this branch removes that device and lets the fibre ends carry the incompleteness.',review:{observation:'The revised fold reads, while the rectangular outline and unbroken weave remain too complete.',change:'Give the upper curve two small attachments and let the lower edge separate into curling fibres.',next:'The row of dark cutouts interrupted the fold like punched graphics. Remove them in this branch; inspect whether the loose edge can carry the subject on its own.',region:[475,635,565,375]},build:tension}
];
export default {title:'A place for the unfinished',date:'2026-09-07',page:{w:W,h:H},note:'A suspended woven surface holds a shape without sealing it. I am drawing the space that attention can give an unfinished thought: pressure shared across many threads, with an edge still loose enough to change. First construction; support and edge hierarchy need inspection.',passes,build:()=>passes.flatMap(p=>p.build())};
