import { OP, PHASE, PAUSE, CLAMP, OCCLUDE, jitter, seed } from '../mark-engine.js';
import { pts, line, plane, hatch, grey } from './aperture-codex-hand.js';
const W=1200,H=1600;
export default { title:'the aperture of a question', date:'2026-09-07', note:'I removed the top-left rays and cloud washes. The well now depends on six folded planes whose hatching converges around a bare opening; the nearest hinge is still slightly too neat, but the depth belongs to architecture rather than an effect.', page:{w:W,h:H}, build:()=>{
  const ops=[PHASE('01 · a quiet opening, set before the walls')];
  const opening=[[438,410],[520,348],[649,342],[755,395],[788,492],[738,555],[616,579],[495,548],[425,482]]; ops.push(OCCLUDE(opening,.18));
  const walls=[[[86,95],[438,410],[425,482],[72,765]],[[86,95],[438,410],[520,348],[372,72]],[[372,72],[520,348],[649,342],[728,68]],[[728,68],[649,342],[755,395],[1118,184]],[[1118,184],[755,395],[788,492],[1174,728]],[[1174,728],[788,492],[738,555],[1100,1350]],[[1100,1350],[738,555],[616,579],[665,1570]],[[665,1570],[616,579],[495,548],[110,1370]],[[110,1370],[495,548],[425,482],[34,742]]];
  for(let i=0;i<walls.length;i++){ const p=walls[i]; plane(ops,p,76+(i%3)*13,i+4); hatch(ops,p,154,5.8,.55,i+19,'pencil'); }
  ops.push(PHASE('02 · hinges and pressure at changing scale'));
  for(let i=0;i<54;i++){ const side=i%2?-1:1,t=seed(i,22),x=600+side*(180+t*410),y=260+t*1080,L=34+seed(i,23)*86,ang=side*(.18+seed(i,24)*.5); const q=pts(u=>[x+Math.cos(ang)*L*u,y+Math.sin(ang)*L*u],Math.ceil(L/4)); ops.push(OP('s',jitter(q,.12),'line','pencil',.72,grey(196),.78)); }
  ops.push(PHASE('03 · one oxide thread, no explanation')); ops.push(OP('s',jitter(pts(t=>[144+t*860,1195+t*185+Math.sin(t*10)*7],130),.08),'accent','liner',1.1,[152,64,38],.86)); ops.push(PAUSE(800),CLAMP('tone',.4)); return ops;
}};
