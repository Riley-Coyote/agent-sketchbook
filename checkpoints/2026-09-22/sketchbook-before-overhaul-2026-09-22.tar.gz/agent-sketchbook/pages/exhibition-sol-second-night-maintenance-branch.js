/* Branch from Night maintenance page 2. The failed horizontal veils are omitted. */
import {OP,PHASE,PAUSE,jitter} from '../mark-engine.js';
import {roomAndGarden,glassAndCaretaker,podPoly,stroke,bezier} from './exhibition-sol-second-night-maintenance.js';

const bone=[213,218,226],steel=[108,128,156],midnight=[40,52,76],ember=[151,82,45];
function exactLoss(ops,cx,cy,rx,ry,ranges,w){
  const poly=podPoly(cx,cy,rx,ry);
  for(const [t0,t1] of ranges){
    const a=Math.floor(t0*(poly.length-1)),b=Math.floor(t1*(poly.length-1));
    ops.push(OP('s',jitter(poly.slice(a,b+1),.025),'line','eraser',w,bone,.62));
  }
}
function sleepingDepth(){
  const ops=[PHASE('05 · unequal sleep')];
  // Long exact-path erasures make visibility, rather than size alone, carry depth.
  exactLoss(ops,765,366,83,137,[[.03,.19],[.49,.67]],2.2);
  exactLoss(ops,918,318,58,94,[[.16,.4],[.69,.9]],1.9);
  exactLoss(ops,1070,357,47,78,[[.04,.31],[.53,.71]],1.75);
  exactLoss(ops,1200,430,70,116,[[.37,.63]],2.0);
  exactLoss(ops,1018,552,96,155,[[.01,.16],[.54,.75]],2.25);
  // Cables cross selected vessels in front, creating overlap without filling their interiors.
  ops.push(bezier([846,70],[870,244],[894,430],midnight,1.65,'soft',.55,'line',.035));
  ops.push(bezier([983,70],[1005,313],[1025,706],midnight,1.8,'soft',.58,'line',.035));
  ops.push(bezier([1125,70],[1143,278],[1163,565],midnight,1.45,'soft',.52,'line',.035));
  // Retain one short cold glint on each lost body.
  const glints=[[[713,295],[734,279],[758,281]],[[884,257],[899,247],[913,253]],[[1039,300],[1052,291],[1066,296]],[[1144,482],[1164,496],[1184,491]],[[944,474],[965,451],[985,449]]];
  glints.forEach((p,i)=>ops.push(stroke(p,i===4?bone:steel,i===4?.55:.36,'pencil',i===4?.4:.3,'line',.035)));
  ops.push(PHASE('06 · floor contact'));
  // An irregular contact shadow stays below the trolley rather than washing across the room.
  for(let i=0;i<11;i++){
    const y=750+i*2.5,fade=1-i/11;
    ops.push(stroke([[654-i,y],[704,y+1],[778+i*1.4,y-3]],midnight,1.9+i*.08,'soft',.28*fade,'line',.06));
  }
  ops.push(bezier([679,769],[710,777],[752,764],ember,.55,'glaze',.18,'line',.06));
  // Reduce brightness along the arm shaft while keeping the joints and tool tip intact.
  ops.push(stroke([[708,650],[690,618],[671,590]],bone,1.8,'eraser',.2,'line',.02));
  ops.push(stroke([[708,650],[690,618],[671,590]],steel,.62,'pencil',.42,'line',.02));
  ops.push(PAUSE(800));
  return ops;
}

function quietSuspension(){
  const ops=[PHASE('07 · suspension returns to the dark')];
  const cables=[[[846,70],[870,244],[894,430]],[[983,70],[1005,313],[1025,706]],[[1125,70],[1143,278],[1163,565]]];
  // Lift the three bars on their exact curves.
  for(const p of cables)ops.push(bezier(p[0],p[1],p[2],bone,2.6,'eraser',.72,'line',.02));
  // Restore them as interrupted hairlines whose visibility changes with depth.
  const traces=[
    [[846,70],[855,137],[863,196]],[[871,260],[881,336],[891,409]],
    [[983,70],[991,181],[998,278]],[[1009,392],[1017,529],[1024,663]],
    [[1125,70],[1132,171],[1139,252]],[[1148,366],[1156,464],[1162,547]],
  ];
  traces.forEach((p,i)=>ops.push(bezier(p[0],p[1],p[2],steel,.26+(i%3)*.06,'pencil',.18+(i%2)*.08,'line',.02)));
  // A small collar glint says suspension without outlining another form.
  ops.push(bezier([1006,383],[1018,379],[1028,384],steel,.38,'pencil',.32,'line',.025));
  ops.push(PAUSE(700));
  return ops;
}

const passes=[
  {name:'The room and suspended records',note:'A closed service hall recedes toward a quiet door. Six archive vessels hang at different depths; only the nearest is awake, its branching record lit from within.',review:{observation:'The depth sequence and amber foreground vessel read at fit scale, but continuous oval rims make the vessels feel diagrammatic. In detail the internal branches repeat as one sparse symbol, and the two bright ceiling rails compete with the focal record.',change:'Initial construction with converging rails, interrupted floor seams, translucent stroked vessels, unequal rims, internal branches, and one localized amber light.',next:'Break the foreground rim into reflection glints, refract room seams through its body, quiet the overhead rails, and introduce a small maintenance action that explains the light.',region:[390,190,820,500]},build:roomAndGarden},
  {name:'Glass and the caretaker',note:'The awake vessel now bends pieces of the room through its body and carries interrupted edge glints. A small wheeled caretaker reaches into it with an articulated inspection arm; its local light activates a denser, returning branch structure.',review:{observation:'The awake vessel reads through refracted seams and a dense unequal record, and the small caretaker is legible. Several sleeping rims remain too complete; a first attempt to veil them dried as obvious horizontal correction bands, so this branch returns to the clean page-2 glass.',change:'Lifted long rim and rail segments; added refracted seams, broken glints, denser internal returns, suspended fragments, a low trolley, jointed arm, inspection light, and floor reflections.',next:'Lose exact rim spans with erasure only, use cable overlap for depth, and anchor the trolley without painting across the glass.',region:[390,250,430,570]},build:glassAndCaretaker},
  {name:'Unequal sleep',note:'The sleeping records lose exact stretches of their rims without painted veils. Dark suspension cables overlap selected bodies, short glints preserve glass, and a bounded floor shadow settles the caretaker.',review:{observation:'The rim loss is clean and unequal, but the three new suspension cables render as bright thick bars. They divide the scene at fit scale and flatten the vessels at detail scale.',change:'Removed the failed veils, erased exact rim ranges, added three occluding cables and five cold glints, confined the contact shadow, and quieted the arm shaft.',next:'Lift the cable bars on their exact paths and restore only interrupted hairline suspension traces.',region:[650,180,610,610]},build:sleepingDepth},
  {name:'Suspension returns to the dark',note:'The three bright bars are lifted. Six interrupted hairline traces now imply hanging weight without cutting the room into panels; a single collar glint remains near the lowest vessel.',review:{observation:'Inspect whether the lost edges now carry depth without visible correction bands or bars, and whether the visual path stays with the awake record and caretaker.',change:'Erased the three heavy cable curves, redrew their visible fragments as fine low-value pencil lines, and added one small collar glint.',next:'If the final whole and foreground/background details hold, assess this branch for candidate status and record any remaining dependence on dark display.',region:[380,170,900,650]},build:quietSuspension},
];

export default{title:'Night maintenance · unequal sleep',date:'2026-09-07',refs:[2],page:{w:1500,h:950},note:'A branch from the clean material pass after atmospheric veils turned into correction bands. The garden should recede by losing edges and passing behind cables, while one record remains awake under care.',passes,build:()=>passes.flatMap(p=>p.build())};
