import {OP,PHASE,OCCLUDE,seed} from '../mark-engine.js';
const ink=[226,223,216];
const mix=(a,b,t)=>a+(b-a)*t;
const at=(a,b,t)=>[mix(a[0],b[0],t),mix(a[1],b[1],t)];
const A=[250,166],B=[480,212],C=[558,394],D=[290,345],E=[154,303];
const mark=(pts,brush='pencil',w=.65,alpha=.65)=>OP('s',pts,'line',brush,w,ink,alpha);
const line=(a,b,brush='pencil',w=.65,alpha=.65)=>mark([a,at(a,b,.5),b],brush,w,alpha);
function placement(){
  const o=[PHASE('Folded blank card: plane, open end and table')];
  // Sparse low marks establish a surface beneath the card.
  for(let j=0;j<19;j++){
    const y=383+j*2.8,x=166+seed(j,14)*74;
    o.push(line([x,y],[580+seed(j,17)*35,y+5],'soft',.8,.027));
  }
  // The far foot and left edge of the open triangular end.
  o.push(line(E,[400,350],'pencil',.6,.4));
  o.push(line(E,A,'soft',.45,.62));
  o.push(line(E,A,'pencil',.6,.65));
  // Native overlapping soft strokes follow the fall of the front paper plane.
  for(let i=0;i<=154;i++){
    const u=i/154,a=at(A,B,u),b=at(D,C,u);
    o.push(line(a,b,'soft',1,.085+.095*(1-u)));
  }
  o.push(line(A,B,'pencil',.7,.9));
  o.push(line(A,D,'pencil',.65,.76));
  o.push(line(D,C,'pencil',.55,.7));
  o.push(line(B,C,'pencil',.5,.49));
  // A few short fibers, avoiding a single uniform hatch across every surface.
  for(let i=0;i<29;i++){
    const u=.08+seed(i,41)*.8,v=.1+seed(i,43)*.79;
    const top=at(A,B,u),bottom=at(D,C,u),p=at(top,bottom,v);
    const q=at(top,bottom,Math.min(.96,v+.024+seed(i,46)*.052));
    o.push(line(p,q,'pencil',.35,.065));
  }
  return o;
}
function opacityRepair(){
  const o=[PHASE('Make the front paper opaque'),OCCLUDE([A,B,C,D],1)];
  // Retain the old canvas, clear the physical foreground, then repaint it.
  // The hidden foot stays in the history but no longer shines through paper.
  for(let i=0;i<=154;i++){
    const u=i/154,a=at(A,B,u),b=at(D,C,u);
    o.push(line(a,b,'soft',1,.085+.095*(1-u)));
  }
  o.push(line(A,B,'pencil',.7,.9));
  o.push(line(A,D,'pencil',.65,.76));
  o.push(line(D,C,'pencil',.55,.7));
  o.push(line(B,C,'pencil',.5,.49));
  for(let i=0;i<29;i++){
    const u=.08+seed(i,41)*.8,v=.1+seed(i,43)*.79;
    const top=at(A,B,u),bottom=at(D,C,u),p=at(top,bottom,v);
    const q=at(top,bottom,Math.min(.96,v+.024+seed(i,46)*.052));
    o.push(line(p,q,'pencil',.35,.065));
  }
  return o;
}
const passes=[
  {name:'First placement',note:'Try a folded blank card seen from its open end, with one broad illuminated paper plane. The initial study needs actual inspection for edge hierarchy, paper tone and contact with the table.',build:placement},
  {name:'Opaque foreground repair',note:'The whole and 2x open-end crop showed the far-foot line crossing the lower front plane. Clear only the foreground paper silhouette and redraw its tone and edges on the retained canvas.',review:{observation:'At x285–400, y329–350, the far-foot line is visible through the front plane, so opaque card reads as a translucent slab.',change:'Occlude the front quadrilateral and restore the foreground with the same native soft and pencil strokes; retain the visible far foot outside that silhouette.',next:'Inspect whether the line is gone and whether clearing has introduced a doubled or ragged silhouette. Table contact and the mechanically even tone may remain unresolved.',region:[260,310,165,65]},build:opacityRepair}
];
export default {title:'A blank card holding itself up',date:'2026-09-07',page:{w:720,h:520},note:'A modest pencil-and-soft study of a folded card. An observed rear-foot line passed through the front paper. The second pass clears and redraws the foreground on the same canvas. The study still needs judgment of table contact and the too-even material tone.',passes,build:()=>passes.flatMap(p=>p.build())};
