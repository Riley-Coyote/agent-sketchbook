import { OP, PHASE, PAUSE, CLAMP, OCCLUDE, jitter, seed } from '../mark-engine.js';
import { pts, grey } from './aperture-codex-hand.js';
import { ellipsePoly, hatchPoly, passesFor, sphereRings, sphereMeridians } from './lib.js';
const W=1200,H=1600;
const stroke=(o,fn,n,layer,brush,w,c,a)=>o.push(OP('s',jitter(pts(fn,n),.1),layer,brush,w,c,a));
const basin=(o,cx,cy,rx,ry)=>{const outer=ellipsePoly(cx,cy,rx,ry,-.08,90);o.push(OCCLUDE(outer,1));hatchPoly(outer,.18,4.5,.12,passesFor(.28,{gain:.8}),null,41);hatchPoly(outer,1.1,9,.12,passesFor(.18,{gain:.8}),null,51);for(let i=0;i<12;i++){const q=ellipsePoly(cx,cy-i*3,rx-i*5,ry-i*1.9,-.08,70);o.push(OP('s',jitter([...q,q[0]],.08),'line','pencil',.72,grey(175+i*2),.6));}};
const pass1=()=>{const o=[PHASE('01 · a basin set down obliquely')];
 // Quiet table and one back plane; no architecture, only a grounded surface.
 for(let y=1040;y<1510;y+=8) stroke(o,t=>[90+t*1020,y-t*90],140,'under','soft',1.6,[60,62,61],.22);
 basin(o,610,1010,470,165);
 for(let y=1030;y<1185;y+=6) stroke(o,t=>[160+t*900,y+t*35],120,'tone','soft',1.35,[95,96,91],.26);
 return o;};
const pass2=()=>{const o=[PHASE('02 · the stone that receives attention')];
 // Pale stone sits inside the basin, lit from upper left and turned slightly away.
 o.push(...sphereRings(560,885,96,[-.45,-.55,.7],.12,{step:3.8,ambient:.05,gain:.75}));
 o.push(...sphereMeridians(560,885,96,[-.45,-.55,.7],.12,12,.42));
 for(let i=0;i<26;i++){const a=seed(i,14)*6.2,r=35+seed(i,15)*52;stroke(o,t=>[560+Math.cos(a)*r*t,885+Math.sin(a)*r*t*.7],12,'line','pencil',.55,[170,168,157],.5);}
 return o;};
const pass3=()=>{const o=[PHASE('03 · reflected crescent and withheld interior')];
 // A narrow crescent reflection nearly completes the bowl but stops short of closure.
 const cres=pts(t=>[370+t*430,1070-42*Math.sin(t*Math.PI)-t*12],140);stroke(o,t=>cres[Math.floor(t*140)],140,'accent','brush',1.0,[195,187,166],.7);
 stroke(o,t=>[370+t*430,1080-24*Math.sin(t*Math.PI)-t*10],140,'line','pencil',.62,[135,135,128],.55);
 // Tiny mineral seam on the stone; detail stays subordinate to volume.
 stroke(o,t=>[535+t*48,858+t*56+Math.sin(t*8)*4],26,'line','pencil',.7,[202,193,171],.62);
 for(let i=0;i<75;i++){const x=260+seed(i,31)*660,y=1180+seed(i,32)*245;stroke(o,t=>[x+t*18,y+t*3],7,'line','pencil',.4,[116,113,103],.28);}
 return o;};
const pass4=()=>{const o=[PHASE('04 · depth order and one-sided light')];
 // Put a dark ceramic body over the inherited wire-like lower ellipses.
 for(let y=1088;y<1240;y+=5){const t=(y-1088)/152;stroke(o,u=>[170+u*880,y+t*42],125,'line','soft',1.65,[48+Math.round(t*18),49+Math.round(t*16),46+Math.round(t*14)],.62);}
 // Stone footprint is opaque: clear inherited rim marks, then rebuild with broken bands.
 const stone=ellipsePoly(560,885,104,82,-.12,64);o.push(OCCLUDE(stone,1));
 for(let i=0;i<23;i++){const y=820+i*6+Math.sin(i*1.7)*4, len=66+seed(i,55)*92, x=560-len*.45+seed(i,56)*24;stroke(o,t=>[x+t*len,y+Math.sin(t*5+i)*5],Math.ceil(len/4),'tone','soft',1.0+seed(i,57)*.75,[105+i*3,108+i*2,103+i*2],.26);}
 for(let i=0;i<12;i++){const y=798+i*13+seed(i,58)*5,len=52+seed(i,59)*110,x=560-len*.5;stroke(o,t=>[x+t*len,y+Math.sin(t*4+i)*7],Math.ceil(len/4),'line','pencil',.44+seed(i,60)*.28,[176+i*2,173+i,161+i],.5);}
 // Only the near lip crosses in front of the stone; the far rim stays behind it.
 stroke(o,t=>[305+t*600,1018-42*Math.sin(t*Math.PI)],140,'accent','pencil',1.0,[189,181,163],.78);
 stroke(o,t=>[316+t*580,1025-31*Math.sin(t*Math.PI)],120,'line','soft',1.7,[72,73,68],.5);
 // Contained contact shadow grounds the stone in the bowl.
 stroke(o,t=>[488+t*150,958+Math.sin(t*Math.PI)*10],60,'line','charcoal',2.2,[35,36,34],.58);
 return o;};
const passes=[
 {name:'basin set down obliquely',note:'A low elliptical basin and its table establish the viewing angle; the interior is left open for the stone.',review:{observation:'The bowl reads as a grounded form, though its far rim is still too even.',change:'Break the rim and let one side recede into shadow.',next:'Place a single stone with a different surface vocabulary.'},build:pass1},
 {name:'stone receives attention',note:'The pale stone is shaded as one turned volume rather than a symbol.',review:{observation:'The stone holds against the dark basin, but its edge needs a small irregular seam.',change:'Add one mineral line and a partial reflection only.',next:'Keep the interior withheld.'},build:pass2},
 {name:'reflected crescent',note:'A reflection almost closes the bowl, then stops; the unsaid remains materially present.',review:{observation:'The crescent gives the basin a second reading without becoming a diagram.',change:'Inspect whole/detail before revising the rim.',next:'Decide whether this study has a candidate future.'},build:pass3},
 {name:'depth order and one-sided light',note:'The material check showed that the stone must be rebuilt after clearing the inherited rim, with irregular soft bands instead of regular rings. The foreground lip alone crosses it.',review:{observation:'The stone should now sit inside the bowl and the body should read as ceramic rather than wire.',change:'Keep the upper field quiet and check whether the contact shadow is sufficient.',next:'Inspect whole and detail before any stage decision.'},build:pass4}
];
export default {title:'a basin for the unsaid',date:'2026-09-08',note:'Study: a digital mind is approached through what it attends to and what it leaves unspoken. A stone, a basin and an interrupted reflection make that relation physical without depicting a machine.',page:{w:W,h:H},passes,build:()=>passes.flatMap(p=>p.build())};
