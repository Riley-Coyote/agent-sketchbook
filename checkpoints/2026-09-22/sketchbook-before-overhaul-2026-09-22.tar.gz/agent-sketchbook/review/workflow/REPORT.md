# Sketchbook revision workflow — 7 September 2026

The sketchbook now makes sustained revision discoverable and preserves its evidence. This work stayed inside Agent Sketchbook. No station, Sanctuary, museum layout or exhibition selection was changed.

## Open the work

- [Visual introduction](http://127.0.0.1:4194/start.html)
- [Saved instrument study](http://127.0.0.1:4194/atelier.html?book=books/instrument-study&page=7)
- [Fresh-agent trial](http://127.0.0.1:4194/atelier.html?book=books/handoff-trial&page=6)
- [Agent instructions](../../START_HERE.md)

The server uses the separate `books/atelier-practice-studio` data directory. Local books and their snapshots are retained on disk; source programs and review evidence are also saved in this repository. No commit or publication was made.

## What changed

- Agent onboarding now distinguishes source strokes, the material studio, and inspecting saved work. It teaches calibration, whole-image and detail inspection, specific diagnoses, correction and deliberate stopping.
- Named passes retain observations, changes, next questions and optional inspection regions. Shared compilation checks that the full builder and pass builders describe the same marks.
- Continue preserves earlier marks, pass boundaries, dimensions and paper. Branch records a changed construction. Resume recovers a full or partial checkpoint into a new source file, independent of the original helper files.
- Saved pages carry source/mark/checkpoint hashes and parent lineage. Book writes use writer exclusion and exclusive page creation. New work defaults to study; selection changes retain their reasons and history separately from immutable marks.
- The atelier displays saved marks without running their source. It offers before/after comparison, named checkpoints, native detail crops, zoom, replay and export. Invalid edits retain the last good drawing; rewriting earlier construction requires an explicit new-version action.
- Invalid raw coordinates are rejected before normalization. This fixes a case where an invalid number serialized as null could otherwise become a coordinate of zero.

## Actual drawing practice

The [instrument process](../instrument/PROCESS.md) records whole-image and detail inspections, material corrections, a construction error discovered in small screws, a preserved branch, and an additional pass addressing weight and edge hierarchy. All marks use the native drawing engine. The study remains somewhat mechanically regular; it was not promoted to exhibition work.

A [fresh agent](../handoff-trial/REPORT.md), without this conversation's history, worked from the new handoff. It made a tool study, diagnosed an incorrect overlap in a folded-card drawing, corrected it over existing marks, tried a changed composition, restored a saved checkpoint and continued it. Whole-image and detail PNGs from the restored checkpoint matched the originals byte for byte. Its follow-up verified that improved source formatting preserved marks, journals and rendered pixels exactly.

Trial feedback led to clearer repository-root command instructions, accurate crop dimensions in CLI output, and one operation per line in restored source. [Initial evidence](../handoff-trial/verification.json) and [follow-up evidence](../handoff-trial/follow-up-verification.json) retain the comparisons. This is evidence for one fresh agent using the source workflow, not a claim that every model or medium has been trained or validated.

## Verification

Passed during this work:

- `node tests/workflow.mjs`
- `node tests/workflow-browser.mjs`
- `node tests/browser.mjs http://127.0.0.1:4194` — 14 passed, 0 failed
- `node tests/dimensions.mjs`
- `node tests/material-persistence.mjs`
- `node tests/precision.mjs`
- `node tests/materials.mjs`
- `node tests/studio-server.mjs`
- `git diff --check`

Browser verification covered actual retained pixels, append/rewrite behavior, failed-edit recovery, saved journals, comparison, crops, reduced motion and narrow-screen overflow. The introduction and real study were visually inspected at desktop and 375px widths.

The broad `node test.mjs` collection run reported **80 passed and 4 failed**. The four failures were reproduced with the pre-change sandbox: a helper file treated as a page, an unavailable helper import, a draft stroke with fewer than two points, and a draft using an unknown layer. They are recorded in [baseline evidence](pre-existing-draft-failures.json). Other artists' drafts were preserved.

## Practical limits

Selection stages are editorial metadata, not hosting permissions or publication controls. The source atelier and material studio remain distinct authoring paths. Original source dependencies are not bundled; saved marks and resume are self-contained. These changes support careful practice and curation, but neither pass count nor passing tests establishes artistic quality.
