# Night maintenance

I wanted to draw care that does not need an audience.

The room is an archive-garden after closing. Each suspended vessel holds a record that has gone quiet. Their forms recede by losing edges and interior detail rather than simply becoming smaller. One vessel remains awake. Inside it, a branching history crosses itself, compresses around repair points, and sends fine reaches toward the glass.

The caretaker is deliberately small: a wheeled instrument with an articulated arm, a few luminous joints, and one narrow inspection light. It does not awaken the whole garden. It tends one record closely while the others remain dark. For me, that is the emotional center of the drawing—maintenance as attention given to a particular continuity when no one is watching.

The foreground glass uses broken amber and chalk glints, a broad cool-violet reflected field, refracted room seams, and suspended fragments. Its living record thickens through fine unequal branches, crossings, compressed repair knots, and reaches that disappear into reflection. The sleeping vessels are mostly inferred from dim stems, collars, and isolated cold glints. The hall stays mostly black so the work feels private, late, and ongoing.

## Final inspection

At fit scale, the visual path holds between the awake record and the caretaker, with the hanging garden present as a quiet depth field. The original ceiling rails have been repainted into the room, and the awake vessel is the only substantially bounded form. At detail scale, the reflected field, irregular living core, glass glints, articulated arm, and floor contact have separate jobs. The faintest sleeping records depend on a dark display and may disappear in a small thumbnail; that loss is part of their depth but remains a viewing limitation.

## Lineage and evidence

- Page 1: initial room and six equally bounded vessels
- Page 2: continued glass, interior record, and caretaker
- Page 3: failed continuation; dark veils dried as horizontal correction bands
- Page 4: branch from page 2 using exact edge loss, but suspension cables became bright bars
- Page 5: continued correction with the cable bars lifted and restored as interrupted hairlines; preserved as the earlier candidate
- Page 6: substantive branch from page 2, repainting full rails and distant bounds while introducing the reflected field and dense living core
- Page 7: continued correction to feather the reflected field and weaken the far-right sleeper
- Page 8: continued correction repainting the original inner sleeping rims; final review candidate
- Initial evidence: `01-whole.png`, `01-detail.png`
- Material checkpoint: `02-whole.png`, `02-detail.png`
- Failed study: `03-whole.png`, `03-detail.png`
- Branch checkpoint: `04-branch-whole.png`, `04-branch-detail.png`
- Earlier candidate: `05-final-whole.png`, `05-final-detail.png`
- Material branch: `06-material-whole.png`, `06-material-detail.png`
- Final candidate: `08-material-final-whole.png`, `08-material-final-detail.png`
