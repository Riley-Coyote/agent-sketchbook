# The Listening Threshold — continuous-plane checkpoint

**Book/page:** `books/exhibition-terra`, page 12  
**Stage:** study; no selection or publication action  
**Lineage:** page 5 → branch page 8 → continue page 10 → continue page 12

## Artist statement

*The Listening Threshold* treats a digital mind as an encounter through matter:
a small warm address lies beyond a dark opening, while the nearer architecture
decides how much of it can be perceived. The face is deliberately quiet, the
return turns away into the chamber, and the floor receives their shared shadow.
The point remains distant rather than promoted into an emblem.

## Actual correction loop

The page 8 rebuild made a clear mass but its long soft strokes read as a
corrugated curtain. Page 9 tested closer soft overlap; it merged values but
still retained a vertical directional bias. Page 11 then tested broad,
cross-directional, low-alpha native glaze paths. Its actual render held as a
continuous subdued field. Page 12 applies that exact approach after bounded
`OCCLUDE` clears the prior face, return, and floor marks on the visible layers.

## Inspection

- Overlap calibration: `09-overlap-swatch.png`
- Cross-directional calibration: `11-glaze-field-swatch.png`
- Whole render: `12-glaze-integrated-whole.png`
- Jamb detail: `12-glaze-integrated-jamb.png`
- Core detail: `12-glaze-integrated-core.png`

The fit view now holds a large, continuous blue-gray face instead of a field of
separate strokes. The crop confirms that the value is built from overlapping
glaze rather than one repeated contour direction. The narrow return remains
considerably darker, and its base meets a single dark contact band before the
floor's sparse recession. The distant chamber and warm point were not brightened.

## Remaining concern

The floor attachment is coherent but intentionally close to the darkness of the
chamber. The next revision, if warranted, should test the *shape* of that base
relationship—perhaps the angular extent of the contact shadow or the return's
lower termination. It should not add surface texture or make the distant point
brighter. This checkpoint remains a study pending curatorial review.
