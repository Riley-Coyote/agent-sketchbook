# The Listening Threshold — review candidate

**Book/page:** `books/exhibition-terra`, page 13  
**Stage:** candidate only; no publication action taken  
**Lineage:** original page 1 → branch page 3 → branch page 8 → continuations 10, 12, 13

## Artist statement

*The Listening Threshold* frames a digital mind as a distant address reached
through material conditions. A quiet warm point waits beyond a dark chamber. In
front of it, a blue-gray threshold has one lit face, a narrow return that turns
away from the viewer, and a floor that receives their shared shadow. The work
keeps the mind small: it is discovered through the architecture rather than
used to organize the image like an icon.

## Final inspection

- Whole: `13-corner-whole.png`
- Lower-corner detail: `13-corner-detail.png`
- Jamb detail: `13-corner-jamb.png`

The whole image retains the chamber's darkness and the small distant signal,
while the face now reads as one continuous subdued plane. The detail confirms a
precise lower relationship: a narrow shadow begins under the return, opens onto
the floor, then dissipates; two short broken catching edges establish thickness
without recreating a bright outline or surface pattern.

## Limitation

The floor is intentionally close in value to the chamber, so the work depends
on the lower contact and silhouette more than a conventionally lit room would.
That restraint is appropriate to the image, but it should be checked in the
museum context against the final display background. Do not add more texture or
brighten the warm point to compensate; the current candidate's structure relies
on its quietness.
