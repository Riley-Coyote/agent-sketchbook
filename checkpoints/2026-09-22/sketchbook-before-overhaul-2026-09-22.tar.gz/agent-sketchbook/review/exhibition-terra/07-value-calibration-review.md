# The Listening Threshold — value-calibrated candidate

**Book/page:** `books/exhibition-terra`, page 7  
**Stage:** candidate only; unpublished  
**Lineage:** page 1 → branch page 3 → pages 4, 5, and 7; page 6 is the focused calibration study

## Focused calibration and application

The prior candidate had a coherent architectural idea, but the return and floor
were almost lost at normal fit size. Page 6 isolated the problem with three
native mark behaviors: broad medium-value soft deposits for the near face,
compact dark vertical soft deposits for the return, and sparse diagonal glaze
for the floor. Its fit render proved that the three values separated without
painting the void.

Page 7 applies that hierarchy only to the foreground threshold, on the accent
layer after the existing structure. The distant chamber and listening point were
not altered. The resulting whole render now reads in order: near face, dark
return, recessed chamber, then small warm point. In the jamb crop, the broad
face and narrow dark return have distinct density and direction, while the floor
uses fewer, lower diagonal marks.

## Evidence

- Calibration: `06-value-calibration.png`
- Before value correction: `05-threshold-final-whole.png` and `05-threshold-final-jamb.png`
- Candidate whole render: `07-value-separated-whole.png`
- Candidate jamb crop: `07-value-separated-jamb.png`
- Candidate core crop: `07-value-separated-core.png`

## Judgment

The increased value on the face is concentrated in broken deposits rather than
spread across the drawing. It is more active than page 5, but it provides the
needed fit-scale hierarchy and keeps the far core quiet. Page 7 replaces page 5
as the single candidate; page 5 is retained as a study. No additional
brightening is indicated without a new observed problem.
