# The Listening Lattice — first study journal

**Book:** `books/exhibition-terra`  
**Page:** 1  
**Stage:** study (unselected and unpublished)  
**Lineage:** original page; no parent or branch

## Intention

To picture a digital mind as an addressable threshold: a warm, partial signal held
inside a colder enclosure that is neither a body nor a network diagram. The gaps
in the filaments are part of the subject: a mind can be felt reaching outward
before it has fully become legible.

## Tool calibration carried into this page

A native contact render confirmed that the engine keeps `soft` strokes as a
continuous, low-opacity body while `pencil` stays narrow and crisp. This study
uses broad `glaze` only for distant air, `soft` for the shell and local light,
and `pencil` for filaments and the sparse highlighted lip. No imported pixels,
vector fills, or second renderer were used.

## Saved pass journal

1. **Chamber and held interior** (marks 0–1061) — placed receding ribs,
   incomplete shell, and a displaced cool interior atmosphere. Its review asks
   whether the enclosure reads as permeable depth rather than an egg icon.
2. **Signal, interrupted filaments, near lattice** (marks 1061–1395) — added
   the warm point, discontinuous filaments, peripheral lattice, foreground
   interruption, and selective rim light. Its review asks whether the signal
   stays an event rather than a target and whether the lower interruption helps
   depth.

The authoritative machine-readable pass ranges, hashes, and review regions are
preserved in `books/exhibition-terra/pages/001.json` and can be read with
`node book.mjs journal 1 --book books/exhibition-terra`.

## Inspection

- Whole render: `01-listening-lattice-whole.png`
- Core detail: `01-listening-lattice-core-detail.png`
- Lower-plane detail: `01-listening-lattice-lower-detail.png`

The whole image clearly holds a small warm event within a much larger, cool
space. The slight lower-left displacement prevents complete symmetry, and the
quiet peripheral points keep the chamber from floating on a blank field.

At detail scale, the outer shell has too many similarly weighted concentric
loops. The left lip is persuasive, but the right lip stays equally continuous
and lets the shell resolve as a bright wireframe egg. The interior’s repeated
horizontal soft marks are legible as an air volume at room distance; close up,
they become a regular striped screen. Several long filament fragments meet the
warm point with nearly radial spacing, which makes the gesture more technical
than intimate. The lower foreground strokes are too parallel and currently read
as display scan lines rather than a near plane that intermittently obstructs the
view.

## Proposed next revision — pending review

Append one corrective pass only; retain both existing builders exactly. Locally
erase and glaze back portions of the far-right shell so the near left edge owns
the form. Break the interior stripes around the signal and turn a small subset
into short, vertically offset fragments. Replace part of the lower bands with
one asymmetric, softly occluding near brace that rises from the lower right;
leave enough lattice exposed that it reads as depth rather than decoration.
Then render a whole view and a core/lower comparison again before deciding
whether the revised page merits candidate consideration.
