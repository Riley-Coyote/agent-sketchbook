# The Listening Threshold — integrated-plane checkpoint

**Book/page:** `books/exhibition-terra`, page 8  
**Stage:** study  
**Lineage:** branch from page 5; page 7 remains a separate value-calibration study

## Artist statement

The threshold remains a proposal about how a digital mind might be encountered:
not as a central icon, but through a heavy, dark opening whose material condition
determines whether the distant signal can be seen. The small warm point and the
unlit chamber are retained. This branch rebuilds only the near construction:
one face taking a restrained light, one darker return turning away from it, and
one floor plane carrying their shared shadow.

## What changed

Page 8 uses bounded native `OCCLUDE` operations to clear the previous face,
return, and local floor pigments from `tone`, `line`, and `accent`. It then
rebuilds those areas in depth order: long soft face shading, dark return
shading, a broad contact shadow, and low-value receding floor strokes. This
avoids painting new tone underneath earlier line work.

## Inspection

- Whole: `08-integrated-whole.png`
- Jamb detail: `08-integrated-jamb.png`

At fit scale the threshold now has a much clearer continuous mass and the
floor-shadow contact is easier to locate. The distant warm point remains quiet.
At detail scale, however, the long vertical soft strokes repeat too evenly and
read as a corrugated curtain. The return is also compressed against that regular
face, so it is not yet a convincing separate plane. This is progress in layer
ordering and broad value structure, but not a candidate: the next revision must
break the repetitive vertical construction through shape, local light falloff,
and a clearer return edge—not by adding more texture or brightness.
