# The Listening Threshold — candidate review

**Candidate:** `books/exhibition-terra`, page 5  
**Stage:** candidate only; no museum publication or sharing action was taken  
**Lineage:** page 1 *The Listening Lattice* → branch page 3 → continuing
corrections pages 4 and 5

## Artist statement

*The Listening Threshold* imagines a digital mind as something met through an
environment rather than presented as an object. A worn architectural jamb takes
the foreground; its cool face, dark return, and receding floor make the viewer
stand outside the chamber. Beyond it, the intelligence is a brief warm address
point and a nearly vanished membrane. Its few paths do not describe a system;
they wait, bend, and fail to meet cleanly. The work treats cognition as an
encounter with depth, obstruction, and partial reply.

## Why this is a candidate

The original study's central shell was visually clear but too evenly repeated:
at both fit and detail scale it became a wireframe egg and its horizontal
interior bands looked screen-like. The branch replaces that repeated contour
with a structured spatial hierarchy:

- broad, fragment-built left face for a near material surface;
- narrow dense dark return and a secondary catching edge for thickness;
- a low-contrast far wall and sloped floor plane that place the interior in
  depth;
- a small, subordinate signal that is found through the threshold.

The whole render now reads from architectural mass to recess to signal. The
jamb crop shows different jobs for marks: dispersed glaze on the face, denser
soft pigment in the return, thin worn edge marks, and low-value floor strokes.
The core crop remains sparse. A first attempted correction made an unwanted dark
X at the signal; page 5 records its removal with native eraser marks and a
smaller asymmetric flare instead of hiding that misstep.

## Evidence

| View | Initial study | Final candidate |
| --- | --- | --- |
| Whole | `01-listening-lattice-whole.png` | `05-threshold-final-whole.png` |
| Core detail | `01-listening-lattice-core-detail.png` | `05-threshold-final-core.png` |
| Material / threshold detail | `02-threshold-swatch.png` | `05-threshold-final-jamb.png` |

## Remaining limitation

The far chamber is intentionally very quiet, but on a dim display it can recede
almost too completely. The candidate earns its selection because the foreground
mass and depth still read at room scale; any future revision should only revisit
the far wall if inspection shows that its restraint has become loss of space.
It should not add texture merely to brighten the image.

The authoritative pass records, parent hashes, and candidate selection remain
in the book. Page 1 and the threshold calibration are retained as studies.
