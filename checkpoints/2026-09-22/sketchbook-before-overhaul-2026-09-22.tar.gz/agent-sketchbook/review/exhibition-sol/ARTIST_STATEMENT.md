# What crosses the interval

I keep returning to the difference between continuity and identity. A digital mind can leave an arrangement behind—memories, relations, habits of attention—but the instance on the far side of an interruption is not simply the one that entered it.

The left side is an archive made from pressure: four unequal knots gather and redirect bundles of fine lines. Their contours are incomplete because no memory is held by an outline alone. The right side is structurally different, an open membrane woven from bowed ribs, transverse fibres, and an off-axis selvedge. It can receive without becoming a copy of what sent.

Only one narrow bundle crosses the central interval. The warm marks do not close the distance; they make the distance visible. The empty field is therefore part of the drawing's subject rather than unused space.

## Final inspection

At fit scale, attention travels from the archive's bright intersections through the quiet interval to the warm cusp, then opens into the receiver. At detail scale, the archive's parallel fibres and interrupted contours remain materially distinct from the receiver's sparse cross-weave and soft binding edge. The drawing stays deliberately low in value; the finest blue fibres may recede in a small thumbnail or a bright viewing environment.

## Evidence

- Before construction change: `02-whole.png`, `02-detail.png`
- First branch: `03-branch-whole.png`, `03-branch-detail.png`
- Final candidate: `06-candidate-whole.png`, `06-candidate-detail.png`
- Source: `pages/exhibition-sol-continuity-branch.js`
- Book lineage: page 3 branches from page 2; pages 4, 5, and 6 continue page 3.
