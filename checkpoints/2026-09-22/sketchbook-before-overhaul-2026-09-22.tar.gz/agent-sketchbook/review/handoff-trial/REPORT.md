# Fresh-agent handoff trial — 2026-09-07

**Result: the handoff and its linked references were sufficient for this source-workflow trial.** I made a small native practice sheet and an original folded-card study, inspected actual PNGs, corrected an observed overlap error on the same canvas, branched a changed construction, restored a saved checkpoint into a new source file, proved identical rendering, and added a visible pass to the restored source. All six saved pages remain **study**. This is evidence for one fresh agent and one medium/workflow, not a certification of every future agent or the material studio.

## Exact route into the work

Working directory throughout: `/Users/rileycoyote/Documents/Repositories/agent-sketchbook`.

1. Read `AGENTS.md`, then `START_HERE.md`. These were the only initial handoff documents.
2. Followed the source-workflow reference into `PAGE_PROTOCOL.md`: opening module, brush/layer tables, native helpers, tone lessons and continuation rules. Read `pages/first-contact.js` for syntax. Inspected the existing dirty-file list only to avoid other work.
3. Ran `node book.mjs --help`. Read the 37-line `review/instrument/PROCESS.md` and the opening helpers and concluding pass sequence of `pages/codex-rain.js`. Used their diagnostic method, not their subjects or palette. I did not read or change engine/tool implementation, consult memory, obtain external images, or use another renderer.
4. Confirmed the supplied server responded at `http://127.0.0.1:4194/atelier.html` and reused it.
5. Chose default dark paper with neutral light `pencil` and `soft` marks; practiced a controlled line, alpha transition, accumulation and erasure first. All practice/study drawing is native mark data.

## Saves and lineage

| Page | Source | Meaning | Parent | Marks | Stage |
|---|---|---|---|---:|---|
| 1 | `pages/handoff-trial-contact.js` | Tool contact sheet | — | 127 | study |
| 2 | `pages/handoff-trial-card.js` at its initial save | Initial folded card | — | 211 | study |
| 3 | `pages/handoff-trial-card.js` | Foreground opacity correction | continue 2 | 401 | study |
| 4 | `pages/handoff-trial-card-branch.js` | Lowered ridge construction | branch 3 | 401 | study |
| 5 | `pages/handoff-trial-card-resumed.js` immediately after resume | Unmodified restored checkpoint | continue 3 | 401 | study |
| 6 | `pages/handoff-trial-card-resumed.js` after adding a pass | Local table tone at the feet | continue 5 | 426 | study |

The authored source at each save remains inside its immutable book page. The resumed file now contains page 6's added pass; page 5 preserves the unmodified restored file.

Commands used for the saved sequence:

```sh
node book.mjs init --owner 'Codex fresh handoff trial' --book books/handoff-trial
node book.mjs write pages/handoff-trial-contact.js --book books/handoff-trial
node book.mjs write pages/handoff-trial-card.js --book books/handoff-trial
# After inspecting page 2 and appending the correction:
node book.mjs write pages/handoff-trial-card.js --book books/handoff-trial --continue 2
node book.mjs journal 3 --book books/handoff-trial
# Copied my own source and lowered its two ridge points by 35 drawing pixels.
# Deliberate negative check: this failed and created no page:
node book.mjs write pages/handoff-trial-card-branch.js --book books/handoff-trial --continue 3
# Correct operation:
node book.mjs write pages/handoff-trial-card-branch.js --book books/handoff-trial --branch 3
node book.mjs resume 3 --book books/handoff-trial --out pages/handoff-trial-card-resumed.js
# Save the restored checkpoint unchanged so its render can be compared:
node book.mjs write pages/handoff-trial-card-resumed.js --book books/handoff-trial --continue 3
# After inspecting the restored PNGs and appending tableContact():
node book.mjs write pages/handoff-trial-card-resumed.js --book books/handoff-trial --continue 5
node book.mjs journal 6 --book books/handoff-trial
node book.mjs list --book books/handoff-trial
```

Every preview below came from `node book.mjs render PAGE --book books/handoff-trial --out review/handoff-trial/FILE` with the listed options. All whole outputs use `--scale 1`; detail outputs use `--scale 2`.

| Page | Whole file | Detail file and `--crop` | Additional checkpoint export |
|---|---|---|---|
| 1 | `00-contact-whole.png` | `00-contact-detail.png`, `290,180,200,90` | — |
| 2 | `01-card-whole.png` | `01-card-detail.png`, `135,150,260,235` | — |
| 3 | `02-repaired-whole.png` | `02-repaired-detail.png`, `135,150,260,235` | `02-before-whole.png`, `--pass 1 --scale 1` |
| 4 | `03-branch-whole.png` | `03-branch-detail.png`, `135,190,260,210` | — |
| 5 | `04-resumed-whole.png` | `04-resumed-detail.png`, `135,150,260,235` | — |
| 6 | `05-resumed-after-whole.png` | `05-resumed-after-detail.png`, `130,290,455,155` | `05-resumed-before.png`, `--pass 2 --scale 1` |

## What I actually saw and changed

I opened all six whole/detail pairs above with `view_image`, rather than inferring their appearance from mark counts. The two extra historical checkpoint exports were compared by SHA-256 rather than separately reopened.

**Contact sheet.** A soft stroke is not automatically a smooth field. The ramp at 5.25-pixel spacing visibly separated into vertical ribs; overlapping the strokes at 2-pixel spacing made a coherent but textured patch. The pencil line stayed fine. The same-layer eraser made a dark slit through the patch. This directly informed the study's closer stroke spacing and its understanding of dark-paper corrections.

![Native contact sheet](00-contact-whole.png)

**Page 2, first study.** The tent-like structure reads, but at whole scale the far foot travels visibly across the lower front plane. The 2× open-end crop confirms a bright line from about `(285,329)` to `(400,350)` through supposedly opaque paper. This makes the face look transparent. The even face texture also resembles a fine mesh, and the table marks sit too far below the left near corner. I chose the overlap error as the first concrete correction.

![Initial study](01-card-whole.png)
![Initial overlap error at detail scale](01-card-detail.png)

**Page 3, same canvas.** I preserved the complete first builder, appended an `OCCLUDE` of the front quadrilateral, and repainted that foreground using native soft and pencil strokes. The detailed rerender shows the foot ending at the foreground edge. The unwanted line through the face is gone. Clearing and repainting makes the front silhouette slightly emphatic, but does not introduce an obvious broken edge. The card remains overly geometric, with weak table contact; the correction is successful without making the drawing resolved.

![Repaired study](02-repaired-whole.png)
![Repaired overlap at detail scale](02-repaired-detail.png)

**Page 4, branch.** Lowering the ridge by 35 pixels changes the earlier construction. The branch produces a flatter, broader paper plane. I prefer the original upright opening for clarity; the low version compresses the dark opening without solving the mechanical tone or floating table. It is a genuine alternate iteration, not an exhibition selection or an extra additive pass mislabeled as a branch.

![Lower-ridge branch](03-branch-whole.png)

**Pages 5–6, restore and further work.** I restored page 3, saved the restored source unchanged as page 5, rendered it at both scales, and opened both files. The same corrected image returned. Only then did I append a third pass: faint ground strokes immediately below both feet and a narrow erasure for contact. Page 6 visibly adds the small left-foot patch and connects more tone to the near foot. It slightly reduces floating, but at detail scale the parallel floor strips remain visible and the tiny left patch risks reading as a separate dash. I stopped with that concern recorded; adding marks merely to claim resolution would not improve this trial.

![Restored source receiving a new pass](05-resumed-after-whole.png)
![Remaining ground-strip issue](05-resumed-after-detail.png)

## Evidence that restore and continuation really worked

The machine-readable [verification.json](verification.json) records PNG dimensions and SHA-256 hashes, source/mark hashes, lineage and twelve checks, all true. [Journal 3](journal-03.json), [journal 4](journal-04.json), [journal 5](journal-05.json), and [journal 6](journal-06.json) retain the pass ranges and review metadata.

- Page 3's first 211 marks exactly equal page 2's marks. Its first-pass PNG equals the original page 2 PNG byte for byte.
- Page 5's complete mark array and pass journal equal page 3's. The restored whole PNG and detail PNG are each byte-for-byte identical to the corresponding page 3 exports.
- The whole-image equivalence hash is `23b2f392ee3df09044e3d15e7ba0e2fb2d48f3c5de4a19a67e9ba4c7499bbe20`; the detail equivalence hash is `3a1f66a539b646aeb6cd1bc91b1c6db8da719a5b45cf99d982e6ab1bece163fe`.
- Page 6 retains all 401 restored marks unchanged and adds 25 operations. Its `--pass 2` render still equals page 3/page 5; its final PNG differs and visibly contains the ground pass.
- Page 4 has changed construction and a `branch` parent relation. Pages 3, 5 and 6 have `continue` relations.
- All six saved pages are `study`. No museum selections, tool files, docs, or other artists' pages were changed by this trial.

## Browser inspection

Opened the source atelier at `atelier.html?p=handoff-trial-card`, used **Compare previous pass**, **Inspect at 100%**, **Inspect a detail**, and **Show detail**. The detail inputs automatically used the pass's recorded `[260,310,165,65]` review region. I inspected the actual before/after canvases and the detail crop.

Then opened `atelier.html?book=books/handoff-trial&page=6`. It correctly showed `study`, three passes, the new review, a disabled source-continuation button, and the saved-checkpoint resume commands. Compared the prior pass with the final pass at fit view. The browser's reduced fit canvases make a grid/moire quality in the repeated soft strokes more prominent than the PNG at 1×; that reinforces the material concern rather than proving a new engine defect.

## Failures, friction and remaining ambiguity

1. **Useful guardrail, deliberately exercised:** trying the changed construction with `--continue 3` exited 1: `continuation changed earlier marks; restore them or save a new version with --branch`. It created no page; the subsequent `--branch 3` created page 4. This was clear and recoverable from the handoff.
2. **Early crop CLI reporting was misleading:** the first contact-detail export printed `1040×620`, while the actual PNG was `400×180`; the first card-detail export printed `1440×1040`, while the PNG was `520×470`. The crops themselves were correct. Later exports printed the correct crop dimensions. Tool work was happening concurrently, so this is an observed early-session mismatch, not a claim that the current implementation still has it.
3. **Environment-only browser failure:** asking for a visible in-app browser failed with `IAB visibility is not supported in a subagent thread`. A hidden tab worked. My first retry also raised `tab is not defined` because the failed declaration did not persist, though it created the tab; attaching to the returned tab ID recovered it. These are tooling/session issues, not Sketchbook instructions failing.
4. **Restore is safe but not pleasant to read as source:** its frozen marks occupy one very long JSON line. My `sed`/`tail` inspection flooded and truncated the output. The short wrapper and commented `passes.push` location were still enough to append a pass. Agents should inspect that wrapper while leaving the frozen data alone. The original authored source is preserved in the saved page, as promised.
5. **Documentation wording to clarify:** the detailed protocol says “From a shell, in the book's folder,” while `START_HERE.md` says to run from the repository and pass `--book`. I used the repository directory throughout. Taken literally, the former wording could put a novice in `books/my-book`, where the documented relative `book.mjs` command would not be found. I did not run that unnecessary failing command.
6. The handoff explains how to restore, but does not prescribe an equivalence check. I chose an unchanged verification save plus native rerenders and byte hashes. It worked, but spent a book page on a duplicate checkpoint. That is an optional verification technique, not a requirement for every drawing session.

The source workflow needed no oral rescue. The document's encouragement to leave studies unresolved was useful: I can report a clear corrected overlap, a real branch, and a verified resumable canvas without claiming that this geometric paper study is exhibition art. The separate experimental material studio, older partial-pass resume, file-overwrite refusal, and future changes to helper implementations were not exercised here.

## Follow-up verification

A bounded follow-up on 2026-09-07 verified fixes made after the original trial, without adding art or changing the preceding report. `PAGE_PROTOCOL.md:248` now explicitly says to run from the **agent-sketchbook repository root**, with `--book books/YOUR_BOOK` choosing storage. That resolves the command-location ambiguity recorded above.

```sh
node book.mjs resume 3 --book books/handoff-trial --out pages/handoff-trial-formatted-resume.js
node book.mjs write pages/handoff-trial-formatted-resume.js --book books/handoff-trial --continue 3
node book.mjs render 7 --book books/handoff-trial --out review/handoff-trial/06-formatted-resume-whole.png --scale 1
node book.mjs render 7 --book books/handoff-trial --out review/handoff-trial/06-formatted-resume-detail.png --crop 135,150,260,235 --scale 2
```

The new frozen block has clear BEGIN/END comments and **401 operations on 401 separate lines**. Reading its opening and wrapper with `sed`/`tail` is now manageable. The unchanged source saved as verification page 7, still `study`, continuing page 3. Its marks and pass journal exactly equal page 3. I opened the new whole and detail PNGs with `view_image`; both also match their original counterparts byte for byte, retaining the equivalence hashes above. The crop command now correctly reports `520×470`, matching its actual PNG dimensions. All six follow-up checks pass in [follow-up-verification.json](follow-up-verification.json). Raw-coordinate validation was fixed by the main agent and was not independently retested in this bounded follow-up. No new art, tool changes, or museum edits were made here.
