# Holding something open — 7 September 2026

This round follows Riley's approval of the instrument and **What crosses the interval**, request for more work on **The Listening Threshold**, and decision to set **the unseen handrail** aside. The new drawings stay in this local review folio. Only the two approved pages were installed in the museum.

## The review selection

| Work | Artist | Saved page | Current status |
| --- | --- | --- | --- |
| A place for the unfinished | Codex | exhibition-codex-second / 4 | Candidate |
| The Listening Threshold | Terra | exhibition-terra / 13 | Revised candidate |
| Night maintenance | Sol | exhibition-sol-second / 8 | Candidate |
| A Basin for the Unsaid | Luna | exhibition-luna-second / 6 | Study |
| An instrument waiting for a signal | Codex | instrument-study / 11 | Approved and installed |
| What crosses the interval | Sol | exhibition-sol / 6 | Approved and installed |

Candidates are offered for Riley's review, not automatically published. Luna's basin remains a study because the bowl still reads as a flattened oval. The unseen handrail and its source pages remain intact outside the current selection.

## How the drawings changed

**Codex — A place for the unfinished.** The first fabric construction showed regular seams where tapered soft strokes met. A branch overlaps the ends and changes the hanging curve. An additive continuation introduces attachment cords and loose fibres. Whole/detail inspection then rejected a row of dark cutouts as a graphic device; the final branch removes it, letting the loose edge carry the subject. All four native pages remain available. See the [statement and process](../exhibition-codex-second/ARTIST_STATEMENT.md).

**Terra — The Listening Threshold.** The previously reviewed page 7 had scattered deposits across the near face. Separate native calibration pages explored overlap and a cross-directional glaze. The integrated correction makes the face more continuous; a final focused contact shadow and broken edge connect its lower return to the floor. The distant address point remains small. Root inspected the whole and lower-corner detail; its quiet values remain a display consideration. [Terra's final notes](../exhibition-terra/13-candidate-review.md).

**Sol — Night maintenance.** A new archive at night pairs one awake record with a small caretaker. The initial equal vessel outlines and ceiling rails competed with the subject. Several corrections failed visibly: dark veils formed bands, and edge removal exposed bright suspension lines. A substantive branch from page 2 reconstructs the rails and introduces a reflected field and denser interior. The final candidate is page 8, inspected whole and close. The work is stylized, and the dim sleeping vessels depend on viewing scale. [Sol's statement and lineage](../exhibition-sol-second/ARTIST_STATEMENT.md).

**Luna — A Basin for the Unsaid.** The first basin had a bright rim through the stone and repeated bands across its surface. Reading the actual drawing program established the cause: a later tone pass still lay beneath an earlier accent layer, and rows four pixels apart left exposed gaps. Small material checks and construction branches correct the depth order and overlap. The stone is now continuous, but the bowl still lacks convincing depth. Root retained the artist's study status. [Current native source](../../pages/exhibition-luna-second-basin-rebuild.js).

Each agent worked in a separate native book and source scope. Root inspected rendered images and returned specific feedback rather than accepting the artist's completion language alone. No fixed pass quota was used. No image generator, imported raster, SVG, alternate renderer or modified MarkEngine produced these drawings.

## Installed works

The instrument's page 11 replaces its earlier export in the existing museum bay. Sol's page 6 is added as **S22** on a freestanding concrete panel north of the reading island. The approved books, earlier pages, source modules and superseded instrument manifest are retained in the museum's private curation directory.

A browser inspection rejected the initial west-wall location: the apparent gap was the upper-walk entrance. The final concrete panel has an explicit physical footprint used by the existing navigation system. Both west-wall openings stay clear. The museum now contains 22 Sketchbook works, including 14 native commissions; all 45 Claude Field originals remain available.

Real browser checks opened every commission from its actual frame, exercised the artwork viewer and return controls, checked mobile layout and long credits, and confirmed moving Field wall previews. All four acceptance checks passed with no page errors. The actual installed panel and instrument viewer are shown in this folio.

## Verification

- Chrome review at 1440px desktop and 390px mobile: all six drawings load, all current/earlier controls work, image and saved-page links resolve, original proportions are contained, no horizontal overflow or page errors. Actual desktop and mobile captures were inspected. [Folio evidence](folio-verification.json).
- All 53 saved snapshots across seven books have matching source and mark hashes. Recorded checkpoints match; every continuation retains its parent's prefix. The folio agrees with current book-level selections. Three standalone calibration pages have no named passes; no boundaries were invented. The initial checker incorrectly assumed snapshot status changes with later selection; it now checks the authoritative book selection while keeping the original page immutable. [Native evidence](native-verification.json).
- Museum commissioning, navigation, catalog, placement, atlas and privacy checks were exercised for the publication; the production build passes. Vite still reports its existing large-chunk advisory. This art round does not claim to resolve that bundle-size issue or establish a new frame-rate benchmark.

Fable's station and the Sanctuary were not edited. The museum and Sketchbook servers remain available locally. Nothing was committed or pushed.
