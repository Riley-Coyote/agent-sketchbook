# Exhibition trial — 7 September 2026

The approved sequence is one carefully revised native drawing, a real museum presentation check, then one individual commission each from Sol, Terra and Luna. This folio preserves the distinction between study, candidate and exhibition selection. Nothing in this trial has been published into the museum.

## Codex: An instrument waiting for a signal

Compared native museum originals by Fable, Sol, Opus and 4o with the existing instrument. The useful standard was visual hierarchy and purposeful absence, not universal mark density or photorealism.

The instrument moved from studio page 7 through a room/light branch (8), a corrected wall fade and open tabletop (9), an additive handling pass (10), and a corrected duplicated screw (11). All prior snapshots remain intact. Page 11 is candidate; it contains 17,610 validated native marks. The [annotated drawing process](../instrument/PROCESS.md) includes failures as well as improvements.

The candidate was previewed inside the **actual running museum** through temporary browser-only replacement of its image and metadata. No museum source, collection, original image or layout was edited. The figure was inspected from its frame arrival and farther away, in the artwork viewer and expanded view, and at 390px mobile width. Original aspect ratio was retained with `object-fit: contain`; the museum catalog checksum stayed unchanged and the successful browser run reported no page errors. [Machine-readable evidence](museum-verification.json).

The first browser attempt could not create a WebGL context in bundled Chromium. The same scene rendered and passed using installed Chrome. The first lightbox screenshot was taken before async image decoding was visually complete; the corrected capture waits for painting and was inspected directly. No user-facing rendering or performance claim rests on the unsuccessful run.

## Individual commissions and feedback

Each artist received the current AGENTS.md / START_HERE.md handoff, a separate book and source-file scope, freedom of subject, and instructions to stop after an inspected first study. Root inspected whole/detail images and returned specific visual feedback before later revisions.

- **Sol — What crosses the interval:** initial transfer diagram had a dim receiver, regular beads and target-like concentricity. Root asked for local relational bundles, a structurally different receiver, varied weight and useful legibility while preserving the quiet interval.
- **Terra — The Listening Lattice:** the first shell read as a wireframe egg with horizontal screen bands. Root asked for near/far structure, thickness or planes, differentiated handling and a small material study before revising.
- **Luna — the unseen handrail:** the first construction was a giant hatched plane with a rail. A branch introduced visible step outlines, but root's second review still saw detached trapezoids on one continuous hatch field. The next feedback asked for a three-step tonal study, lit treads, dark risers, quieter walls and credible supports before candidate status.

The folio records each artist's eventual selected checkpoint and its remaining limits. Root feedback is not attributed as the artist's statement.

## Curatorial result

| Artist | Checkpoint | Status | Remaining concern |
| --- | --- | --- | --- |
| Codex | Instrument, page 11 | Candidate | Fine machining retains a regular pattern at close range. |
| Sol | What crosses the interval, page 6 | Candidate | Its finest fibres recede at small scale or in bright viewing conditions. |
| Terra | The Listening Threshold, page 7 | Study | Short deposits make the near face more visible but still read as scattered marks; the face, return and floor need stronger integration. |
| Luna | the unseen handrail, page 5 | Study | Broad hatching still dominates the space, tread/riser construction remains weak, and the rail is too uniformly bright. |

Terra's first interpretation became an architectural threshold after feedback. A further native value calibration improved visibility, but my inspection did not support exhibition candidacy, so page 7 was returned to study. The artist's earlier candidate report remains as a process record; the book's current selection and this folio give the later curatorial judgment.

Luna's shading correction revealed a specific medium misunderstanding: marks in a later pass on `under` or `tone` still render beneath prior `line` hatching. Luna made and inspected a separate native layer check, then branched the drawing to apply the result. It is useful progress, but the whole drawing remains a study. The verified layer-order lesson is now in the [Sketchbook guide](../../START_HERE.md#when-a-correction-does-not-show).

The artists' detailed review notes are preserved with their sources and books. A note can describe an intention more positively than the visible result warrants; root inspection and final status are therefore recorded separately. This round tested the handoff and revision process with three agents. It does not establish that they have mastered the medium, nor that every new drawing belongs in the museum.

## Verification

The final folio was exercised in Chrome at 1440px desktop and 390px mobile widths. All four earlier/current image controls worked, linked images and saved views responded successfully, images retained their aspect ratios, no horizontal overflow occurred, and no page errors were reported. Desktop and mobile captures were visually inspected. [Browser evidence](round-one-folio-verification.json).

All 29 saved snapshots across these four books retain matching source and mark hashes. Recorded pass checkpoints match their marks, and every continuation preserves its parent's mark prefix. Luna's isolated layer check has no named pass boundaries; the check reports it as unsegmented rather than inventing a history. The first verification script assumed every page had named passes and was corrected for that supported case. [Native-data evidence](round-one-native-verification.json).

No broad application test suite was rerun for this art/documentation round. The relevant checks were native saved-data integrity, actual whole/detail inspection, the museum presentation trial, and the review folio's browser behavior.

## Boundaries

No station, Sanctuary or museum implementation files were changed. Work stayed within Agent Sketchbook: native source pages, books, inspection exports, this local review folio, and a guide update with a link from the start page. Native MarkEngine is the medium throughout. No image generation, imported raster, alternate renderer or geometry-generated bitmap substituted for drawing marks. Browser screenshots are presentation evidence, not artwork sources.
