import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const base=resolve(import.meta.dirname,'../..');
const hash=v=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const names=['instrument-study','exhibition-sol','exhibition-terra','exhibition-luna','exhibition-codex-second','exhibition-sol-second','exhibition-luna-second'];
const results=[];
for(const name of names){
 const dir=resolve(base,'books',name),book=JSON.parse(await readFile(resolve(dir,'book.json'),'utf8'));
 const saved=new Map(await Promise.all(book.pages.map(async meta=>[meta.index,JSON.parse(await readFile(resolve(dir,meta.file),'utf8'))])));
 const result={book:name,snapshots:saved.size,continuations:0,branches:0,unsegmentedPages:[],candidates:[],exhibitions:[]};
 for(const [index,p] of saved){
  const label=`${name} / ${index}`,j=p.journal;assert(j,label);
  assert.equal(hash(p.source),j.sourceHash,label+' source');assert.equal(hash(p.ops),j.marksHash,label+' marks');
  let end=0;
  for(const pass of j.passes){
   assert.equal(pass.start,end,label+' contiguous passes');end=pass.end;assert(end<=p.ops.length,label);
   assert.equal(hash({page:p.page,surface:p.surface,ops:p.ops.slice(0,end)}),pass.checkpointHash,label+' checkpoint');
  }
  if(j.passes.length)assert.equal(end,p.ops.length,label+' full marks');else result.unsegmentedPages.push(index);
  if(j.parent){
   assert.equal(j.parent.book,book.id,label+' parent book');const parent=saved.get(j.parent.page);assert(parent,label+' parent exists');
   assert.equal(hash(parent.ops),j.parent.marksHash,label+' parent hash');
   if(j.parent.relation==='continue'){assert.deepEqual(p.ops.slice(0,parent.ops.length),parent.ops,label+' parent prefix');result.continuations++;}
   if(j.parent.relation==='branch')result.branches++;
  }
  // Selection is a later book-level decision; saved drawing snapshots remain immutable.
  const meta=book.pages.find(m=>m.index===index);
  if(meta.stage==='candidate')result.candidates.push(index);
  if(meta.stage==='exhibition')result.exhibitions.push(index);
 }
 results.push(result);
}
const entries=JSON.parse(await readFile(resolve(import.meta.dirname,'gallery.json'),'utf8'));
for(const e of entries){
 const p=JSON.parse(await readFile(resolve(base,e.book,'book.json'),'utf8'));
 assert.equal(p.pages.find(p=>p.index===e.page)?.stage,e.stage,e.title+' displayed stage');
}
const report={checked:new Date().toISOString(),results,sourceAndMarkHashesMatch:true,recordedCheckpointHashesMatch:true,continuePrefixesPreserved:true,folioSelectionsMatch:true,scope:'Saved native data and lineage integrity, not artistic quality. Unsegmented pages have no named pass boundaries; none have been invented.'};
await writeFile(resolve(import.meta.dirname,'native-verification.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
