"""Render the folio's Markdown process records for the existing static server."""
from pathlib import Path
from urllib.parse import urlsplit
import os
from markdown_it import MarkdownIt
from html import escape
ROOT=Path(__file__).resolve().parents[2]
REVIEW=ROOT/'review'
parser=MarkdownIt('commonmark',{'html':False}).enable('table')
seen=set()
style='''body{margin:0;background:#101010;color:#dad7d3;font:16px/1.8 Georgia,serif}main{max-width:850px;margin:auto;padding:45px 24px 80px}nav,p,li{overflow-wrap:anywhere}nav{font:13px/1.6 system-ui;margin-bottom:42px}a{color:inherit;text-underline-offset:4px}a:focus-visible{outline:2px solid white;outline-offset:4px}h1,h2,h3{font-weight:400;line-height:1.25}h1{font-size:38px}h2{margin-top:40px;font-size:26px}h3{font-size:21px}table{border-collapse:collapse;width:100%;font:13px/1.65 system-ui}td,th{border-bottom:1px solid #363636;text-align:left;padding:10px 7px}pre,code{font-size:12px;overflow-wrap:anywhere}pre{white-space:pre-wrap}strong{color:#f2efea}@media(max-width:600px){h1{font-size:31px}main{padding:28px 18px}table{font-size:11px}td,th{padding:8px 4px}}'''
def render(path):
 path=path.resolve()
 if path in seen:return
 seen.add(path)
 tokens=parser.parse(path.read_text())
 def fix(nodes):
  for t in nodes:
   if t.type=='link_open':
    href=t.attrGet('href');url=urlsplit(href)
    if not url.scheme and url.path.endswith('.md'):
     target=(path.parent/url.path).resolve()
     if target.is_file() and target.is_relative_to(REVIEW):
      render(target);t.attrSet('href',str(Path(url.path).with_suffix('.html'))+(('#'+url.fragment) if url.fragment else ''))
     elif target==ROOT/'START_HERE.md':t.attrSet('href',os.path.relpath(ROOT/'start.html',path.parent))
   if t.children:fix(t.children)
 fix(tokens)
 body=parser.renderer.render(tokens,parser.options,{})
 back=os.path.relpath(REVIEW/'exhibition-trial/index.html',path.parent)
 title=path.read_text().splitlines()[0].lstrip('# ').strip()
 path.with_suffix('.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+escape(title)+'</title><style>'+style+'</style><main><nav><a href="'+back+'">← Return to the drawings</a></nav>'+body+'</main></html>')
for name in ['ROUND_TWO.md','REPORT.md']:render(Path(__file__).resolve().parent/name)
print('Rendered',len(seen),'review notes.')
