import {chromium} from 'playwright-core';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';

const out=import.meta.dirname;
const entries=JSON.parse(await readFile(resolve(out,'gallery.json'),'utf8'));
const base='http://127.0.0.1:4194/review/exhibition-trial/index.html';
const browser=await chromium.launch({channel:'chrome',headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}});
const errors=[],checks=[];
page.on('pageerror',e=>errors.push(e.message));
const paint=async img=>{await img.evaluate(async el=>{await el.decode();await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));});};
try {
  await page.goto(base);
  await page.waitForFunction(n=>document.querySelectorAll('.work').length===n,entries.length);
  for(const w of entries){
    const section=page.locator('#'+w.id),img=section.locator('.drawing img');
    await section.scrollIntoViewIfNeeded();await paint(img);
    const original=await img.evaluate(el=>[el.naturalWidth,el.naturalHeight]);
    assert(original[0]>0&&original[1]>0);
    await section.getByRole('button',{name:'Earlier study',exact:true}).click();await paint(img);
    assert((await img.getAttribute('src')).endsWith(w.before));
    assert.equal(await section.getByRole('button',{name:'Earlier study',exact:true}).getAttribute('aria-pressed'),'true');
    await section.getByRole('button',{name:'Current drawing',exact:true}).click();await paint(img);
    assert((await img.getAttribute('src')).endsWith(w.image));
    assert.equal(await section.getByRole('button',{name:'Current drawing',exact:true}).getAttribute('aria-pressed'),'true');
    await section.screenshot({path:resolve(out,`folio-${w.id}-desktop.png`)});
    for(const href of await section.locator('a').evaluateAll(links=>links.map(a=>a.href))){
      const response=await page.request.get(href);assert.equal(response.status(),200,href);
    }
    checks.push({artist:w.artist,stage:w.stage,natural:original,beforeAfterWorks:true,linksResolve:true});
  }
  await page.setViewportSize({width:390,height:844});
  await page.goto(base);
  await page.waitForFunction(n=>document.querySelectorAll('.work').length===n,entries.length);
  for(const w of entries){
    const section=page.locator('#'+w.id),img=section.locator('.drawing img');
    await section.scrollIntoViewIfNeeded();await paint(img);
    const fit=await img.evaluate(el=>{const r=el.getBoundingClientRect();return {left:r.left,right:r.right,width:innerWidth,fit:getComputedStyle(el).objectFit};});
    assert(fit.left>=0&&fit.right<=fit.width);assert.equal(fit.fit,'contain');
    await section.getByRole('button',{name:'Earlier study',exact:true}).click();await paint(img);
    await section.getByRole('button',{name:'Current drawing',exact:true}).click();await paint(img);
  }
  const noOverflow=await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);
  assert(noOverflow);await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:resolve(out,'folio-mobile.png')});
  await page.locator('#codex').screenshot({path:resolve(out,'folio-codex-mobile.png')});
  for(const href of await page.locator('header a,.foot a,.museum a').evaluateAll(links=>links.map(a=>a.href))){
    if(new URL(href).origin!==new URL(base).origin)continue;
    assert.equal((await page.request.get(href)).status(),200,href);
  }
  await page.goto(new URL('./ROUND_TWO.html',base).href);
  assert.equal(await page.locator('h1').count(),1);
  for(const href of await page.locator('a').evaluateAll(links=>links.map(a=>a.href))){
    if(new URL(href).origin===new URL(base).origin)assert.equal((await page.request.get(href)).status(),200,href);
  }
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Notes overflow on mobile');
  await page.screenshot({path:resolve(out,'process-mobile.png')});
  assert.deepEqual(errors,[]);
  const result={checked:new Date().toISOString(),entries:checks,noOverflow,mobileWidth:390,errors,scope:'Local review folio; browser image loading, comparison controls, links and responsive layout. These checks do not establish artistic quality.'};
  await writeFile(resolve(out,'folio-verification.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
}finally{await browser.close();}
