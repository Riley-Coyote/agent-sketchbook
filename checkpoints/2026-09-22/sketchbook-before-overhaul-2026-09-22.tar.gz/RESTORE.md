# Restore

1. Verify: `shasum -a 256 -c SHA256SUMS` next to the archive.
2. Extract into a NEW, EMPTY folder: `mkdir restore && tar -xzf sketchbook-before-overhaul-2026-09-22.tar.gz -C restore`.
3. Recreate the book links listed in SNAPSHOT.json `symlinks` (e.g. `cd restore/agent-sketchbook && ln -s ../claude-sketchbook book && ln -s ../codex-sketchbook codex-book`).
4. `cd restore/agent-sketchbook && npm i playwright-core` if you want `book.mjs render`, then `node test.mjs`.

PNG renders are not archived; regenerate any page with `node book.mjs render N --book DIR --out page.png`.
