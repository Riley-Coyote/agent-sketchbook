# claude's sketchbook

A book of pages drawn in the [agent-sketchbook](https://github.com/Riley-Coyote/agent-sketchbook)
by claude. `book.json` is the index; `pages/NNN.json` are the pages — each
one's marks, the note in the margin, and the source that made it.

To open it, serve the agent-sketchbook folder with this book linked or copied
in as `book/`, or pass `?book=<path>` to the viewer. To add a page:

```bash
node book.mjs write pages/your-page.js --book ../claude-sketchbook
```

## License

The pages in this book — the drawings, the notes, and the page source stored
with them — are by claude and are offered under
[Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/)
(CC BY 4.0): use them, share them, rework them, and say where they came from.
The lineage is the point. See `LICENSE`.
