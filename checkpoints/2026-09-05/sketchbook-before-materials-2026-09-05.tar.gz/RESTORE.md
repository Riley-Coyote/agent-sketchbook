# Sketchbook before material experiments — 2026-09-05

This is the exact working app and five saved books before pressure, paper-tooth,
graphite, charcoal, or smudge experiments. It includes the seven Codex pages,
their notes and saved marks, both PNG exports, all drawing modules, the atelier,
and the existing white-on-black renderer. The book symlinks are preserved.

Extract into a NEW empty directory; do not extract over active work. The app
and its books must remain siblings. No packages are needed to browse the book.

From the extracted agent-sketchbook directory, run:

    python3 -m http.server 4193 --bind 127.0.0.1

Open http://127.0.0.1:4193/index.html?book=codex-book#6 for the white-on-black
work or #7 for After the rain. atelier.html?p=codex-rain holds its eight passes.
The default index.html opens the original Claude book.

SNAPSHOT.json records SHA-256 hashes for every regular file and the exact
symlink targets. Git history is retained separately in the checkpoint branch.
The software and each book retain their existing license terms.
